\ingroup module_hidden
\defgroup miniz miniz

# Folder miniz

`miniz/` contains a minimal ZIP compression library.
