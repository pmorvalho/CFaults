\ingroup module_hidden
\defgroup jbmc jbmc

# Folder jbmc

`jbmc/` is like cbmc but especially designed for Java.
