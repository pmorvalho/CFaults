\ingroup module_hidden
\defgroup janalyzer janalyzer

# Folder janalyzer

`janalyzer/` is a tool performing static analyses on Java
programs. It provides a Java front end for many of the static analyses
in the \ref analyses directory.
