/*******************************************************************\

Module:

Author: Daniel Poetzl

\*******************************************************************/

#include "java_object_factory_parameters.h"

void parse_java_object_factory_options(
  const cmdlinet &cmdline,
  optionst &options)
{
  parse_object_factory_options(cmdline, options);
}
