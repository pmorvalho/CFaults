\ingroup module_hidden
\defgroup jdiff jdiff

# Folder jdiff

`jdiff/` is a tool that offers functionality similar to the `diff`
tool, but for Java programs.
