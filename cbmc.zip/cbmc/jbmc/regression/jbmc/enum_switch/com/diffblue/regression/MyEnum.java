package com.diffblue.regression;

enum MyEnum {
 A, B, C, D;
}
