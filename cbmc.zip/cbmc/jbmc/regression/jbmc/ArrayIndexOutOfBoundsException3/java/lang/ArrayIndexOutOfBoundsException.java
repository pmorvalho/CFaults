package java.lang;

public class ArrayIndexOutOfBoundsException extends IndexOutOfBoundsException {
}
