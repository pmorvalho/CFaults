package java.lang;

public class IndexOutOfBoundsException extends RuntimeException {
}
