public class stack_test {
  public static void main(String[] args) {
    stack_var6 s = new stack_var6();
    int n = s.f(1,2,4);
    assert(n==-2);
  }
}
