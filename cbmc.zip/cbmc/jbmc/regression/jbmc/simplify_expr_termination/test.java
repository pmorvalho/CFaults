public class test {

  public static int check()
  {
    boolean[] assigned = new boolean[3];
    if (assigned[0] == false) {
        assert false;
    }
    return 1;
  }
}
