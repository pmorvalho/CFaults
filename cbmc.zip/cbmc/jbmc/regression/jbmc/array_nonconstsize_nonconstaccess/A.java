public class A {
  public float a;
}
