public class Test {

    public int foo(int i) {
      int x = 0;
      if (i > 0) {
        x++;
      }
      else
      {
        x--;
      }
      return x + 1000;
    }
}
