interface package_friendly1 {
  void operation1();
}

class package_friendly2 {
  int operation2() {
    return 999;
  }
}
