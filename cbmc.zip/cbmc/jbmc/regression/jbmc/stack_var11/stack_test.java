public class stack_test {
  public static void main(String[] args) {
    stack_var11 s = new stack_var11();
    int n = s.f();
    assert(n==0);
  }
}
