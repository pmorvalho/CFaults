public class stack_test {
  public static void main(String[] args) {
    stack_var10 s = new stack_var10();
    int n = s.f();
    assert(n==0);
  }
}
