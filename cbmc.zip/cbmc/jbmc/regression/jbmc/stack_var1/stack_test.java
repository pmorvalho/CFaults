public class stack_test {
  public static void main(String[] args) {
    stack_var1 s = new stack_var1();
    int n = s.f(1);
    assert(n==0);
  }
}
