@FunctionalInterface
interface CustomLambda<T> {
    boolean is_ok(T t);
}
