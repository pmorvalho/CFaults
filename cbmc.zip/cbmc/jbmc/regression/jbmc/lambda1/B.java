public class B {
    public int y;

    public static java.util.function.Function<Double, Double> dmul = x -> x * 3.1415;

    public void set(int x) {
        y = x;
    }
}
