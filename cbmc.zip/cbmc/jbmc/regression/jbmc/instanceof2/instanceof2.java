class instanceof2
{
  public static void main(String[] args)
  {
    assert int.class instanceof Object;
  }
};
