class short1
{
  public static void main(String[] args)
  {
    short s;
    int i=100000;
    
    s=0;
    s=100;
    s=300;
    
    if(s>=1000)
      i=s;
    else
      s=(short)i;
  }
}

