package org.cprover;

public @interface MustNotThrow { }
