public class Main
{
  public void main(String[] args) // not static!
  {
    assert(args != null); // allowed to fail
  }
}
