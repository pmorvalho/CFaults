public class Opaque {

  Color c;

  public Color getC() {
    return c;
  }

}
