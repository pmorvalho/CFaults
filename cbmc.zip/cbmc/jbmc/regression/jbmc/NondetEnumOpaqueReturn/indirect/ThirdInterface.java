package indirect;

public interface ThirdInterface {
    TestEnum getState();
}
