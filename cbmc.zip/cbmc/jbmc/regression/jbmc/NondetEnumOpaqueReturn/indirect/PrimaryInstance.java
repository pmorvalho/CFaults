package indirect;

public class PrimaryInstance extends SecondaryInstance implements PrimaryInterface {
}
