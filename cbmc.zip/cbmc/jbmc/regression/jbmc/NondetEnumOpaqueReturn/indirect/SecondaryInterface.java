package indirect;

public interface SecondaryInterface extends ThirdInterface {
}
