package indirect;

public abstract class SecondaryInstance extends ThirdInstance implements SecondaryInterface {
}
