package indirect;

public interface PrimaryInterface extends SecondaryInterface {
}
