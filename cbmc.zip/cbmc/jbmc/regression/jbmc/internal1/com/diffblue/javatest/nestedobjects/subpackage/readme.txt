Source of benchmark:
https://github.com/DiffBlue-benchmarks/java-test