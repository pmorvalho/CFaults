package com.diffblue.javatest.nestedobjects.subpackage;

public class Item {
  public int cost;
}
