public class Test {
    public void main() {}
}
