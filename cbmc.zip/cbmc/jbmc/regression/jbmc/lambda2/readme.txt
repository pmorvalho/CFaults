from https://github.com/symphonyoss/symphony-java-client/

The StaticMethodRef.class is compiled using the Eclipse Compiler
