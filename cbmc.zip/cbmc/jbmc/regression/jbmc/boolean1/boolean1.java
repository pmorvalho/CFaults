class boolean1 {

  static public void doit(boolean my_boolean)
  {
    // Boolean shall be either true or false.
    if(my_boolean == true) return;
    if(my_boolean == false) return;

    assert false;
  }

};
