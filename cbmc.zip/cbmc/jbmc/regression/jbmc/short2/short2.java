public class short2
{
  short a;
  void f()
  {
    a=0;
    a++;
    assert a==1;
  }
}
