public class Main
{
  public static void main(String[] args)
  {
    if(args.length>0) {
      assert(args[0] != null); // must not fail 
    }
  }
}
