public class Test {
  public int test() {
    return (new Opaque()).get().value();
  }
}
