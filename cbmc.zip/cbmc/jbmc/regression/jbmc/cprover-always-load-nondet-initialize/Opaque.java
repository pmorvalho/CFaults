import org.cprover.CProver;

public class Opaque {
  public ObjectWithNondetInitialize get() {
    return new ObjectWithNondetInitialize();
  }
}
