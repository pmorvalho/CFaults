public class bitwise1
{
  static char c;
  public static void main(String[] args)
  {
    c=1;
    int i = (c | 2);
    assert i==3;
  }
}
