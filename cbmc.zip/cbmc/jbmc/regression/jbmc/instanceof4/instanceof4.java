class instanceof4
{
  public static void main(String[] args)
  {
    assert "" instanceof String;
  }
};
