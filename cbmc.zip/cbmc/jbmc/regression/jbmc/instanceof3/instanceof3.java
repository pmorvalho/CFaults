class instanceof3
{
  public static void main(String[] args)
  {
    assert args instanceof Object[];
  }
};
