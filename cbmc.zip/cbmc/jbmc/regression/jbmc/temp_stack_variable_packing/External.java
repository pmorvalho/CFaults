public class External {
    public void Accept(int... args) {

    }
}
