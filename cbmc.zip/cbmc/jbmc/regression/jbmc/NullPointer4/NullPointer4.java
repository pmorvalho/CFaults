public class NullPointer4 {

  public static void main(String[] args)
  {
    int array[]=null;
    int s=array.length; // NULL pointer dereference
  }

}
