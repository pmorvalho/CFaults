public class Test {
    public static void main(int x) {
        assert(x == 0);
    }
}
