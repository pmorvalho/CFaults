public class DivideByZero {
    public static void main(String args[]) {
        int i=0;
        int j=10/i;
    }
}
