public class NullPointer3 {

  public static void main(String[] args)
  {
    throw null; // NULL pointer dereference
  }
}
