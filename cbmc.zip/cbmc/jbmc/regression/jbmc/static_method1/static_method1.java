public class static_method1
{ 

  static public void f(int a, int b) {
    int c = b/(a+1);
  }

  static public void g(int a, int b) {
    int c = a/(b+1);
  }

}
