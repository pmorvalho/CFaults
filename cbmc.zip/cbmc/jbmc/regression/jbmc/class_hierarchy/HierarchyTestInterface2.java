interface HierarchyTestInterface2 {}
