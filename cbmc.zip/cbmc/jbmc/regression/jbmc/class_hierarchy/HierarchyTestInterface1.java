interface HierarchyTestInterface1 {}
