public class ArrayListEquals {
    
    public int check2(ArrayList<Integer> l1) {
        ArrayList<Integer> al = new ArrayList<Integer>();
        if(l1.equals(al))
            return 1;
        else
            return 0;
    }

}
