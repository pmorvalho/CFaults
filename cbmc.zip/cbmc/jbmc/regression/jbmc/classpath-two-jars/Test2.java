class Test2
{
  public static void foo()
  {
    assert false;
  }
}
