class Test
{
  public static void main(String[] args)
  {
    Test2.foo();
    assert true;
  }
}
