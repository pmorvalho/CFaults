public class B {

    public int g() {
        return 5;
    }

}
