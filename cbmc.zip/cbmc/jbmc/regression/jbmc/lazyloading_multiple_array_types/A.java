public class A {

    public int f() {
        return 1;
    }

}
