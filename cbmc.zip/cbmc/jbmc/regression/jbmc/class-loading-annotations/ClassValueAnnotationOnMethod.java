public class ClassValueAnnotationOnMethod {
  @AnnotationWithClassValue(MyClassA.class)
  public void classValueAnnotatedMethod() {}
}
