public @interface AnnotationWithClassValue {

  Class<?> value();

}
