public class ArrayValueAnnotationOnField {
  @AnnotationWithArrayValue({MyClassA.class, MyClassB.class})
  int arrayValueAnnotatedField;
}
