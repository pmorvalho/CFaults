public class ClassValueAnnotationOnField {
  @AnnotationWithClassValue(MyClassA.class)
  int classValueAnnotatedField;
}
