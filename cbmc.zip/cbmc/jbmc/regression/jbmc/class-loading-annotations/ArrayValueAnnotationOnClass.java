@AnnotationWithArrayValue({MyClassA.class, MyClassB.class})
public class ArrayValueAnnotationOnClass {
}
