public class ArrayValueAnnotationOnMethod {
  @AnnotationWithArrayValue({MyClassA.class, MyClassB.class})
  public void arrayValueAnnotatedMethod() {}
}
