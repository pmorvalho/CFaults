public @interface AnnotationWithArrayValue {

  Class<?>[] value();

}
