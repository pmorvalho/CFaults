public class MyClassA {}
