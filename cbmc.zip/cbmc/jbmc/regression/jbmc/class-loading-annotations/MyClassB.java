public class MyClassB {}
