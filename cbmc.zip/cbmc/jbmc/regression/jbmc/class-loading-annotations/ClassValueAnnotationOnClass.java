@AnnotationWithClassValue(MyClassA.class)
public class ClassValueAnnotationOnClass {
}
