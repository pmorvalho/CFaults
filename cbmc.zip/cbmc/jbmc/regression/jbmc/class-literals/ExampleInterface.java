
interface ExampleInterface {

}
