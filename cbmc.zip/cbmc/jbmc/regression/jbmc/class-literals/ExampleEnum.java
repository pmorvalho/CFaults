
public enum ExampleEnum {

}

