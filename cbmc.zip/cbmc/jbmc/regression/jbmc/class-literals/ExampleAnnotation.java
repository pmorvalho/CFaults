
public @interface ExampleAnnotation {

}
