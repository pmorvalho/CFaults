class TestJar
{
  public static void foo()
  {
    assert false;
  }
}
