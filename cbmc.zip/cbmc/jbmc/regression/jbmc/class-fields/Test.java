public class Test {

  public static void main() {

    java.lang.Class c = Test.class;
    assert false;

  }

}
