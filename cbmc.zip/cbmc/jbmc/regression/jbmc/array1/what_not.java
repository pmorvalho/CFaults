class what_not
{
};
