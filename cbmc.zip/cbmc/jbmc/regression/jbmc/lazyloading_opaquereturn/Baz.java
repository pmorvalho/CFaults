public class Baz {
  public void cproverNondetInitialize() {

  }
}
