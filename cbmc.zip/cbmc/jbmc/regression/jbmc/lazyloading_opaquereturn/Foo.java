public class Foo {
  public Bar subType;

  public Baz[] arraySubtype;

  public Gen<GenFiller> genSubtype;

  public void cproverNondetInitialize() {

  }
}
