public class TestClass {
  public static void testFunction() {
    int x = Opaque.opaqueMethod().subType.x;
  }
}
