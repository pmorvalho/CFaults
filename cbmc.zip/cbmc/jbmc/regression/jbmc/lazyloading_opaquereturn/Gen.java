public class Gen<T> {
  T t;
}
