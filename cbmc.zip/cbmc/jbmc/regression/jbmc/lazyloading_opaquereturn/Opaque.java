public class Opaque
{
  static Foo opaqueMethod() {
    return null;
  }
}
