public class Bar {
  public int x;

  public void cproverNondetInitialize() {

  }
}
