
public class Parent {

  // This is the version of Parent we will run jbmc against, which does
  // not have a static field 'x'.

}
