
public class Parent {

  // This is the version of Parent we compile Test.java against, which does
  // have a static field 'x'.
  public static int x;

}
