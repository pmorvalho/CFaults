public class TestGenTest
{
  public void f()
  {
    int a = 4;
    assert false;
  }
}
