
public class test {

  public static void main() {
    test t = (test)null;
  }

}
