public class classtest1
{
  public static void main(String[] args)
  {
    g(classtest1.class);
  }
  static void g(Object c)
  {
    assert true;
  }
}
