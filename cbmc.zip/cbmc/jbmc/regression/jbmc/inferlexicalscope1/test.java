public class test {

  public static void main() {

    int x = 5;
    if(x == 4) {
      int y = x + 1;
      ++y;
    }
    else {
      int z = x + 1;
      ++z;
    }

  }

}
