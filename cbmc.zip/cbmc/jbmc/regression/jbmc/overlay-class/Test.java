public class Test
{
  public int x;

  public static void main(String[] args)
  {
    assert(false);
  }

  public static void notOverlain()
  {
    assert(true);
  }
}
