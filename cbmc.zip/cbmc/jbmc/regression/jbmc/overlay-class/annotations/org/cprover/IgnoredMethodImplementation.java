package org.cprover;

/**
 * Ignored methods are documented above
 * `java_bytecode_convert_classt::is_ignored_method`.
 */
public @interface IgnoredMethodImplementation {
}
