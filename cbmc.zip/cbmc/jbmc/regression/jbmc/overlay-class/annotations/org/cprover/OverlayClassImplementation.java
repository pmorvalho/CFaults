package org.cprover;

/**
 * Overlay classes are documented above `is_overlay_class()` in
 * jbmc/src/java_bytecode/java_class_loader.cpp.
 */
public @interface OverlayClassImplementation {
}
