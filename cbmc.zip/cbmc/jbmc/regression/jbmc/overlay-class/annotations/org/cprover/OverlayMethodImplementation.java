package org.cprover;

/**
 * Overlay methods are documented above
 * `java_bytecode_convert_classt::is_overlay_method`.
 */
public @interface OverlayMethodImplementation {
}
