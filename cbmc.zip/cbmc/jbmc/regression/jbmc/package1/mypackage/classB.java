package mypackage;

public class classB
{
  public static int some_method() { return 123; }
};
