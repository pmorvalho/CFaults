import mypackage.*;

class classA
{
  public static void main(String[] args)
  {
    int result=classB.some_method();
    assert result==123;
  }
};
