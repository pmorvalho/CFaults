public class test {

    int x;
    int y;
    
    public test() { x = 1; y = 2; }
    public void setx(int _x) { x = _x; }
    public void sety(int _y) { y = _y; }
    public void sety(float _y) { y = (int)_y; }
    public void f() { }
    
}


