public class IrrelevantClass {

    public static void notImportant() {
        assert true;
    }

}
