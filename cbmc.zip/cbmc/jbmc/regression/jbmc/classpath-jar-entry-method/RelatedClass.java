public class RelatedClass {

    public int i;

}
