public class RelevantClass {

    public static void entry(RelatedClass rc) {
        assert false;
    }

}
