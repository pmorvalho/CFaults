package temp;

public class B extends A
{
  public int check()
  {
    return toint();
  }
}
