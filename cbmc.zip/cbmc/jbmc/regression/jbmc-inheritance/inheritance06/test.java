import temp.B;

public class test
{
  public void check()
  {
     B myObject = new B();
     assert(myObject.check()==123456);
  }
}

