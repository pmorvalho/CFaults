package temp;

class A
{
  int toint()
  {
    return 123456;
  }
}

