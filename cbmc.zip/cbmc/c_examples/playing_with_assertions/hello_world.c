#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(){
  char s[18];
  int sl=0;
  //memset(s, '\0', sizeof(s));
  char l1=strlen("Hello World!\n");
  strcpy(s, "Hello World!\n");
  sl+=l1;
  char l2=strlen("x2!\n");
  strcpy(s+sl, "x2!\n");
  sl+=l2;
  assert(strcmp(s, "Hello World!\nx2!\n")==0 && sl==17);
  return 0;
}
