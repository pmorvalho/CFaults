#include <stdio.h>
#include <assert.h>
#include <string.h>
int main() {
	int n1, n2, n3;
	char str[16];
	char str2[16]="3\n";
	//scanf("%d %d %d", &n1, &n2, &n3);
	n1=1,n2=2,n3=3;
	if ((n1 > n2) && (n1 > n3)) {
	  sprintf(str, "%d\n", n1);
	}
	else if ((n2 > n1) && (n2 > n3)) {
	  sprintf(str, "%d\n", n2);
	}
	else {
	  sprintf(str, "%d\n", n3);
	};
	printf("%s", str);
	//assert((str!="3\n") && (n3>n2 && n3> n1));
	//assert(strcmp(str,"3\n")==0);
	assert(str[0]=='3');	
	return 0;
}
