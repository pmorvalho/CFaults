#define __STDC_WANT_LIB_EXT2__ 1  //Define you want TR 24731-2:2010 extensions

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>
#include <string.h>

int __input__[1] = {5}, __i__=0, __offset__=0;
char __output__[1024];

void print(const char* format, ...)
{
    char* dest;
    va_list argptr;
    va_start(argptr, format);
    vasprintf(&dest, format, argptr);
    va_end(argptr);
    printf(dest);
    strcpy(__output__+__offset__, dest);
    __offset__+=strlen(dest);
    //free(dest);
}

void loop(int j, int l){
  while (l >= j){
    assert(j>=1 && j<=l && l==5);
    //printf("%d\n", j);
    print("%dooooo\n", j);
    ++j;
  }
}

int main(){
  int j=1, l;
  //scanf("%d", &l);
  l=__input__[__i__++];
  loop(j, l);
  printf("%s", __output__);
  assert(strcmp(__output__,"1\n2\n3\n4\n5\n")==0);
  return 0;
}
