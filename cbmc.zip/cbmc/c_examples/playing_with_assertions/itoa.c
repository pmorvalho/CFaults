#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to swap two numbers
void swap(char *x, char *y) {
    char t = *x; *x = *y; *y = t;
}
 
// Function to reverse `buffer[i…j]`
char* reverse(char *buffer, int i, int j)
{
    while (i < j) {
        swap(&buffer[i++], &buffer[j--]);
    }
 
    return buffer;
}
 
// Iterative function to implement `itoa()` function in C
char* itoa(int value, char* buffer, int base, int padding)
{
    // invalid input
    if (base < 2 || base > 32) {
        return buffer;
    }
 
    // consider the absolute value of the number
    int n = abs(value);
    //printf("N: %d\n",n);
    int i = 0, j=0;
    while (n)
    {
        int r = n % base;
 
        if (r >= 10) {
            buffer[i++] = 65 + (r - 10);
        }
        else {
            buffer[i++] = 48 + r;
        }
	//printf("%d\n", buffer[i-1]);
        n = n / base;
    }
 
    // if the number is 0
    if (i == 0) {
        buffer[i++] = '0';
    }
    for (j=i; j<padding; ){
       buffer[j++] = '0';
    }
    // If the base is 10 and the value is negative, the resulting string
    // is preceded with a minus sign (-)
    // With any other base, value is always considered unsigned
    if (value < 0 && base == 10) {
        buffer[i++] = '-';
    }
 
    buffer[padding] = '\0'; // null terminate string
 
    // reverse the string and return it
    return reverse(buffer, 0, padding-1);
}

int main() {
  int n,l,c;
  char str[1024];
  int str_i=0, i;
  int INT_PADDING=2;
  //scanf("%d", &n);
  n=3;
  for (l = 0; l < n; ++l) {
      for (c = 0; c < n; ++c) {
	if (c) {
	  //sprintf(str, '\t');
	  strcpy(str + str_i, "gg");
	  str_i+=strlen("\t");
	}	  
	itoa(l+c+1,str+str_i,10,INT_PADDING);
	str_i+=INT_PADDING;
      }
      strcpy(str + str_i, "\n");
      str_i+=strlen("\n");
  }
  str[str_i+1]='\0';
  //printf("%s", str);
  //fflush(stdout);
  assert(strcmp("01\t02\t03\n02\t03\t04\n03\t04\t05\n",str)==0);
  assert((0<=l && l<=n) && (0<=c && c<=n));
  return 0;
}
