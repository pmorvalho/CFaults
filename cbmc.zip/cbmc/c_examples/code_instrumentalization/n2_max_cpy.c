#include <stdbool.h>
#include <assert.h>

int main (){
   int n1, n2, n3, m;
   bool _l_1, _l_2_0, _l_2_1, _l_3, _l_4_0, _l_4_1, _l_5;
   n1=2,n2=3,n3=1;
   if (_l_1) m = n1;
   if((_l_2_1 && !_l_2_0) || (_l_2_0 && n2 < m))
   {
     if (_l_3) m = n1;
   }
   if((_l_4_1 && !_l_4_0) || (_l_4_0 && n3 < m))
   {
     if (_l_5) m = n3;
   }
   assert(m != 3);
   return 0;
}
