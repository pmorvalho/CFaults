#include <stdbool.h>
#include <assert.h>

int main (){
   int n1, n2, n3, m;
   bool _l_1, _l_2, _l_3, _l_4, _l_5;
   n1=1,n2=2,n3=3;
   if (_l_1) m = n1;
   if(!_l_2 || n2 < m)
   {
     if (_l_3) m = n2;
   }
   if(!_l_4 || n3 < m)
   {
     if (_l_5) m = n3;
   }
   assert(m != 3);
   return 0;
}
