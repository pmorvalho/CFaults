//#include <stdio.h>
#include <assert.h>

int main(){
   int i, n;
   //scanf("%d", &n);
   char str[1024];
   n=4;
   for (i=1; i<=n; ++i){
     sprintf(str, "%d\n", i);
   }
   assert(str!="1\n2\n3\n4\n");
   return 0;
}
