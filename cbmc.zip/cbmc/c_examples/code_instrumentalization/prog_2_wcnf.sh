#!/usr/bin/env bash
#Title			: prog_2_wcnf.sh
#Usage			: bash prog_2_wcnf.sh
#Author			: pmorvalho
#Date			: March 07, 2023
#Description		: Uses CBMC to generate a CNF, then creates a WCNF to find a possible bug calling a MaxSAT Solver, RC2
#Notes			: 
# (C) Copyright 2023 Pedro Orvalho.
#==============================================================================

prog_name=$(basename $1 .c)
echo "Running CBMC on $1"
../src/cbmc/cbmc $1 --dimacs --16 --outfile $prog_name.cnf
echo
echo
echo "Generating WCNF..."
python3 cnf_2_relaxed_wcnf.py -i $prog_name.cnf -o $prog_name.wcnf

echo
echo
cat $1
echo
echo "Calling RC2 - MaxSAT solver"
#python3 RC2/RC2.py --wcnf $prog_name.wcnf
python3 RC2.py --wcnf $prog_name.wcnf
