#include <stdbool.h>
#include <assert.h>

int main (){
  int n1, n2, m;
  bool _l_1, _l_2, _l_3;
  n1=2,n2=1;
  if (!_l_1 || n1 < n2){
     if (_l_2) m = n1;
  }
  else{
     if (_l_3)
       m = n2;
  }

   assert(m != 2);
   return 0;
}
