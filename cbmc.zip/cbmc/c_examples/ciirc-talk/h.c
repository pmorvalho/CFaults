#include "print_cbmc.h"
//#include "/home/pmorvalho/cbmc/src/ansi-c/library/stdlib.c"
//#include "/home/pmorvalho/cbmc/src/ansi-c/library/string.c"

void __CPROVER_printf(const char *format, ...);

int main()
{
  {
    //char __output_char__0[6] = "Hello";
    char __output_char__0[6];
    char str[6] = "He";
    int __output_offset_char__0 = 0;
    //    __output_offset_char__0 = print(__output_char__0, __output_offset_char__0, "Ola");
    __output_offset_char__0 = print(__output_char__0, __output_offset_char__0, "He");
    //__output_char__0[0] = "H";
    //strcpy(__output_char__0, str);
    // __output_char__0[0] = "H";
    //__CPROVER_printf("%s", __output_char__0);
    //printf("%s", __output_char__0);
    //    assert(strcmp(__output_char__0, "H") == 0);
    //assert(__output_char__0[0] == 'H');
    assert(strcmp(__output_char__0, str) == 0);    
    return 0;
  }
}
