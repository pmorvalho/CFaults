#include <assert.h>
#include <stdio.h>

int main(){
  int i = 1;
  for (; i < 20; i++) ;
  assert(i == 20);
  return 0;
}
