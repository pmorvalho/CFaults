#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>

void loop(int j, int l){
  while (l >= j){
    assert(1 <= j && j <= l);
    printf("%d\n", j);
    ++j;
  }
}

int main(){
  int j=1, l;
  scanf("%d", &l);
  loop(j, l);
  return 0;
}

