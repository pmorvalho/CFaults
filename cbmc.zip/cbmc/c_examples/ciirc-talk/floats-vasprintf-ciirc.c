#define __STDC_WANT_LIB_EXT2__ 1  //Define you want TR 24731-2:2010 extensions

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>
#include <string.h>


inline void *malloc(__CPROVER_size_t malloc_size)
{
  void *malloc_res;
  malloc_res = __CPROVER_allocate(malloc_size, 0);
  return malloc_res;
}

int print(char* str, int offset, const char* format, ...)
{
    char* dest;
    va_list argptr;
    va_start(argptr, format);
    vasprintf(&dest, format, argptr);
    va_end(argptr);
    printf(dest);
    strcpy(str+offset, dest);
    offset+=strlen(dest);
    //free(dest);
    return offset;
}

int main() {
  float min, max;
  float k;
  int n, i;
  char str[1024];
  //char* str;
  float input[5] = {4, 6.8, 2, 1, 0};
  int ii=0, str_i=0;
  n=input[ii++];
  max=input[ii++];
  min = max;
  for(i=1;i<n;++i) {
    k=input[ii++];
    if (k>max)
      max = k;
    if (k<min)
      min = k;
  }
  //vasprintf(&str, "min: %f, max: %f\n", min, max);
  str_i = print(str, str_i, " %f", min);
  str_i = print(str, str_i, " max: %f\n", max);
  printf("%s", str);
  fflush(stdout);
  assert(strcmp("min: 0.000000, max: 6.800000\n",str)==0 && 0<=i && i<=n && min==0.0f && max==6.8f);
  return 0;
}
