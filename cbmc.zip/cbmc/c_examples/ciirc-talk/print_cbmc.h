#define __STDC_WANT_LIB_EXT2__ 1  //Define you want TR 24731-2:2010 extensions

#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
#include <assert.h>
#include <stdarg.h>
#include <stdbool.h> 
#include "/home/pmorvalho/cbmc/src/ansi-c/library/stdlib.c"
#include "/home/pmorvalho/cbmc/src/ansi-c/library/string.c"
#include "/home/pmorvalho/cbmc/src/ansi-c/library/stdio.c"

/*
inline void *malloc(__CPROVER_size_t malloc_size)
{
  void *malloc_res;
  malloc_res = __CPROVER_allocate(malloc_size, 0);
  return malloc_res;
}

extern void free(void *ptr);
*/

/*
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "local.h"
int vsnprintf(char *str, size_t n, const char *fmt, __va_list ap)
{
	int ret;
	char dummy;
	FILE f;
	struct __sfileext fext;
	_FILEEXT_SETUP(&f, &fext);
	// While snprintf(3) specifies size_t stdio uses an int internally 
	if (n > INT_MAX)
		n = INT_MAX;
	// Stdio internals do not deal correctly with zero length buffer 
	if (n == 0) {
		str = &dummy;
		n = 1;
	}
	f._file = -1;
	f._flags = __SWR | __SSTR;
	f._bf._base = f._p = (unsigned char *)str;
	f._bf._size = f._w = n - 1;
	ret = __vfprintf(&f, fmt, ap);
	*f._p = '\0';
	return (ret);
}


int vasprintf(char **s, const char *fmt, va_list ap)
{
	va_list ap2;
	va_copy(ap2, ap);
	int l = vsnprintf(0, 0, fmt, ap2);
	va_end(ap2);

	if (l<0 || !(*s=malloc(l+1U))) return -1;
	return vsnprintf(*s, l+1U, fmt, ap);
}
*/
int print(char* str, int offset, const char* format, ...)
{
    char* dest = NULL;
    va_list argptr;
    va_start(argptr, format);
    assert(format[0] == "He");
    vasprintf(&dest, format, argptr);
    va_end(argptr);
    /* printf(dest); */
    strcpy(str+offset, dest);
    assert(dest[0] == "He");
    assert(str[0] == "He");
    offset+=strlen(dest);
    free(dest);
    return offset;
}
