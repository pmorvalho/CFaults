
#include "print_cbmc.h"

int main() {
  float min, max;
  float k;
  int n, i;
  char str[1024];
  //char* str;
  float input[5] = {4, 6.8, 2, 1, 0};
  int ii=0, str_i=0;
  n=input[ii++];
  max=input[ii++];
  min = max;
  for(i=1;i<n;++i) {
    k=input[ii++];
    if (k>max)
      max = k;
    if (k>min)
      min = k;
  }
  //vasprintf(&str, "min: %f, max: %f\n", min, max);
  //str_i = print(str, str_i, " %f", min);
  //str_i = print(str, str_i, " max: %f\n", max);
  str_i = print(str, str_i, "min: %f, max: %f\n", min, max);
  printf("%s", str);
  fflush(stdout);
  //assert(strcmp("min: 0.000000, max: 6.800000\n",str)==0 && 0<=i && i<=n && min==0.0f && max==6.8f);
  assert(strcmp("min: 0.000000, max: 6.800000\n",str)==0);
  return 0;
}
