

#include <stdio.h>

int leLinha(char s[]) {
    
}