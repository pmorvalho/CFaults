

#include <stdio.h>

#define VECMAX 100

int main() {
    int n, vet
}