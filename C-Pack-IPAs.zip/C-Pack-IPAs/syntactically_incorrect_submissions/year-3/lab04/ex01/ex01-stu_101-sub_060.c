


#include <stdio.h>

int main(){
    int n,valor;
    int vecmax[100];

    for(i=0;i<n;i++){
        vecmax[i] = scanf("%d",&valor);
    }
    vecmax[i]='\0';
    for(i=0;i<n;i++){
        for(i=0;i=vecmax[i];i++)
            printf('*');
    }
    return 0;
}
