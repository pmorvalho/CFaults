

#include <stdio.h>

int main(void) {

    #define VECMAX 100;
    int i, v, num, v[VECMAX];

    scanf("%d", num);
    


}