
#include <stdio.h>
#define VECMAX 100

int max(int vect_nums[], int n){
    int i,m = 0;
    for (i = 0; i < n, i++)
        if (v[i] > m)
            m = v[i];
    return m
}

int main(){
    int num_nums = 0;
    int i,j = 0;
    scanf("%d", num_nums);
    int vect_nums = [100];
    while (i++ < num_nums){
        scanf("%d", vect_nums[i]);
    int m = max(vect_nums,num_nums);
    for (i = 0; i < m, i++){
        for(j = 0, j < n, j++){
            putchar(v[j] > i ?"*":" ");
        putchar("\n")
        }
    }
    }
    return 0
}
