
#include <stdio.h>

int main() {
    int 

    return 0;
}