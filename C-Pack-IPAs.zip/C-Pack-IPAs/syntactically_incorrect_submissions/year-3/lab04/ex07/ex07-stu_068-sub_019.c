
#include <stdio.h>
#define MAX 100



void apagaCaracter(char s[], char c)