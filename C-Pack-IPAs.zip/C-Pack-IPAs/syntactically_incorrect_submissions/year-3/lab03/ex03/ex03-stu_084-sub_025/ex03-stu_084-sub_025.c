
#include <stdio.h>

void cruz(int N);

int main(){
    int N;
    scanf("%d", &N);
    cruz(N);
    return 0;
}

void cruz(int N){
    int i, j;
}
