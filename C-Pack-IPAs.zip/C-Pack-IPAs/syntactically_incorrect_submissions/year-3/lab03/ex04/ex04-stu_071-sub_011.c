
#include <stdio.h>

int main(){

long int n;
int i, c;
scanf("%d, &n");
c = getchar();
while ( c != EOF){
    c = getchar;
    if ( c =! ' ' ){
        c = getchar;
    }
    else print 


}








return 0;
}