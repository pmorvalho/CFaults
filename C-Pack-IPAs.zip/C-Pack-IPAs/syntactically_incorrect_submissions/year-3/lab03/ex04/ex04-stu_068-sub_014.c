
#include <stdio.h>

int main(){

    int c, zero_comeco = 0;
    
    
    

    while ((c = getchar())!= EOF ){
        
        if (c <= 9 && c >= 1){
         
    }

    
    
    
    
    
    return 0;

}