

#include <stdio.h>
#define DENTRO0 1
#define FORA0 0

int main(){
    int i, j;
    char c;
    
    while((c = getchar()) != EOF){
        
    }
}