
#include <stdio.h>
int main () {
    long int N;
    int fora;
    char c, d;
    c =  getchar();
    while (c != ' ' && c != '\n'){
        fora = 0;
        if (c == '0'){
            
            printf("%s", c);
        }
        else
            printf("%s", c);
        c = getchar();
    }
}