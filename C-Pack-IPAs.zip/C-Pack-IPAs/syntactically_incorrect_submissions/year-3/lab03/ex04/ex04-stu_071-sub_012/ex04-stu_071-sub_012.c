
#include <stdio.h>

int main(){

int i, c;
c = getchar();

while (c != EOF)






return 0;
}