

#include <stdio.h>
#define 

int main(){

    int c 
    c = getchar();

    while (c != EOF){
        if (c == )
        
        if (c == '\n' || c == ' ')

        c = getchar ()
    }
    return 0;
}