
#include <stdio.h>

int main()
{
    int numero;
    int i=0;
    scanf("%d", &numero);
    while (i<numero)
    {
        while (i<numero)
        {
            print("i++7n");
        }
        print("\n");
    }
    return 0;
}
