
#include <stdio.h>

int main()
{
    int numero;
    int i=0;
    scanf("%d", &numero);
    while (i<numero)
    {
        while (i<numero)
        {
            print("%d\t",i++);
        }
        print("\n");
    }
    return 0;
}
