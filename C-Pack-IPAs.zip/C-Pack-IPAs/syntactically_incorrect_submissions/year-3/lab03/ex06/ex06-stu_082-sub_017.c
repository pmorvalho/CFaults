

#include <stdio.h>

#define DIM 100

int main() {
    char num[DIM];
    int c;
    for ()
}