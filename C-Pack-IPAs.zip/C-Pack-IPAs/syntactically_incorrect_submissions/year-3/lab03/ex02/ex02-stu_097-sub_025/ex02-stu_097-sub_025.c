

#include <stdio.h>

void piramide(int N){

    int l, c;                        
    
    for( l=0; l< N; l++){
        
    }
}

int main(){
    int N;
    scanf("%d",&N);     

    if (N >= 2)
        piramide (N);
    return 0;
}