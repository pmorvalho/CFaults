
#include <stdio.h>
void piramide(int N){
    int l, c;
    for(l = 0; l <= N; l++){
        for(c = 0; c < N-l-1; c++){
            for(c = 0; c < l+1; c++){    
            }
            )
        }
    }
        
}    
int main () {
    int N = 0;
    while (N<2){
        scanf("%d", &N);
    }
    return 0;    
}