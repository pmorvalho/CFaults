

#include <stdio.h>



int auxiliar(){
    
}

int main(){
    char c;
    c = getchar();

    while (c != '\n'){
        if (c >='0' && c <='9')
            num = c -'0';

        if (c == ' '){
            c = getchar ();
            if (c == '+'){
                c = getchar();
                
            }
            if (c == '-'){


            }
            if ((c >='0' && c <='9')){
                num2 = c - '0';


            }
        c = getchar();
        }

    }

}