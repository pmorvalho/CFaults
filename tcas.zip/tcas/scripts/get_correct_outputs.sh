#!/usr/bin/env bash
#Title			: get_correct_outputs.sh
#Usage			: bash get_correct_outputs.sh
#Author			: pmorvalho
#Date			: November 07, 2023
#Description		: Run the correct program on each input
#Notes			: 
# (C) Copyright 2023 Pedro Orvalho.
#==============================================================================


for t in $(find ../inputs/t* -mindepth 0 -maxdepth 0 -type f);
do
    t_id=$(basename $t ".in")    
    echo ">>>>>>>>running test $t_id"
    ../source/tcas.exe  $(cat $t) > ../outputs/$t_id".out"
done

