echo script type: T
echo ">>>>>>>>running test 1"
../source/tcas.c.inst.exe  958 1 1 2597  574 4253 0  399  400 0 0 1     > ../newoutputs/t1
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/0.tr
echo ">>>>>>>>running test 2"
../source/tcas.c.inst.exe  627 0 0  621  216  382 1  400  641 1 1 0     > ../newoutputs/t2
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1.tr
echo ">>>>>>>>running test 3"
../source/tcas.c.inst.exe  549 1 1 4398  133 1445 1  641  639 0 0 1     > ../newoutputs/t3
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/2.tr
echo ">>>>>>>>running test 4"
../source/tcas.c.inst.exe  576 0 1 3469  183  381 2  641  501 1 0 1     > ../newoutputs/t4
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/3.tr
echo ">>>>>>>>running test 5"
../source/tcas.c.inst.exe  992 1 0 3342   23 4657 1  640  741 0 0 0     > ../newoutputs/t5
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/4.tr
echo ">>>>>>>>running test 6"
../source/tcas.c.inst.exe  548 0 1   34  542 3514 2  499  401 1 1 1     > ../newoutputs/t6
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/5.tr
echo ">>>>>>>>running test 7"
../source/tcas.c.inst.exe  710 0 0  127  403 4616 3  500  400 0 0 0     > ../newoutputs/t7
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/6.tr
echo ">>>>>>>>running test 8"
../source/tcas.c.inst.exe  638 0 1  698  499 2465 3  500  501 0 0 0     > ../newoutputs/t8
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/7.tr
echo ">>>>>>>>running test 9"
../source/tcas.c.inst.exe  893 1 0  205  283 5056 3  400  641 1 1 1     > ../newoutputs/t9
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/8.tr
echo ">>>>>>>>running test 10"
../source/tcas.c.inst.exe  976 1 1 5378  390 1000 2  641  741 1 0 0     > ../newoutputs/t10
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/9.tr
echo ">>>>>>>>running test 11"
../source/tcas.c.inst.exe  763 0 0  136  576 2305 0  401  741 0 0 0     > ../newoutputs/t11
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/10.tr
echo ">>>>>>>>running test 12"
../source/tcas.c.inst.exe  570 0 1 1945  376 2064 0  739  740 1 1 1     > ../newoutputs/t12
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/11.tr
echo ">>>>>>>>running test 13"
../source/tcas.c.inst.exe  967 1 0  659  204 3825 3  500  399 0 0 0     > ../newoutputs/t13
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/12.tr
echo ">>>>>>>>running test 14"
../source/tcas.c.inst.exe  892 0 1 2009   40 1011 1  641  740 1 1 0     > ../newoutputs/t14
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/13.tr
echo ">>>>>>>>running test 15"
../source/tcas.c.inst.exe  911 1 1 4194  242 4667 1  401  399 1 1 1     > ../newoutputs/t15
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/14.tr
echo ">>>>>>>>running test 16"
../source/tcas.c.inst.exe  929 0 1 1072  134 1036 1  741  639 1 1 0     > ../newoutputs/t16
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/15.tr
echo ">>>>>>>>running test 17"
../source/tcas.c.inst.exe  588 1 0 4341  336 2774 2  740  400 1 0 1     > ../newoutputs/t17
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/16.tr
echo ">>>>>>>>running test 18"
../source/tcas.c.inst.exe  963 0 0 5985  377  994 3  400  499 0 1 1     > ../newoutputs/t18
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/17.tr
echo ">>>>>>>>running test 19"
../source/tcas.c.inst.exe  699 1 1  619  432  912 2  740  639 0 1 0     > ../newoutputs/t19
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/18.tr
echo ">>>>>>>>running test 20"
../source/tcas.c.inst.exe  818 0 1 1876  318  793 1  499  501 1 0 0     > ../newoutputs/t20
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/19.tr
echo ">>>>>>>>running test 21"
../source/tcas.c.inst.exe  926 1 0 1694  263  651 2  501  499 1 0 0     > ../newoutputs/t21
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/20.tr
echo ">>>>>>>>running test 22"
../source/tcas.c.inst.exe  579 0 1  882  101 5381 0  639  499 0 1 0     > ../newoutputs/t22
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/21.tr
echo ">>>>>>>>running test 23"
../source/tcas.c.inst.exe  878 0 0 1063   86 4714 1  499  400 0 0 0     > ../newoutputs/t23
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/22.tr
echo ">>>>>>>>running test 24"
../source/tcas.c.inst.exe  822 0 1 1469  234 4419 1  399  399 1 1 1     > ../newoutputs/t24
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/23.tr
echo ">>>>>>>>running test 25"
../source/tcas.c.inst.exe  653 1 0  432   67  203 0  401  401 1 0 0     > ../newoutputs/t25
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/24.tr
echo ">>>>>>>>running test 26"
../source/tcas.c.inst.exe  601 1 1  777  424  309 1  641  401 0 1 1     > ../newoutputs/t26
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/25.tr
echo ">>>>>>>>running test 27"
../source/tcas.c.inst.exe  764 0 1 2969  491 2466 0  639  501 0 1 1     > ../newoutputs/t27
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/26.tr
echo ">>>>>>>>running test 28"
../source/tcas.c.inst.exe  594 1 1 2484  121 1193 2  500  740 0 0 1     > ../newoutputs/t28
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/27.tr
echo ">>>>>>>>running test 29"
../source/tcas.c.inst.exe  992 1 0 1793  517  254 0  739  500 1 1 1     > ../newoutputs/t29
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/28.tr
echo ">>>>>>>>running test 30"
../source/tcas.c.inst.exe  832 1 1 4454  148 4683 3  501  640 0 1 1     > ../newoutputs/t30
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/29.tr
echo ">>>>>>>>running test 31"
../source/tcas.c.inst.exe  882 0 1  674  444  191 3  741  740 1 0 0     > ../newoutputs/t31
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/30.tr
echo ">>>>>>>>running test 32"
../source/tcas.c.inst.exe  753 1 0 3203  448 1667 0  501  641 0 0 0     > ../newoutputs/t32
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/31.tr
echo ">>>>>>>>running test 33"
../source/tcas.c.inst.exe  953 1 1  682   24 2477 2  739  399 1 1 0     > ../newoutputs/t33
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/32.tr
echo ">>>>>>>>running test 34"
../source/tcas.c.inst.exe  588 1 0 3362   93 1315 3  741  639 1 0 1     > ../newoutputs/t34
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/33.tr
echo ">>>>>>>>running test 35"
../source/tcas.c.inst.exe  965 0 0 2078   76  303 1  401  640 0 1 1     > ../newoutputs/t35
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/34.tr
echo ">>>>>>>>running test 36"
../source/tcas.c.inst.exe  612 0 0 5073  510 1151 1  501  500 1 0 0     > ../newoutputs/t36
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/35.tr
echo ">>>>>>>>running test 37"
../source/tcas.c.inst.exe  783 1 0 4006  586 1219 0  501  740 0 1 1     > ../newoutputs/t37
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/36.tr
echo ">>>>>>>>running test 38"
../source/tcas.c.inst.exe  903 0 1 4075  608 5049 1  399  741 0 1 1     > ../newoutputs/t38
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/37.tr
echo ">>>>>>>>running test 39"
../source/tcas.c.inst.exe  888 0 0 2521  241  647 1  741  639 1 0 0     > ../newoutputs/t39
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/38.tr
echo ">>>>>>>>running test 40"
../source/tcas.c.inst.exe  971 0 1  183  524  747 2  400  401 1 1 1     > ../newoutputs/t40
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/39.tr
echo ">>>>>>>>running test 41"
../source/tcas.c.inst.exe  668 0 0 4507  418 4267 2  740  640 0 1 1     > ../newoutputs/t41
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/40.tr
echo ">>>>>>>>running test 42"
../source/tcas.c.inst.exe  731 0 0 2686  128  674 2  499  740 0 0 0     > ../newoutputs/t42
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/41.tr
echo ">>>>>>>>running test 43"
../source/tcas.c.inst.exe  935 0 0  121  179 2414 0  501  639 1 0 1     > ../newoutputs/t43
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/42.tr
echo ">>>>>>>>running test 44"
../source/tcas.c.inst.exe  952 1 1  802   26 3803 1  400  740 1 1 0     > ../newoutputs/t44
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/43.tr
echo ">>>>>>>>running test 45"
../source/tcas.c.inst.exe  673 1 0 2913   18 2294 3  400  641 0 1 0     > ../newoutputs/t45
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/44.tr
echo ">>>>>>>>running test 46"
../source/tcas.c.inst.exe  832 0 1  934    9 1145 2  399  401 0 1 1     > ../newoutputs/t46
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/45.tr
echo ">>>>>>>>running test 47"
../source/tcas.c.inst.exe  547 1 1 1723  236 2963 0  739  501 1 1 1     > ../newoutputs/t47
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/46.tr
echo ">>>>>>>>running test 48"
../source/tcas.c.inst.exe  799 0 1 5588  485  211 0  399  499 0 0 1     > ../newoutputs/t48
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/47.tr
echo ">>>>>>>>running test 49"
../source/tcas.c.inst.exe  711 0 0  201  181 2943 1  739  741 0 0 0     > ../newoutputs/t49
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/48.tr
echo ">>>>>>>>running test 50"
../source/tcas.c.inst.exe  987 0 0  813  318  888 3  641  400 1 0 0     > ../newoutputs/t50
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/49.tr
echo ">>>>>>>>running test 51"
../source/tcas.c.inst.exe  821 0 1  138   79  356 2  399  640 0 1 1     > ../newoutputs/t51
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/50.tr
echo ">>>>>>>>running test 52"
../source/tcas.c.inst.exe  528 1 0 5170   22  500 1  740  639 1 1 1     > ../newoutputs/t52
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/51.tr
echo ">>>>>>>>running test 53"
../source/tcas.c.inst.exe  896 1 1 5784  557  585 2  739  641 1 0 0     > ../newoutputs/t53
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/52.tr
echo ">>>>>>>>running test 54"
../source/tcas.c.inst.exe  546 0 1 1900  507 4846 1  501  641 0 1 1     > ../newoutputs/t54
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/53.tr
echo ">>>>>>>>running test 55"
../source/tcas.c.inst.exe  822 0 0  447  353 1740 2  399  639 0 0 1     > ../newoutputs/t55
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/54.tr
echo ">>>>>>>>running test 56"
../source/tcas.c.inst.exe  796 0 1  108   59  134 3  640  740 1 1 0     > ../newoutputs/t56
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/55.tr
echo ">>>>>>>>running test 57"
../source/tcas.c.inst.exe  775 1 1 2961  373 5279 3  640  499 0 1 0     > ../newoutputs/t57
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/56.tr
echo ">>>>>>>>running test 58"
../source/tcas.c.inst.exe  763 1 1 2635  387 4709 3  641  741 0 0 1     > ../newoutputs/t58
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/57.tr
echo ">>>>>>>>running test 59"
../source/tcas.c.inst.exe  568 1 1 3423   52 3011 3  499  640 0 1 1     > ../newoutputs/t59
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/58.tr
echo ">>>>>>>>running test 60"
../source/tcas.c.inst.exe  972 0 1 4644  495 4090 1  640  500 0 0 1     > ../newoutputs/t60
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/59.tr
echo ">>>>>>>>running test 61"
../source/tcas.c.inst.exe  562 0 0 1642   19  895 2  400  739 0 0 1     > ../newoutputs/t61
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/60.tr
echo ">>>>>>>>running test 62"
../source/tcas.c.inst.exe  804 0 1 3945   71  376 2  501  739 0 0 0     > ../newoutputs/t62
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/61.tr
echo ">>>>>>>>running test 63"
../source/tcas.c.inst.exe  610 0 1  282  158   14 3  500  499 1 1 0     > ../newoutputs/t63
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/62.tr
echo ">>>>>>>>running test 64"
../source/tcas.c.inst.exe  743 1 0  773  436  860 2  501  740 1 0 1     > ../newoutputs/t64
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/63.tr
echo ">>>>>>>>running test 65"
../source/tcas.c.inst.exe  947 1 0 1660  606 2279 3  739  500 1 0 0     > ../newoutputs/t65
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/64.tr
echo ">>>>>>>>running test 66"
../source/tcas.c.inst.exe  919 0 1  904  185 2680 0  641  401 0 0 0     > ../newoutputs/t66
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/65.tr
echo ">>>>>>>>running test 67"
../source/tcas.c.inst.exe  529 0 1 2376  616 4702 3  501  739 0 0 0     > ../newoutputs/t67
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/66.tr
echo ">>>>>>>>running test 68"
../source/tcas.c.inst.exe  632 0 1 1479  544 2213 1  499  641 1 0 0     > ../newoutputs/t68
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/67.tr
echo ">>>>>>>>running test 69"
../source/tcas.c.inst.exe  871 0 1 4564  133  362 1  499  400 0 0 0     > ../newoutputs/t69
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/68.tr
echo ">>>>>>>>running test 70"
../source/tcas.c.inst.exe  562 1 1 2836  195 5909 2  499  741 0 1 1     > ../newoutputs/t70
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/69.tr
echo ">>>>>>>>running test 71"
../source/tcas.c.inst.exe  610 0 1  135  539 5537 1  739  639 1 0 0     > ../newoutputs/t71
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/70.tr
echo ">>>>>>>>running test 72"
../source/tcas.c.inst.exe  867 1 1 1874  201 4704 0  499  499 1 0 1     > ../newoutputs/t72
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/71.tr
echo ">>>>>>>>running test 73"
../source/tcas.c.inst.exe  845 1 0  647  226 4212 2  501  499 0 0 1     > ../newoutputs/t73
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/72.tr
echo ">>>>>>>>running test 74"
../source/tcas.c.inst.exe  822 1 0 5034  541 2582 2  740  740 0 1 0     > ../newoutputs/t74
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/73.tr
echo ">>>>>>>>running test 75"
../source/tcas.c.inst.exe  769 0 1  903   91  233 3  399  740 1 1 0     > ../newoutputs/t75
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/74.tr
echo ">>>>>>>>running test 76"
../source/tcas.c.inst.exe  667 0 0 4200  562  645 3  640  739 1 0 1     > ../newoutputs/t76
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/75.tr
echo ">>>>>>>>running test 77"
../source/tcas.c.inst.exe  597 0 0 5459  555 2985 3  741  401 1 1 0     > ../newoutputs/t77
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/76.tr
echo ">>>>>>>>running test 78"
../source/tcas.c.inst.exe  959 1 1 1600  566 3684 1  641  740 0 0 1     > ../newoutputs/t78
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/77.tr
echo ">>>>>>>>running test 79"
../source/tcas.c.inst.exe  557 0 1 1365  369  241 0  500  401 0 0 0     > ../newoutputs/t79
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/78.tr
echo ">>>>>>>>running test 80"
../source/tcas.c.inst.exe  877 0 1 3749  566 3439 1  641  739 0 1 0     > ../newoutputs/t80
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/79.tr
echo ">>>>>>>>running test 81"
../source/tcas.c.inst.exe  637 1 1  486  588 3732 2  399  641 1 0 1     > ../newoutputs/t81
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/80.tr
echo ">>>>>>>>running test 82"
../source/tcas.c.inst.exe  950 1 1 1309    2 5510 3  740  639 1 0 0     > ../newoutputs/t82
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/81.tr
echo ">>>>>>>>running test 83"
../source/tcas.c.inst.exe  925 0 1  508  500 1124 3  740  740 1 0 1     > ../newoutputs/t83
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/82.tr
echo ">>>>>>>>running test 84"
../source/tcas.c.inst.exe  691 0 0 1625  534 5258 0  400  639 1 0 0     > ../newoutputs/t84
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/83.tr
echo ">>>>>>>>running test 85"
../source/tcas.c.inst.exe  833 1 1  927  145 2642 2  641  501 1 0 1     > ../newoutputs/t85
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/84.tr
echo ">>>>>>>>running test 86"
../source/tcas.c.inst.exe  804 0 1 1933  194 1176 0  640  639 1 0 0     > ../newoutputs/t86
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/85.tr
echo ">>>>>>>>running test 87"
../source/tcas.c.inst.exe  937 0 1 2358  298  524 1  740  741 1 1 1     > ../newoutputs/t87
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/86.tr
echo ">>>>>>>>running test 88"
../source/tcas.c.inst.exe  542 0 0   96  231 2100 2  400  741 1 0 0     > ../newoutputs/t88
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/87.tr
echo ">>>>>>>>running test 89"
../source/tcas.c.inst.exe  975 0 0 1371  238 1272 1  400  640 1 1 1     > ../newoutputs/t89
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/88.tr
echo ">>>>>>>>running test 90"
../source/tcas.c.inst.exe  690 0 0  173  231  681 1  499  741 1 1 1     > ../newoutputs/t90
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/89.tr
echo ">>>>>>>>running test 91"
../source/tcas.c.inst.exe  866 1 1 5987   18 2595 1  639  639 0 0 0     > ../newoutputs/t91
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/90.tr
echo ">>>>>>>>running test 92"
../source/tcas.c.inst.exe  915 0 0 1855   99 3443 2  401  740 0 0 1     > ../newoutputs/t92
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/91.tr
echo ">>>>>>>>running test 93"
../source/tcas.c.inst.exe  630 1 0 3335  578 2359 3  401  740 1 0 1     > ../newoutputs/t93
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/92.tr
echo ">>>>>>>>running test 94"
../source/tcas.c.inst.exe  843 1 1 1806  481 1209 3  640  500 1 1 1     > ../newoutputs/t94
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/93.tr
echo ">>>>>>>>running test 95"
../source/tcas.c.inst.exe  564 1 0  389  179  377 3  741  501 0 1 0     > ../newoutputs/t95
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/94.tr
echo ">>>>>>>>running test 96"
../source/tcas.c.inst.exe  685 1 1 4828  116  410 2  501  500 1 1 0     > ../newoutputs/t96
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/95.tr
echo ">>>>>>>>running test 97"
../source/tcas.c.inst.exe  716 0 0 1318   76   54 2  400  640 1 1 1     > ../newoutputs/t97
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/96.tr
echo ">>>>>>>>running test 98"
../source/tcas.c.inst.exe  624 1 0 3575  185 2668 2  501  639 0 1 1     > ../newoutputs/t98
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/97.tr
echo ">>>>>>>>running test 99"
../source/tcas.c.inst.exe  922 0 0 5533  587 5628 1  640  499 0 0 0     > ../newoutputs/t99
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/98.tr
echo ">>>>>>>>running test 100"
../source/tcas.c.inst.exe  651 1 0  270  517 5308 0  739  740 0 1 1     > ../newoutputs/t100
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/99.tr
echo ">>>>>>>>running test 101"
../source/tcas.c.inst.exe  931 0 0  472  619  702 3  639  740 0 0 1     > ../newoutputs/t101
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/100.tr
echo ">>>>>>>>running test 102"
../source/tcas.c.inst.exe  827 0 1 1691  437  776 1  641  399 1 0 1     > ../newoutputs/t102
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/101.tr
echo ">>>>>>>>running test 103"
../source/tcas.c.inst.exe  636 0 0 4210  340 4046 0  741  401 0 1 1     > ../newoutputs/t103
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/102.tr
echo ">>>>>>>>running test 104"
../source/tcas.c.inst.exe  838 1 0 5179  451 3128 2  399  740 1 0 0     > ../newoutputs/t104
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/103.tr
echo ">>>>>>>>running test 105"
../source/tcas.c.inst.exe  807 1 1 3747  344 2226 1  641  401 0 0 1     > ../newoutputs/t105
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/104.tr
echo ">>>>>>>>running test 106"
../source/tcas.c.inst.exe  953 1 1 5194  356 2325 3  501  401 1 1 0     > ../newoutputs/t106
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/105.tr
echo ">>>>>>>>running test 107"
../source/tcas.c.inst.exe  779 1 1 5328  619 4294 0  501  399 0 1 1     > ../newoutputs/t107
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/106.tr
echo ">>>>>>>>running test 108"
../source/tcas.c.inst.exe  932 0 1 2219  415  189 0  641  500 1 1 0     > ../newoutputs/t108
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/107.tr
echo ">>>>>>>>running test 109"
../source/tcas.c.inst.exe  969 1 0  691  510  603 1  740  399 1 1 1     > ../newoutputs/t109
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/108.tr
echo ">>>>>>>>running test 110"
../source/tcas.c.inst.exe  530 0 0  515   36  368 2  740  400 1 1 1     > ../newoutputs/t110
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/109.tr
echo ">>>>>>>>running test 111"
../source/tcas.c.inst.exe  940 1 1  203  198  885 0  499  500 0 0 0     > ../newoutputs/t111
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/110.tr
echo ">>>>>>>>running test 112"
../source/tcas.c.inst.exe  877 0 0  996  157 2459 1  501  740 1 1 0     > ../newoutputs/t112
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/111.tr
echo ">>>>>>>>running test 113"
../source/tcas.c.inst.exe  779 1 0 4175   94 5280 1  739  499 0 1 1     > ../newoutputs/t113
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/112.tr
echo ">>>>>>>>running test 114"
../source/tcas.c.inst.exe  753 1 0 5017   27 1162 3  740  640 1 0 0     > ../newoutputs/t114
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/113.tr
echo ">>>>>>>>running test 115"
../source/tcas.c.inst.exe  890 0 1 4178  598 5835 2  741  401 1 0 1     > ../newoutputs/t115
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/114.tr
echo ">>>>>>>>running test 116"
../source/tcas.c.inst.exe  969 1 1  375  228  986 0  499  499 1 1 1     > ../newoutputs/t116
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/115.tr
echo ">>>>>>>>running test 117"
../source/tcas.c.inst.exe  705 0 0 3770  607  499 1  401  399 0 0 0     > ../newoutputs/t117
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/116.tr
echo ">>>>>>>>running test 118"
../source/tcas.c.inst.exe  886 1 1 1380  305 2806 0  641  739 0 0 0     > ../newoutputs/t118
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/117.tr
echo ">>>>>>>>running test 119"
../source/tcas.c.inst.exe  833 0 0  981  545  739 0  499  399 1 0 0     > ../newoutputs/t119
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/118.tr
echo ">>>>>>>>running test 120"
../source/tcas.c.inst.exe  656 0 0  892  409 4552 1  399  639 0 1 1     > ../newoutputs/t120
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/119.tr
echo ">>>>>>>>running test 121"
../source/tcas.c.inst.exe  913 0 0   58   84 1982 1  739  500 1 1 1     > ../newoutputs/t121
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/120.tr
echo ">>>>>>>>running test 122"
../source/tcas.c.inst.exe  675 1 0  300  395 2397 2  501  639 0 1 1     > ../newoutputs/t122
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/121.tr
echo ">>>>>>>>running test 123"
../source/tcas.c.inst.exe  625 1 1 3344  560 3343 1  501  499 1 1 0     > ../newoutputs/t123
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/122.tr
echo ">>>>>>>>running test 124"
../source/tcas.c.inst.exe  750 0 0 5769   41  906 1  401  741 0 1 1     > ../newoutputs/t124
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/123.tr
echo ">>>>>>>>running test 125"
../source/tcas.c.inst.exe  817 1 0  973  245 3280 3  740  640 1 0 1     > ../newoutputs/t125
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/124.tr
echo ">>>>>>>>running test 126"
../source/tcas.c.inst.exe  651 0 1  982  211  394 3  500  741 0 0 0     > ../newoutputs/t126
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/125.tr
echo ">>>>>>>>running test 127"
../source/tcas.c.inst.exe  646 0 1 1598  269 5991 0  400  739 0 0 0     > ../newoutputs/t127
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/126.tr
echo ">>>>>>>>running test 128"
../source/tcas.c.inst.exe  670 1 1 1329  428 5569 1  399  740 1 1 1     > ../newoutputs/t128
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/127.tr
echo ">>>>>>>>running test 129"
../source/tcas.c.inst.exe  622 1 0 4421  180 1996 2  639  640 0 1 0     > ../newoutputs/t129
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/128.tr
echo ">>>>>>>>running test 130"
../source/tcas.c.inst.exe  548 1 1 4416  322 1952 0  739  500 0 0 0     > ../newoutputs/t130
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/129.tr
echo ">>>>>>>>running test 131"
../source/tcas.c.inst.exe  654 1 1 2133  113  442 3  641  741 0 0 0     > ../newoutputs/t131
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/130.tr
echo ">>>>>>>>running test 132"
../source/tcas.c.inst.exe  543 0 1 2857  188 2979 3  401  741 0 0 0     > ../newoutputs/t132
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/131.tr
echo ">>>>>>>>running test 133"
../source/tcas.c.inst.exe  845 1 0 2624  419 4353 1  400  641 1 1 1     > ../newoutputs/t133
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/132.tr
echo ">>>>>>>>running test 134"
../source/tcas.c.inst.exe  837 1 1 3649   52 3911 3  640  499 0 1 0     > ../newoutputs/t134
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/133.tr
echo ">>>>>>>>running test 135"
../source/tcas.c.inst.exe  812 1 0 2155  530 1846 2  640  739 0 1 1     > ../newoutputs/t135
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/134.tr
echo ">>>>>>>>running test 136"
../source/tcas.c.inst.exe  554 1 0 4534    6 1975 3  399  499 1 1 1     > ../newoutputs/t136
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/135.tr
echo ">>>>>>>>running test 137"
../source/tcas.c.inst.exe  888 1 0 3648  302  215 1  501  399 1 1 0     > ../newoutputs/t137
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/136.tr
echo ">>>>>>>>running test 138"
../source/tcas.c.inst.exe  702 1 1 3653  250  423 1  401  501 0 0 0     > ../newoutputs/t138
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/137.tr
echo ">>>>>>>>running test 139"
../source/tcas.c.inst.exe  774 1 1  551  433 2572 1  740  639 0 0 1     > ../newoutputs/t139
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/138.tr
echo ">>>>>>>>running test 140"
../source/tcas.c.inst.exe  594 1 1 5449  318 4116 1  400  501 1 1 1     > ../newoutputs/t140
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/139.tr
echo ">>>>>>>>running test 141"
../source/tcas.c.inst.exe  961 0 1  902  126 3531 1  740  500 1 0 0     > ../newoutputs/t141
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/140.tr
echo ">>>>>>>>running test 142"
../source/tcas.c.inst.exe  934 1 1 2743  366 5463 2  739  399 0 1 1     > ../newoutputs/t142
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/141.tr
echo ">>>>>>>>running test 143"
../source/tcas.c.inst.exe  533 0 0 5750  407 4328 2  641  400 1 1 1     > ../newoutputs/t143
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/142.tr
echo ">>>>>>>>running test 144"
../source/tcas.c.inst.exe  712 1 1 2545  341 4146 0  641  740 1 0 0     > ../newoutputs/t144
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/143.tr
echo ">>>>>>>>running test 145"
../source/tcas.c.inst.exe  780 0 0  702   12 4837 3  740  739 1 0 0     > ../newoutputs/t145
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/144.tr
echo ">>>>>>>>running test 146"
../source/tcas.c.inst.exe  861 1 1 2982  567 3850 3  400  401 1 0 1     > ../newoutputs/t146
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/145.tr
echo ">>>>>>>>running test 147"
../source/tcas.c.inst.exe  829 1 0 4012  389  818 1  401  400 0 1 1     > ../newoutputs/t147
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/146.tr
echo ">>>>>>>>running test 148"
../source/tcas.c.inst.exe  660 0 1 3874   28  726 1  400  401 1 1 0     > ../newoutputs/t148
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/147.tr
echo ">>>>>>>>running test 149"
../source/tcas.c.inst.exe  716 1 1 2749  240  993 3  401  739 0 1 0     > ../newoutputs/t149
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/148.tr
echo ">>>>>>>>running test 150"
../source/tcas.c.inst.exe  739 1 1  609   48 1187 1  741  639 1 1 1     > ../newoutputs/t150
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/149.tr
echo ">>>>>>>>running test 151"
../source/tcas.c.inst.exe  592 1 0 1045  226 4721 2  640  401 0 0 1     > ../newoutputs/t151
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/150.tr
echo ">>>>>>>>running test 152"
../source/tcas.c.inst.exe  833 0 0  678  405  963 2  400  739 1 0 1     > ../newoutputs/t152
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/151.tr
echo ">>>>>>>>running test 153"
../source/tcas.c.inst.exe  940 0 0  651  469 3461 2  639  400 0 1 0     > ../newoutputs/t153
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/152.tr
echo ">>>>>>>>running test 154"
../source/tcas.c.inst.exe  690 0 0  404  384  908 0  500  740 0 0 1     > ../newoutputs/t154
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/153.tr
echo ">>>>>>>>running test 155"
../source/tcas.c.inst.exe  757 1 1 3234  187 2853 3  401  500 0 1 1     > ../newoutputs/t155
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/154.tr
echo ">>>>>>>>running test 156"
../source/tcas.c.inst.exe  879 0 1  553  347 2553 1  639  400 0 0 1     > ../newoutputs/t156
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/155.tr
echo ">>>>>>>>running test 157"
../source/tcas.c.inst.exe  719 1 1 5010  438 4880 0  741  640 1 1 1     > ../newoutputs/t157
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/156.tr
echo ">>>>>>>>running test 158"
../source/tcas.c.inst.exe  690 1 1  380  577  239 0  641  640 0 1 1     > ../newoutputs/t158
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/157.tr
echo ">>>>>>>>running test 159"
../source/tcas.c.inst.exe  793 0 1  176   89 4431 0  740  399 1 0 0     > ../newoutputs/t159
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/158.tr
echo ">>>>>>>>running test 160"
../source/tcas.c.inst.exe  771 0 0 1054  289  282 3  400  641 0 0 1     > ../newoutputs/t160
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/159.tr
echo ">>>>>>>>running test 161"
../source/tcas.c.inst.exe  979 0 1  931  141   79 1  639  399 0 0 0     > ../newoutputs/t161
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/160.tr
echo ">>>>>>>>running test 162"
../source/tcas.c.inst.exe  858 0 1 3222  405  349 1  740  500 0 0 0     > ../newoutputs/t162
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/161.tr
echo ">>>>>>>>running test 163"
../source/tcas.c.inst.exe  918 1 0  818  542 1868 2  639  639 0 0 1     > ../newoutputs/t163
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/162.tr
echo ">>>>>>>>running test 164"
../source/tcas.c.inst.exe  741 1 1  966  413 2508 3  741  641 1 0 0     > ../newoutputs/t164
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/163.tr
echo ">>>>>>>>running test 165"
../source/tcas.c.inst.exe  990 1 1 3490  323  281 2  640  741 0 0 1     > ../newoutputs/t165
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/164.tr
echo ">>>>>>>>running test 166"
../source/tcas.c.inst.exe  536 0 1  927  423 2757 3  399  501 1 0 1     > ../newoutputs/t166
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/165.tr
echo ">>>>>>>>running test 167"
../source/tcas.c.inst.exe  927 1 0 4902  351 2093 0  739  740 1 0 0     > ../newoutputs/t167
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/166.tr
echo ">>>>>>>>running test 168"
../source/tcas.c.inst.exe  749 0 1 1037  384  703 3  400  740 1 1 1     > ../newoutputs/t168
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/167.tr
echo ">>>>>>>>running test 169"
../source/tcas.c.inst.exe  946 1 0 2345  180  170 2  399  400 0 1 0     > ../newoutputs/t169
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/168.tr
echo ">>>>>>>>running test 170"
../source/tcas.c.inst.exe  631 1 0 1569  330 1984 0  740  500 1 1 1     > ../newoutputs/t170
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/169.tr
echo ">>>>>>>>running test 171"
../source/tcas.c.inst.exe  550 1 1  489  113 1317 1  640  399 1 0 1     > ../newoutputs/t171
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/170.tr
echo ">>>>>>>>running test 172"
../source/tcas.c.inst.exe  641 0 1   41  422 4244 3  740  401 0 1 1     > ../newoutputs/t172
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/171.tr
echo ">>>>>>>>running test 173"
../source/tcas.c.inst.exe  700 0 1 1300  580 3798 2  639  741 1 1 0     > ../newoutputs/t173
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/172.tr
echo ">>>>>>>>running test 174"
../source/tcas.c.inst.exe  666 1 0  201  119 3080 2  399  640 1 0 0     > ../newoutputs/t174
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/173.tr
echo ">>>>>>>>running test 175"
../source/tcas.c.inst.exe  661 0 1 3235  287 2268 1  640  399 0 1 1     > ../newoutputs/t175
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/174.tr
echo ">>>>>>>>running test 176"
../source/tcas.c.inst.exe  826 0 0 3619  369 2109 1  741  639 0 1 1     > ../newoutputs/t176
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/175.tr
echo ">>>>>>>>running test 177"
../source/tcas.c.inst.exe  874 0 1  771    9 4043 1  500  639 1 1 1     > ../newoutputs/t177
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/176.tr
echo ">>>>>>>>running test 178"
../source/tcas.c.inst.exe  911 1 1 3373  346 1773 2  400  501 1 1 1     > ../newoutputs/t178
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/177.tr
echo ">>>>>>>>running test 179"
../source/tcas.c.inst.exe  749 0 1 2307  230 1594 1  741  740 1 0 1     > ../newoutputs/t179
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/178.tr
echo ">>>>>>>>running test 180"
../source/tcas.c.inst.exe  567 1 0 5621  399 3514 1  500  400 0 1 0     > ../newoutputs/t180
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/179.tr
echo ">>>>>>>>running test 181"
../source/tcas.c.inst.exe  635 1 0 5854  219  617 3  399  401 1 1 0     > ../newoutputs/t181
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/180.tr
echo ">>>>>>>>running test 182"
../source/tcas.c.inst.exe  897 1 1 1701  109 3438 1  641  401 0 1 0     > ../newoutputs/t182
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/181.tr
echo ">>>>>>>>running test 183"
../source/tcas.c.inst.exe  598 0 1 2589  130  629 3  399  500 0 0 1     > ../newoutputs/t183
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/182.tr
echo ">>>>>>>>running test 184"
../source/tcas.c.inst.exe  893 0 1 5001  301  711 2  400  739 1 0 0     > ../newoutputs/t184
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/183.tr
echo ">>>>>>>>running test 185"
../source/tcas.c.inst.exe  530 0 0 1564  583 4042 1  400  500 1 0 1     > ../newoutputs/t185
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/184.tr
echo ">>>>>>>>running test 186"
../source/tcas.c.inst.exe  854 0 0 5295  258  895 3  639  500 1 1 1     > ../newoutputs/t186
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/185.tr
echo ">>>>>>>>running test 187"
../source/tcas.c.inst.exe  550 1 0  968   10 5679 0  500  740 0 0 0     > ../newoutputs/t187
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/186.tr
echo ">>>>>>>>running test 188"
../source/tcas.c.inst.exe  828 1 0 4580  568 2638 0  740  639 0 1 0     > ../newoutputs/t188
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/187.tr
echo ">>>>>>>>running test 189"
../source/tcas.c.inst.exe  944 1 1 4283  251 3431 2  639  641 1 0 1     > ../newoutputs/t189
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/188.tr
echo ">>>>>>>>running test 190"
../source/tcas.c.inst.exe  768 0 0  889  193 4424 3  740  740 1 1 0     > ../newoutputs/t190
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/189.tr
echo ">>>>>>>>running test 191"
../source/tcas.c.inst.exe  857 0 1  574  409 3712 2  501  501 1 1 0     > ../newoutputs/t191
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/190.tr
echo ">>>>>>>>running test 192"
../source/tcas.c.inst.exe  659 1 0  781   18  271 3  399  499 1 0 1     > ../newoutputs/t192
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/191.tr
echo ">>>>>>>>running test 193"
../source/tcas.c.inst.exe  827 1 1 1935  339  968 0  399  740 0 1 1     > ../newoutputs/t193
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/192.tr
echo ">>>>>>>>running test 194"
../source/tcas.c.inst.exe  768 1 1 2197  496 5257 1  639  399 0 0 0     > ../newoutputs/t194
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/193.tr
echo ">>>>>>>>running test 195"
../source/tcas.c.inst.exe  684 1 1 5744  499  870 3  741  739 1 1 1     > ../newoutputs/t195
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/194.tr
echo ">>>>>>>>running test 196"
../source/tcas.c.inst.exe  722 1 0  201  343  665 1  639  499 1 1 0     > ../newoutputs/t196
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/195.tr
echo ">>>>>>>>running test 197"
../source/tcas.c.inst.exe  571 1 0  397  173 2247 2  641  499 1 0 1     > ../newoutputs/t197
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/196.tr
echo ">>>>>>>>running test 198"
../source/tcas.c.inst.exe  956 0 1 3698   70  717 3  399  499 1 0 1     > ../newoutputs/t198
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/197.tr
echo ">>>>>>>>running test 199"
../source/tcas.c.inst.exe  850 1 1 4146  473  899 1  740  500 1 0 0     > ../newoutputs/t199
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/198.tr
echo ">>>>>>>>running test 200"
../source/tcas.c.inst.exe  642 1 1 3494  125 2158 0  500  400 1 0 1     > ../newoutputs/t200
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/199.tr
echo ">>>>>>>>running test 201"
../source/tcas.c.inst.exe  628 1 0 2784    4 3034 3  399  399 1 0 0     > ../newoutputs/t201
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/200.tr
echo ">>>>>>>>running test 202"
../source/tcas.c.inst.exe  838 0 0 5849  266 1016 2  401  500 0 0 0     > ../newoutputs/t202
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/201.tr
echo ">>>>>>>>running test 203"
../source/tcas.c.inst.exe  824 1 1 1917   99  850 3  739  739 0 0 1     > ../newoutputs/t203
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/202.tr
echo ">>>>>>>>running test 204"
../source/tcas.c.inst.exe  686 0 0 1705  525 5369 1  641  401 0 1 0     > ../newoutputs/t204
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/203.tr
echo ">>>>>>>>running test 205"
../source/tcas.c.inst.exe  934 0 1  372  159 1322 1  401  639 1 1 0     > ../newoutputs/t205
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/204.tr
echo ">>>>>>>>running test 206"
../source/tcas.c.inst.exe  999 0 0 3577   27 4795 0  641  500 1 1 0     > ../newoutputs/t206
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/205.tr
echo ">>>>>>>>running test 207"
../source/tcas.c.inst.exe  738 0 1  573  548  268 3  499  741 1 1 0     > ../newoutputs/t207
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/206.tr
echo ">>>>>>>>running test 208"
../source/tcas.c.inst.exe  988 1 0 5692  580 4270 0  639  639 1 0 1     > ../newoutputs/t208
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/207.tr
echo ">>>>>>>>running test 209"
../source/tcas.c.inst.exe  762 0 0 1874  205 4933 3  399  641 1 0 1     > ../newoutputs/t209
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/208.tr
echo ">>>>>>>>running test 210"
../source/tcas.c.inst.exe  540 1 1  122  460 5776 2  640  740 1 0 1     > ../newoutputs/t210
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/209.tr
echo ">>>>>>>>running test 211"
../source/tcas.c.inst.exe  745 1 1 5728  191 2829 1  401  640 0 1 0     > ../newoutputs/t211
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/210.tr
echo ">>>>>>>>running test 212"
../source/tcas.c.inst.exe 1000 1 0  177  288 5884 3  401  640 0 0 1     > ../newoutputs/t212
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/211.tr
echo ">>>>>>>>running test 213"
../source/tcas.c.inst.exe  638 1 0 2578  156 3757 0  500  399 1 0 0     > ../newoutputs/t213
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/212.tr
echo ">>>>>>>>running test 214"
../source/tcas.c.inst.exe  919 0 1  131  300 3506 0  641  501 0 0 1     > ../newoutputs/t214
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/213.tr
echo ">>>>>>>>running test 215"
../source/tcas.c.inst.exe  874 0 0 5644  103 4207 3  399  740 1 0 0     > ../newoutputs/t215
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/214.tr
echo ">>>>>>>>running test 216"
../source/tcas.c.inst.exe  848 1 1 2141  138 2142 1  500  399 1 1 0     > ../newoutputs/t216
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/215.tr
echo ">>>>>>>>running test 217"
../source/tcas.c.inst.exe  910 1 0  427  162 2489 2  740  741 0 0 1     > ../newoutputs/t217
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/216.tr
echo ">>>>>>>>running test 218"
../source/tcas.c.inst.exe  838 1 0 2922  557  983 1  740  640 0 0 1     > ../newoutputs/t218
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/217.tr
echo ">>>>>>>>running test 219"
../source/tcas.c.inst.exe  913 0 1  452  437  263 1  741  741 1 1 1     > ../newoutputs/t219
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/218.tr
echo ">>>>>>>>running test 220"
../source/tcas.c.inst.exe  776 0 1  798  308 3693 0  400  741 0 0 0     > ../newoutputs/t220
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/219.tr
echo ">>>>>>>>running test 221"
../source/tcas.c.inst.exe  556 0 0 5915  151  482 2  400  739 1 0 0     > ../newoutputs/t221
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/220.tr
echo ">>>>>>>>running test 222"
../source/tcas.c.inst.exe  974 0 1  420  156 5924 0  741  400 0 0 1     > ../newoutputs/t222
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/221.tr
echo ">>>>>>>>running test 223"
../source/tcas.c.inst.exe  781 1 0  930  207 4163 1  639  399 0 0 0     > ../newoutputs/t223
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/222.tr
echo ">>>>>>>>running test 224"
../source/tcas.c.inst.exe  916 0 1 1828   43 3898 3  499  640 0 1 0     > ../newoutputs/t224
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/223.tr
echo ">>>>>>>>running test 225"
../source/tcas.c.inst.exe  813 0 0 1259   55  662 1  399  501 0 1 1     > ../newoutputs/t225
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/224.tr
echo ">>>>>>>>running test 226"
../source/tcas.c.inst.exe  822 0 0 1474   38 1377 3  641  640 1 0 0     > ../newoutputs/t226
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/225.tr
echo ">>>>>>>>running test 227"
../source/tcas.c.inst.exe  538 0 0  186  548 2387 0  739  639 0 0 0     > ../newoutputs/t227
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/226.tr
echo ">>>>>>>>running test 228"
../source/tcas.c.inst.exe  983 1 1 4732   69 1731 2  640  739 1 0 1     > ../newoutputs/t228
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/227.tr
echo ">>>>>>>>running test 229"
../source/tcas.c.inst.exe  685 1 0  117   74 5136 0  640  639 1 1 0     > ../newoutputs/t229
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/228.tr
echo ">>>>>>>>running test 230"
../source/tcas.c.inst.exe  660 1 1 4014  407  561 3  501  400 0 1 1     > ../newoutputs/t230
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/229.tr
echo ">>>>>>>>running test 231"
../source/tcas.c.inst.exe  535 0 0 1871   69 5220 2  500  641 0 1 1     > ../newoutputs/t231
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/230.tr
echo ">>>>>>>>running test 232"
../source/tcas.c.inst.exe  651 0 1  703  399   62 3  741  641 1 1 0     > ../newoutputs/t232
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/231.tr
echo ">>>>>>>>running test 233"
../source/tcas.c.inst.exe  868 0 0 2014  577 1420 1  740  401 1 0 0     > ../newoutputs/t233
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/232.tr
echo ">>>>>>>>running test 234"
../source/tcas.c.inst.exe  760 0 0  104  113 1610 3  741  401 1 0 1     > ../newoutputs/t234
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/233.tr
echo ">>>>>>>>running test 235"
../source/tcas.c.inst.exe  856 0 1 4927  182 3316 0  741  740 0 0 1     > ../newoutputs/t235
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/234.tr
echo ">>>>>>>>running test 236"
../source/tcas.c.inst.exe  874 0 0 3373  525 1643 2  399  641 1 1 0     > ../newoutputs/t236
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/235.tr
echo ">>>>>>>>running test 237"
../source/tcas.c.inst.exe  844 1 1 3839   76 2610 1  740  640 0 1 0     > ../newoutputs/t237
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/236.tr
echo ">>>>>>>>running test 238"
../source/tcas.c.inst.exe  782 1 1  263  499 1160 0  641  740 1 1 1     > ../newoutputs/t238
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/237.tr
echo ">>>>>>>>running test 239"
../source/tcas.c.inst.exe  679 0 0  279  453  454 1  641  499 0 0 1     > ../newoutputs/t239
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/238.tr
echo ">>>>>>>>running test 240"
../source/tcas.c.inst.exe  898 1 0 2193   11 2865 2  741  641 0 1 1     > ../newoutputs/t240
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/239.tr
echo ">>>>>>>>running test 241"
../source/tcas.c.inst.exe  878 1 0 2425  103  556 1  740  739 1 0 0     > ../newoutputs/t241
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/240.tr
echo ">>>>>>>>running test 242"
../source/tcas.c.inst.exe  743 1 0 1305  269  942 1  740  501 0 0 1     > ../newoutputs/t242
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/241.tr
echo ">>>>>>>>running test 243"
../source/tcas.c.inst.exe  953 0 1 2935  224 2070 3  499  641 0 1 0     > ../newoutputs/t243
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/242.tr
echo ">>>>>>>>running test 244"
../source/tcas.c.inst.exe  897 1 1 2226  306 3860 3  740  641 0 0 1     > ../newoutputs/t244
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/243.tr
echo ">>>>>>>>running test 245"
../source/tcas.c.inst.exe  733 0 1  367   18 1266 1  499  399 0 0 1     > ../newoutputs/t245
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/244.tr
echo ">>>>>>>>running test 246"
../source/tcas.c.inst.exe  643 1 1 5514  362 2288 1  400  741 1 1 0     > ../newoutputs/t246
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/245.tr
echo ">>>>>>>>running test 247"
../source/tcas.c.inst.exe  541 0 1 5231  502 1059 1  399  639 0 0 0     > ../newoutputs/t247
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/246.tr
echo ">>>>>>>>running test 248"
../source/tcas.c.inst.exe  598 0 0 3491  413 5933 3  741  401 0 0 0     > ../newoutputs/t248
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/247.tr
echo ">>>>>>>>running test 249"
../source/tcas.c.inst.exe  750 1 1  682  313 4253 2  499  740 0 0 1     > ../newoutputs/t249
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/248.tr
echo ">>>>>>>>running test 250"
../source/tcas.c.inst.exe  563 1 1 4688  587  773 3  640  639 0 0 0     > ../newoutputs/t250
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/249.tr
echo ">>>>>>>>running test 251"
../source/tcas.c.inst.exe  544 0 0 4467  603 5942 1  501  640 0 0 0     > ../newoutputs/t251
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/250.tr
echo ">>>>>>>>running test 252"
../source/tcas.c.inst.exe  661 1 1 1802  117 1355 3  400  499 0 1 0     > ../newoutputs/t252
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/251.tr
echo ">>>>>>>>running test 253"
../source/tcas.c.inst.exe  880 0 1  412  407  936 1  401  739 1 0 1     > ../newoutputs/t253
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/252.tr
echo ">>>>>>>>running test 254"
../source/tcas.c.inst.exe  832 0 0  375  147 2068 0  739  741 0 1 1     > ../newoutputs/t254
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/253.tr
echo ">>>>>>>>running test 255"
../source/tcas.c.inst.exe  751 1 1 1924  408 2617 0  639  640 1 1 1     > ../newoutputs/t255
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/254.tr
echo ">>>>>>>>running test 256"
../source/tcas.c.inst.exe  698 0 0  990  464 5856 3  640  501 1 0 0     > ../newoutputs/t256
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/255.tr
echo ">>>>>>>>running test 257"
../source/tcas.c.inst.exe  858 0 1 1894  242  772 3  400  639 0 1 0     > ../newoutputs/t257
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/256.tr
echo ">>>>>>>>running test 258"
../source/tcas.c.inst.exe  798 0 1 5229  263 1740 0  740  401 1 1 0     > ../newoutputs/t258
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/257.tr
echo ">>>>>>>>running test 259"
../source/tcas.c.inst.exe  710 1 1 5993  315  239 1  641  401 0 1 1     > ../newoutputs/t259
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/258.tr
echo ">>>>>>>>running test 260"
../source/tcas.c.inst.exe  743 1 1 3478  260 1672 1  400  499 1 0 0     > ../newoutputs/t260
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/259.tr
echo ">>>>>>>>running test 261"
../source/tcas.c.inst.exe  745 0 0 2069  495 3141 3  501  501 1 1 1     > ../newoutputs/t261
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/260.tr
echo ">>>>>>>>running test 262"
../source/tcas.c.inst.exe  865 0 1  796  147  444 0  499  400 1 1 1     > ../newoutputs/t262
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/261.tr
echo ">>>>>>>>running test 263"
../source/tcas.c.inst.exe  554 1 1 2815  476 1600 3  641  401 0 1 1     > ../newoutputs/t263
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/262.tr
echo ">>>>>>>>running test 264"
../source/tcas.c.inst.exe  536 0 0 3139  164 5669 1  399  501 0 0 1     > ../newoutputs/t264
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/263.tr
echo ">>>>>>>>running test 265"
../source/tcas.c.inst.exe  849 0 1 4435  344  969 3  399  401 0 1 0     > ../newoutputs/t265
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/264.tr
echo ">>>>>>>>running test 266"
../source/tcas.c.inst.exe  715 1 1 1085  409 1577 3  640  740 0 1 0     > ../newoutputs/t266
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/265.tr
echo ">>>>>>>>running test 267"
../source/tcas.c.inst.exe  726 1 0 1021  340 5644 2  641  399 0 0 0     > ../newoutputs/t267
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/266.tr
echo ">>>>>>>>running test 268"
../source/tcas.c.inst.exe  974 0 0 1091  325   69 3  501  741 1 0 0     > ../newoutputs/t268
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/267.tr
echo ">>>>>>>>running test 269"
../source/tcas.c.inst.exe  584 1 0  679   53  117 1  739  401 0 1 1     > ../newoutputs/t269
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/268.tr
echo ">>>>>>>>running test 270"
../source/tcas.c.inst.exe  998 1 0 2921  563  904 1  499  641 1 0 0     > ../newoutputs/t270
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/269.tr
echo ">>>>>>>>running test 271"
../source/tcas.c.inst.exe  786 1 0  383  548 5870 0  639  399 1 0 1     > ../newoutputs/t271
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/270.tr
echo ">>>>>>>>running test 272"
../source/tcas.c.inst.exe  809 0 0  108  413  343 3  401  399 1 0 1     > ../newoutputs/t272
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/271.tr
echo ">>>>>>>>running test 273"
../source/tcas.c.inst.exe  873 1 0 2763    4  208 3  741  401 0 0 1     > ../newoutputs/t273
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/272.tr
echo ">>>>>>>>running test 274"
../source/tcas.c.inst.exe  523 1 0 5002  473  909 3  499  501 0 0 0     > ../newoutputs/t274
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/273.tr
echo ">>>>>>>>running test 275"
../source/tcas.c.inst.exe  982 1 1  927  524 5556 2  500  501 1 1 1     > ../newoutputs/t275
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/274.tr
echo ">>>>>>>>running test 276"
../source/tcas.c.inst.exe  921 1 0 2049  162 1259 3  401  641 1 0 1     > ../newoutputs/t276
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/275.tr
echo ">>>>>>>>running test 277"
../source/tcas.c.inst.exe  679 1 1 3180  297 5750 3  739  400 0 0 0     > ../newoutputs/t277
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/276.tr
echo ">>>>>>>>running test 278"
../source/tcas.c.inst.exe  755 0 0 2949  565 2031 0  399  741 1 1 0     > ../newoutputs/t278
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/277.tr
echo ">>>>>>>>running test 279"
../source/tcas.c.inst.exe  643 0 1 1976  129  124 1  499  641 0 0 1     > ../newoutputs/t279
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/278.tr
echo ">>>>>>>>running test 280"
../source/tcas.c.inst.exe  815 0 0  836  295 1267 3  739  499 1 0 0     > ../newoutputs/t280
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/279.tr
echo ">>>>>>>>running test 281"
../source/tcas.c.inst.exe  677 1 0 4864  257 5470 1  501  399 0 1 0     > ../newoutputs/t281
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/280.tr
echo ">>>>>>>>running test 282"
../source/tcas.c.inst.exe  986 1 1 1534  145 2736 3  641  401 0 0 0     > ../newoutputs/t282
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/281.tr
echo ">>>>>>>>running test 283"
../source/tcas.c.inst.exe  841 1 1  670  226 4140 1  640  740 0 1 1     > ../newoutputs/t283
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/282.tr
echo ">>>>>>>>running test 284"
../source/tcas.c.inst.exe  960 0 1 5487  575 2958 0  400  500 1 0 1     > ../newoutputs/t284
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/283.tr
echo ">>>>>>>>running test 285"
../source/tcas.c.inst.exe  945 1 1 1426  406  555 2  401  739 1 1 0     > ../newoutputs/t285
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/284.tr
echo ">>>>>>>>running test 286"
../source/tcas.c.inst.exe  587 0 0 3575    5  815 0  639  739 1 1 0     > ../newoutputs/t286
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/285.tr
echo ">>>>>>>>running test 287"
../source/tcas.c.inst.exe  816 1 1 5118  231 4376 1  500  499 0 1 1     > ../newoutputs/t287
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/286.tr
echo ">>>>>>>>running test 288"
../source/tcas.c.inst.exe  772 1 1 2007  377  416 1  401  639 1 0 1     > ../newoutputs/t288
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/287.tr
echo ">>>>>>>>running test 289"
../source/tcas.c.inst.exe  802 0 1 3169  150 4244 2  739  400 0 0 1     > ../newoutputs/t289
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/288.tr
echo ">>>>>>>>running test 290"
../source/tcas.c.inst.exe  745 1 0   85  144 5206 3  401  499 1 0 0     > ../newoutputs/t290
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/289.tr
echo ">>>>>>>>running test 291"
../source/tcas.c.inst.exe  944 0 0 2065  348  818 2  640  739 0 1 0     > ../newoutputs/t291
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/290.tr
echo ">>>>>>>>running test 292"
../source/tcas.c.inst.exe  937 1 1 5273  326  878 1  640  641 1 1 1     > ../newoutputs/t292
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/291.tr
echo ">>>>>>>>running test 293"
../source/tcas.c.inst.exe  594 0 1  574  103  969 2  499  399 0 0 1     > ../newoutputs/t293
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/292.tr
echo ">>>>>>>>running test 294"
../source/tcas.c.inst.exe  725 1 1 2766  354 4811 3  641  501 1 1 0     > ../newoutputs/t294
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/293.tr
echo ">>>>>>>>running test 295"
../source/tcas.c.inst.exe  523 1 1  877  601 5608 1  639  400 0 0 0     > ../newoutputs/t295
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/294.tr
echo ">>>>>>>>running test 296"
../source/tcas.c.inst.exe  931 1 0 5113   72 3242 3  400  639 1 1 0     > ../newoutputs/t296
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/295.tr
echo ">>>>>>>>running test 297"
../source/tcas.c.inst.exe  716 1 0 5046  323 3839 1  639  500 0 1 0     > ../newoutputs/t297
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/296.tr
echo ">>>>>>>>running test 298"
../source/tcas.c.inst.exe  893 1 0 5078  256 3944 1  500  641 0 0 1     > ../newoutputs/t298
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/297.tr
echo ">>>>>>>>running test 299"
../source/tcas.c.inst.exe  819 0 0 3878  331 5704 3  740  499 1 1 0     > ../newoutputs/t299
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/298.tr
echo ">>>>>>>>running test 300"
../source/tcas.c.inst.exe  611 0 0 1509   98  667 3  739  399 1 1 1     > ../newoutputs/t300
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/299.tr
echo ">>>>>>>>running test 301"
../source/tcas.c.inst.exe  574 0 1 2060  111 2572 3  500  641 0 0 0     > ../newoutputs/t301
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/300.tr
echo ">>>>>>>>running test 302"
../source/tcas.c.inst.exe  989 1 0 1208   55 4201 2  499  400 1 1 1     > ../newoutputs/t302
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/301.tr
echo ">>>>>>>>running test 303"
../source/tcas.c.inst.exe  895 1 1  985  483 3388 2  501  400 1 0 0     > ../newoutputs/t303
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/302.tr
echo ">>>>>>>>running test 304"
../source/tcas.c.inst.exe  724 0 1 1495  597 5243 0  640  500 1 1 0     > ../newoutputs/t304
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/303.tr
echo ">>>>>>>>running test 305"
../source/tcas.c.inst.exe  932 1 1 3456  557  571 2  640  400 0 0 0     > ../newoutputs/t305
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/304.tr
echo ">>>>>>>>running test 306"
../source/tcas.c.inst.exe  521 1 0 1907  348 2633 0  499  501 0 1 0     > ../newoutputs/t306
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/305.tr
echo ">>>>>>>>running test 307"
../source/tcas.c.inst.exe  608 1 1  674  216  442 0  741  400 0 0 0     > ../newoutputs/t307
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/306.tr
echo ">>>>>>>>running test 308"
../source/tcas.c.inst.exe  589 0 1 3817  593  223 3  400  641 1 1 1     > ../newoutputs/t308
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/307.tr
echo ">>>>>>>>running test 309"
../source/tcas.c.inst.exe  841 0 1 3618  311 1559 1  400  739 1 0 1     > ../newoutputs/t309
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/308.tr
echo ">>>>>>>>running test 310"
../source/tcas.c.inst.exe  746 1 0  121  246  362 1  401  640 1 1 0     > ../newoutputs/t310
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/309.tr
echo ">>>>>>>>running test 311"
../source/tcas.c.inst.exe  628 1 0 5645  573 1477 2  501  399 1 1 0     > ../newoutputs/t311
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/310.tr
echo ">>>>>>>>running test 312"
../source/tcas.c.inst.exe  845 1 0  805  521  374 3  499  740 1 0 1     > ../newoutputs/t312
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/311.tr
echo ">>>>>>>>running test 313"
../source/tcas.c.inst.exe  690 0 1 4135  106 3520 1  499  639 1 0 1     > ../newoutputs/t313
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/312.tr
echo ">>>>>>>>running test 314"
../source/tcas.c.inst.exe  548 1 1 2625  249 1679 0  641  501 1 1 1     > ../newoutputs/t314
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/313.tr
echo ">>>>>>>>running test 315"
../source/tcas.c.inst.exe  763 0 0  907  444 1881 0  741  399 0 0 1     > ../newoutputs/t315
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/314.tr
echo ">>>>>>>>running test 316"
../source/tcas.c.inst.exe  750 1 1 1730  298   60 0  640  500 0 0 0     > ../newoutputs/t316
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/315.tr
echo ">>>>>>>>running test 317"
../source/tcas.c.inst.exe  653 1 0 1707  280 3904 3  501  740 0 0 1     > ../newoutputs/t317
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/316.tr
echo ">>>>>>>>running test 318"
../source/tcas.c.inst.exe  697 0 0  539  241 2597 3  640  741 0 1 0     > ../newoutputs/t318
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/317.tr
echo ">>>>>>>>running test 319"
../source/tcas.c.inst.exe  556 1 1  351    9  281 3  741  639 0 0 1     > ../newoutputs/t319
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/318.tr
echo ">>>>>>>>running test 320"
../source/tcas.c.inst.exe  789 0 0 3283  354 1116 2  640  400 0 0 0     > ../newoutputs/t320
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/319.tr
echo ">>>>>>>>running test 321"
../source/tcas.c.inst.exe  717 0 0 3436  374 1439 2  640  740 1 1 0     > ../newoutputs/t321
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/320.tr
echo ">>>>>>>>running test 322"
../source/tcas.c.inst.exe  596 0 0 5238  574  857 3  739  501 1 1 0     > ../newoutputs/t322
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/321.tr
echo ">>>>>>>>running test 323"
../source/tcas.c.inst.exe  767 0 1 2316  399 3575 0  499  501 0 1 1     > ../newoutputs/t323
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/322.tr
echo ">>>>>>>>running test 324"
../source/tcas.c.inst.exe  806 1 0 2197  495 5711 0  401  739 0 0 1     > ../newoutputs/t324
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/323.tr
echo ">>>>>>>>running test 325"
../source/tcas.c.inst.exe  593 0 1  765  481 3711 0  500  641 1 0 1     > ../newoutputs/t325
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/324.tr
echo ">>>>>>>>running test 326"
../source/tcas.c.inst.exe  955 0 1 1836  542 3698 3  500  401 1 0 0     > ../newoutputs/t326
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/325.tr
echo ">>>>>>>>running test 327"
../source/tcas.c.inst.exe  622 1 1 3661   13  223 1  499  739 0 1 0     > ../newoutputs/t327
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/326.tr
echo ">>>>>>>>running test 328"
../source/tcas.c.inst.exe  719 0 0 5273  196 3585 1  740  740 1 1 1     > ../newoutputs/t328
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/327.tr
echo ">>>>>>>>running test 329"
../source/tcas.c.inst.exe  772 0 1 3773   87 4375 1  639  400 1 0 1     > ../newoutputs/t329
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/328.tr
echo ">>>>>>>>running test 330"
../source/tcas.c.inst.exe  612 1 0 4829    4  200 1  399  500 1 1 1     > ../newoutputs/t330
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/329.tr
echo ">>>>>>>>running test 331"
../source/tcas.c.inst.exe  694 1 1 3238   81 1642 1  500  739 0 0 0     > ../newoutputs/t331
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/330.tr
echo ">>>>>>>>running test 332"
../source/tcas.c.inst.exe  564 0 0  417  556 3138 0  741  639 1 0 0     > ../newoutputs/t332
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/331.tr
echo ">>>>>>>>running test 333"
../source/tcas.c.inst.exe  994 0 0 3682  579   39 0  400  740 1 1 1     > ../newoutputs/t333
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/332.tr
echo ">>>>>>>>running test 334"
../source/tcas.c.inst.exe  689 1 0 5258  331 1464 2  640  501 0 1 1     > ../newoutputs/t334
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/333.tr
echo ">>>>>>>>running test 335"
../source/tcas.c.inst.exe  971 1 0  383  189 4986 3  739  501 0 0 0     > ../newoutputs/t335
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/334.tr
echo ">>>>>>>>running test 336"
../source/tcas.c.inst.exe  775 0 1  865  102 2303 3  401  401 1 1 1     > ../newoutputs/t336
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/335.tr
echo ">>>>>>>>running test 337"
../source/tcas.c.inst.exe  612 0 1 3691  242  485 1  401  500 1 0 0     > ../newoutputs/t337
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/336.tr
echo ">>>>>>>>running test 338"
../source/tcas.c.inst.exe  980 1 1  904  214 2419 1  400  641 1 0 1     > ../newoutputs/t338
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/337.tr
echo ">>>>>>>>running test 339"
../source/tcas.c.inst.exe  785 1 0 2740  421  162 3  741  741 1 0 0     > ../newoutputs/t339
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/338.tr
echo ">>>>>>>>running test 340"
../source/tcas.c.inst.exe  546 0 0 2569  544 2947 0  399  640 1 0 1     > ../newoutputs/t340
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/339.tr
echo ">>>>>>>>running test 341"
../source/tcas.c.inst.exe  886 0 0 2059  459  274 1  401  641 1 1 1     > ../newoutputs/t341
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/340.tr
echo ">>>>>>>>running test 342"
../source/tcas.c.inst.exe  889 0 0 3799  100 4302 1  499  640 1 0 1     > ../newoutputs/t342
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/341.tr
echo ">>>>>>>>running test 343"
../source/tcas.c.inst.exe  698 1 1 4165  477 5526 2  641  500 1 1 0     > ../newoutputs/t343
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/342.tr
echo ">>>>>>>>running test 344"
../source/tcas.c.inst.exe  644 0 1 2518  298  896 2  401  500 1 0 1     > ../newoutputs/t344
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/343.tr
echo ">>>>>>>>running test 345"
../source/tcas.c.inst.exe  843 0 1 1935    2 4489 0  499  401 0 0 0     > ../newoutputs/t345
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/344.tr
echo ">>>>>>>>running test 346"
../source/tcas.c.inst.exe  577 1 1 2046  389  495 0  740  501 0 1 1     > ../newoutputs/t346
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/345.tr
echo ">>>>>>>>running test 347"
../source/tcas.c.inst.exe  856 1 1 2716  320 1742 2  641  401 1 1 0     > ../newoutputs/t347
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/346.tr
echo ">>>>>>>>running test 348"
../source/tcas.c.inst.exe  900 1 0 3346  507  663 2  640  639 0 0 1     > ../newoutputs/t348
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/347.tr
echo ">>>>>>>>running test 349"
../source/tcas.c.inst.exe  995 0 1 3499   70 1262 1  640  399 0 0 0     > ../newoutputs/t349
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/348.tr
echo ">>>>>>>>running test 350"
../source/tcas.c.inst.exe  656 0 1 4956  595 2307 2  501  741 0 0 1     > ../newoutputs/t350
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/349.tr
echo ">>>>>>>>running test 351"
../source/tcas.c.inst.exe  878 0 1 4939  250 1842 2  640  400 1 0 0     > ../newoutputs/t351
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/350.tr
echo ">>>>>>>>running test 352"
../source/tcas.c.inst.exe  591 1 1 1124  287 2790 2  640  501 1 1 1     > ../newoutputs/t352
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/351.tr
echo ">>>>>>>>running test 353"
../source/tcas.c.inst.exe  785 0 1 2802  447 2187 1  400  740 1 1 1     > ../newoutputs/t353
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/352.tr
echo ">>>>>>>>running test 354"
../source/tcas.c.inst.exe  904 1 1 2361  527  419 2  401  400 1 1 1     > ../newoutputs/t354
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/353.tr
echo ">>>>>>>>running test 355"
../source/tcas.c.inst.exe  619 1 0  197  287 4568 2  500  499 0 0 1     > ../newoutputs/t355
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/354.tr
echo ">>>>>>>>running test 356"
../source/tcas.c.inst.exe  928 1 1  380  232 5117 1  740  499 0 0 0     > ../newoutputs/t356
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/355.tr
echo ">>>>>>>>running test 357"
../source/tcas.c.inst.exe  860 1 1  602  331 5657 3  639  740 1 1 0     > ../newoutputs/t357
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/356.tr
echo ">>>>>>>>running test 358"
../source/tcas.c.inst.exe  661 0 0  767   26 5316 3  640  399 0 1 1     > ../newoutputs/t358
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/357.tr
echo ">>>>>>>>running test 359"
../source/tcas.c.inst.exe  534 1 0 5360  149 1528 3  740  499 1 1 0     > ../newoutputs/t359
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/358.tr
echo ">>>>>>>>running test 360"
../source/tcas.c.inst.exe  774 1 1 1231  234   61 2  400  500 1 1 1     > ../newoutputs/t360
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/359.tr
echo ">>>>>>>>running test 361"
../source/tcas.c.inst.exe  804 0 1 3514  152 1152 1  740  501 1 1 1     > ../newoutputs/t361
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/360.tr
echo ">>>>>>>>running test 362"
../source/tcas.c.inst.exe  887 0 0 1725  477 2346 2  741  739 1 0 0     > ../newoutputs/t362
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/361.tr
echo ">>>>>>>>running test 363"
../source/tcas.c.inst.exe  808 1 1  946  546  661 1  400  640 0 1 0     > ../newoutputs/t363
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/362.tr
echo ">>>>>>>>running test 364"
../source/tcas.c.inst.exe  800 1 0 2067  586  284 3  740  499 0 0 1     > ../newoutputs/t364
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/363.tr
echo ">>>>>>>>running test 365"
../source/tcas.c.inst.exe  811 0 0 2117  222 3074 3  501  399 1 0 1     > ../newoutputs/t365
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/364.tr
echo ">>>>>>>>running test 366"
../source/tcas.c.inst.exe  661 0 0  963  177 5207 3  499  400 1 0 0     > ../newoutputs/t366
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/365.tr
echo ">>>>>>>>running test 367"
../source/tcas.c.inst.exe  995 0 0 2133  218  905 1  501  501 0 0 1     > ../newoutputs/t367
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/366.tr
echo ">>>>>>>>running test 368"
../source/tcas.c.inst.exe  788 0 0  113  177 2105 2  501  741 0 1 1     > ../newoutputs/t368
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/367.tr
echo ">>>>>>>>running test 369"
../source/tcas.c.inst.exe  906 0 0 4284  439  111 2  740  740 0 1 1     > ../newoutputs/t369
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/368.tr
echo ">>>>>>>>running test 370"
../source/tcas.c.inst.exe  537 0 1 1397  427 1241 1  739  740 0 1 0     > ../newoutputs/t370
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/369.tr
echo ">>>>>>>>running test 371"
../source/tcas.c.inst.exe  876 1 1  508  401  271 0  401  400 1 0 0     > ../newoutputs/t371
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/370.tr
echo ">>>>>>>>running test 372"
../source/tcas.c.inst.exe  548 1 0 2001  399  523 0  741  739 0 0 0     > ../newoutputs/t372
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/371.tr
echo ">>>>>>>>running test 373"
../source/tcas.c.inst.exe  801 0 1 5536  450  504 2  741  740 0 0 1     > ../newoutputs/t373
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/372.tr
echo ">>>>>>>>running test 374"
../source/tcas.c.inst.exe  921 0 1 2166  315 3826 0  739  500 1 1 1     > ../newoutputs/t374
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/373.tr
echo ">>>>>>>>running test 375"
../source/tcas.c.inst.exe  958 0 0 1971  138 4932 2  400  640 0 0 1     > ../newoutputs/t375
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/374.tr
echo ">>>>>>>>running test 376"
../source/tcas.c.inst.exe  661 1 1   23  469 2852 1  400  500 1 1 1     > ../newoutputs/t376
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/375.tr
echo ">>>>>>>>running test 377"
../source/tcas.c.inst.exe  878 0 1 5906  588 3803 2  499  399 0 0 1     > ../newoutputs/t377
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/376.tr
echo ">>>>>>>>running test 378"
../source/tcas.c.inst.exe  664 1 0 3757   24 2579 1  499  739 0 1 1     > ../newoutputs/t378
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/377.tr
echo ">>>>>>>>running test 379"
../source/tcas.c.inst.exe  564 1 0  463  166  199 2  500  640 1 1 0     > ../newoutputs/t379
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/378.tr
echo ">>>>>>>>running test 380"
../source/tcas.c.inst.exe  787 0 1 3296  306  326 3  741  639 1 1 0     > ../newoutputs/t380
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/379.tr
echo ">>>>>>>>running test 381"
../source/tcas.c.inst.exe  843 0 1  154  327 2365 0  640  499 0 0 0     > ../newoutputs/t381
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/380.tr
echo ">>>>>>>>running test 382"
../source/tcas.c.inst.exe  669 1 0  287  436 2803 3  740  400 1 1 1     > ../newoutputs/t382
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/381.tr
echo ">>>>>>>>running test 383"
../source/tcas.c.inst.exe  734 0 0 2049  280 5472 0  399  499 0 0 0     > ../newoutputs/t383
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/382.tr
echo ">>>>>>>>running test 384"
../source/tcas.c.inst.exe  578 1 0 1170  526 4785 1  399  741 1 0 1     > ../newoutputs/t384
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/383.tr
echo ">>>>>>>>running test 385"
../source/tcas.c.inst.exe  541 1 0 3553  365  687 0  400  741 1 1 0     > ../newoutputs/t385
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/384.tr
echo ">>>>>>>>running test 386"
../source/tcas.c.inst.exe  530 0 1  129  519 1555 1  501  640 0 1 0     > ../newoutputs/t386
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/385.tr
echo ">>>>>>>>running test 387"
../source/tcas.c.inst.exe  847 0 1 2379  193 4481 0  641  741 0 0 0     > ../newoutputs/t387
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/386.tr
echo ">>>>>>>>running test 388"
../source/tcas.c.inst.exe  867 1 1 1211  581  153 2  640  641 1 1 1     > ../newoutputs/t388
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/387.tr
echo ">>>>>>>>running test 389"
../source/tcas.c.inst.exe  607 1 1 4250   14 4883 2  399  641 1 0 0     > ../newoutputs/t389
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/388.tr
echo ">>>>>>>>running test 390"
../source/tcas.c.inst.exe  558 0 1   84  275 4457 1  501  401 1 0 1     > ../newoutputs/t390
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/389.tr
echo ">>>>>>>>running test 391"
../source/tcas.c.inst.exe  526 0 1  751  595 2071 3  400  641 1 0 0     > ../newoutputs/t391
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/390.tr
echo ">>>>>>>>running test 392"
../source/tcas.c.inst.exe  745 0 1  730  516  245 1  641  399 1 1 0     > ../newoutputs/t392
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/391.tr
echo ">>>>>>>>running test 393"
../source/tcas.c.inst.exe  812 1 0 4165   80  690 0  741  401 0 1 1     > ../newoutputs/t393
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/392.tr
echo ">>>>>>>>running test 394"
../source/tcas.c.inst.exe  785 0 1 4931  240  554 2  499  400 0 1 1     > ../newoutputs/t394
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/393.tr
echo ">>>>>>>>running test 395"
../source/tcas.c.inst.exe  540 1 0  672  233    7 0  641  399 1 0 0     > ../newoutputs/t395
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/394.tr
echo ">>>>>>>>running test 396"
../source/tcas.c.inst.exe  756 0 1  562  415 3339 2  640  640 0 0 0     > ../newoutputs/t396
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/395.tr
echo ">>>>>>>>running test 397"
../source/tcas.c.inst.exe  695 0 1   55  100 2038 1  499  401 0 0 0     > ../newoutputs/t397
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/396.tr
echo ">>>>>>>>running test 398"
../source/tcas.c.inst.exe  559 1 1 1883  613 4507 2  640  500 1 1 1     > ../newoutputs/t398
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/397.tr
echo ">>>>>>>>running test 399"
../source/tcas.c.inst.exe  676 1 0  566  287 5295 2  399  500 1 1 1     > ../newoutputs/t399
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/398.tr
echo ">>>>>>>>running test 400"
../source/tcas.c.inst.exe  571 0 0 3403  576  850 1  741  500 1 0 0     > ../newoutputs/t400
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/399.tr
echo ">>>>>>>>running test 401"
../source/tcas.c.inst.exe  831 0 1  468  108 3882 1  500  399 0 1 0     > ../newoutputs/t401
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/400.tr
echo ">>>>>>>>running test 402"
../source/tcas.c.inst.exe  794 1 1  562  577 2901 2  499  401 0 0 1     > ../newoutputs/t402
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/401.tr
echo ">>>>>>>>running test 403"
../source/tcas.c.inst.exe  680 0 0  505   44  186 1  739  741 0 1 0     > ../newoutputs/t403
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/402.tr
echo ">>>>>>>>running test 404"
../source/tcas.c.inst.exe  924 0 0 1568   86  533 0  739  499 1 1 0     > ../newoutputs/t404
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/403.tr
echo ">>>>>>>>running test 405"
../source/tcas.c.inst.exe  833 1 0 4117  424 2255 1  501  401 1 0 0     > ../newoutputs/t405
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/404.tr
echo ">>>>>>>>running test 406"
../source/tcas.c.inst.exe  759 0 0 1552  265 4793 0  641  640 1 0 0     > ../newoutputs/t406
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/405.tr
echo ">>>>>>>>running test 407"
../source/tcas.c.inst.exe  973 0 0 1209  444 4409 2  399  641 1 0 0     > ../newoutputs/t407
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/406.tr
echo ">>>>>>>>running test 408"
../source/tcas.c.inst.exe  739 1 1 5287  252  632 1  740  639 1 0 1     > ../newoutputs/t408
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/407.tr
echo ">>>>>>>>running test 409"
../source/tcas.c.inst.exe  912 0 0 2658  192 3449 3  399  401 0 1 0     > ../newoutputs/t409
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/408.tr
echo ">>>>>>>>running test 410"
../source/tcas.c.inst.exe  750 0 0 5376  523 2611 2  500  639 0 0 0     > ../newoutputs/t410
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/409.tr
echo ">>>>>>>>running test 411"
../source/tcas.c.inst.exe  953 0 1 1508  132  672 3  499  499 0 1 0     > ../newoutputs/t411
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/410.tr
echo ">>>>>>>>running test 412"
../source/tcas.c.inst.exe  782 1 1  513  224 5295 0  641  639 0 1 0     > ../newoutputs/t412
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/411.tr
echo ">>>>>>>>running test 413"
../source/tcas.c.inst.exe  722 1 1 1415  245  316 0  401  739 0 0 1     > ../newoutputs/t413
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/412.tr
echo ">>>>>>>>running test 414"
../source/tcas.c.inst.exe  836 1 0 4086  407  308 2  499  400 0 1 0     > ../newoutputs/t414
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/413.tr
echo ">>>>>>>>running test 415"
../source/tcas.c.inst.exe  994 0 1 3194  242  687 1  501  741 0 0 1     > ../newoutputs/t415
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/414.tr
echo ">>>>>>>>running test 416"
../source/tcas.c.inst.exe  644 1 1 1986  596 2448 0  741  400 1 0 0     > ../newoutputs/t416
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/415.tr
echo ">>>>>>>>running test 417"
../source/tcas.c.inst.exe  935 1 1  792  272 3451 3  401  740 1 1 1     > ../newoutputs/t417
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/416.tr
echo ">>>>>>>>running test 418"
../source/tcas.c.inst.exe  690 1 1 4560  148   43 2  741  500 0 1 0     > ../newoutputs/t418
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/417.tr
echo ">>>>>>>>running test 419"
../source/tcas.c.inst.exe  596 1 0 4634  393  376 1  640  501 0 1 0     > ../newoutputs/t419
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/418.tr
echo ">>>>>>>>running test 420"
../source/tcas.c.inst.exe  538 0 1  404  384 4237 2  640  499 0 0 1     > ../newoutputs/t420
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/419.tr
echo ">>>>>>>>running test 421"
../source/tcas.c.inst.exe  799 0 1  386  380  351 1  639  639 1 0 1     > ../newoutputs/t421
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/420.tr
echo ">>>>>>>>running test 422"
../source/tcas.c.inst.exe  640 0 1 2175  485 1271 3  639  499 1 0 0     > ../newoutputs/t422
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/421.tr
echo ">>>>>>>>running test 423"
../source/tcas.c.inst.exe  884 0 1  754  323 2052 3  399  640 1 0 0     > ../newoutputs/t423
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/422.tr
echo ">>>>>>>>running test 424"
../source/tcas.c.inst.exe  635 1 0 1142  511 4704 1  740  500 0 0 1     > ../newoutputs/t424
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/423.tr
echo ">>>>>>>>running test 425"
../source/tcas.c.inst.exe  781 1 0 1855  408 3758 3  741  741 1 1 0     > ../newoutputs/t425
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/424.tr
echo ">>>>>>>>running test 426"
../source/tcas.c.inst.exe  757 1 1  319   51  300 1  401  741 0 1 0     > ../newoutputs/t426
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/425.tr
echo ">>>>>>>>running test 427"
../source/tcas.c.inst.exe  526 1 1 5505  562 2174 2  639  399 1 0 0     > ../newoutputs/t427
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/426.tr
echo ">>>>>>>>running test 428"
../source/tcas.c.inst.exe  867 0 0 4266  161 5389 1  640  741 0 0 0     > ../newoutputs/t428
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/427.tr
echo ">>>>>>>>running test 429"
../source/tcas.c.inst.exe  693 1 1 4557  254  482 3  740  739 0 0 1     > ../newoutputs/t429
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/428.tr
echo ">>>>>>>>running test 430"
../source/tcas.c.inst.exe  671 0 1 5327  132  902 2  400  500 1 0 1     > ../newoutputs/t430
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/429.tr
echo ">>>>>>>>running test 431"
../source/tcas.c.inst.exe  818 0 1  100  562 4914 0  739  401 0 1 0     > ../newoutputs/t431
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/430.tr
echo ">>>>>>>>running test 432"
../source/tcas.c.inst.exe  780 1 0 5331   10 1209 3  399  640 1 0 1     > ../newoutputs/t432
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/431.tr
echo ">>>>>>>>running test 433"
../source/tcas.c.inst.exe  706 1 0 4170  207  133 3  499  400 0 0 1     > ../newoutputs/t433
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/432.tr
echo ">>>>>>>>running test 434"
../source/tcas.c.inst.exe  714 1 1 1027  537  387 3  739  400 1 1 1     > ../newoutputs/t434
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/433.tr
echo ">>>>>>>>running test 435"
../source/tcas.c.inst.exe  946 0 0  693  550 4173 2  399  400 1 0 1     > ../newoutputs/t435
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/434.tr
echo ">>>>>>>>running test 436"
../source/tcas.c.inst.exe  630 1 0 2188  209 2525 0  639  739 0 0 1     > ../newoutputs/t436
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/435.tr
echo ">>>>>>>>running test 437"
../source/tcas.c.inst.exe  914 1 1 4924  384 5869 3  740  741 0 0 1     > ../newoutputs/t437
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/436.tr
echo ">>>>>>>>running test 438"
../source/tcas.c.inst.exe  721 1 0 4129  379 2370 3  500  741 1 1 1     > ../newoutputs/t438
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/437.tr
echo ">>>>>>>>running test 439"
../source/tcas.c.inst.exe  831 1 0 4955    8 4715 0  500  399 0 0 0     > ../newoutputs/t439
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/438.tr
echo ">>>>>>>>running test 440"
../source/tcas.c.inst.exe  905 1 0 1171  158  385 0  739  499 1 0 0     > ../newoutputs/t440
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/439.tr
echo ">>>>>>>>running test 441"
../source/tcas.c.inst.exe  899 0 1 4998    2 4230 0  500  501 0 0 0     > ../newoutputs/t441
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/440.tr
echo ">>>>>>>>running test 442"
../source/tcas.c.inst.exe  924 0 1 1780  437  998 2  501  639 0 1 1     > ../newoutputs/t442
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/441.tr
echo ">>>>>>>>running test 443"
../source/tcas.c.inst.exe  574 1 0  317  311 2079 1  400  400 1 1 0     > ../newoutputs/t443
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/442.tr
echo ">>>>>>>>running test 444"
../source/tcas.c.inst.exe  623 0 1 4856  546  420 3  500  501 0 1 1     > ../newoutputs/t444
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/443.tr
echo ">>>>>>>>running test 445"
../source/tcas.c.inst.exe  699 0 0 4483  280  358 1  499  639 1 1 1     > ../newoutputs/t445
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/444.tr
echo ">>>>>>>>running test 446"
../source/tcas.c.inst.exe  942 1 1 2938  179  534 0  740  641 0 1 0     > ../newoutputs/t446
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/445.tr
echo ">>>>>>>>running test 447"
../source/tcas.c.inst.exe  571 0 1  379  114 2328 2  400  401 1 1 1     > ../newoutputs/t447
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/446.tr
echo ">>>>>>>>running test 448"
../source/tcas.c.inst.exe  965 0 0 5560  431 1871 0  741  399 1 0 1     > ../newoutputs/t448
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/447.tr
echo ">>>>>>>>running test 449"
../source/tcas.c.inst.exe  974 0 1 1279  110 1990 3  400  501 1 1 0     > ../newoutputs/t449
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/448.tr
echo ">>>>>>>>running test 450"
../source/tcas.c.inst.exe  559 1 1 2851  413 4323 2  501  740 0 0 0     > ../newoutputs/t450
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/449.tr
echo ">>>>>>>>running test 451"
../source/tcas.c.inst.exe  655 1 1 4095  265 3490 2  739  499 1 1 0     > ../newoutputs/t451
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/450.tr
echo ">>>>>>>>running test 452"
../source/tcas.c.inst.exe  860 1 1 2944  139 5412 0  399  641 1 0 1     > ../newoutputs/t452
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/451.tr
echo ">>>>>>>>running test 453"
../source/tcas.c.inst.exe  924 1 0 1981  336 3860 2  500  501 1 1 0     > ../newoutputs/t453
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/452.tr
echo ">>>>>>>>running test 454"
../source/tcas.c.inst.exe  848 1 0 2408  180  525 0  740  401 0 1 0     > ../newoutputs/t454
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/453.tr
echo ">>>>>>>>running test 455"
../source/tcas.c.inst.exe  921 0 1 1788  125  516 3  399  739 1 0 1     > ../newoutputs/t455
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/454.tr
echo ">>>>>>>>running test 456"
../source/tcas.c.inst.exe  852 1 1 1399  347 1245 1  400  641 0 0 0     > ../newoutputs/t456
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/455.tr
echo ">>>>>>>>running test 457"
../source/tcas.c.inst.exe  897 0 0 2622  326 3725 2  401  400 0 0 0     > ../newoutputs/t457
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/456.tr
echo ">>>>>>>>running test 458"
../source/tcas.c.inst.exe  933 0 1  567  407 1839 0  641  640 0 0 1     > ../newoutputs/t458
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/457.tr
echo ">>>>>>>>running test 459"
../source/tcas.c.inst.exe  776 1 0  954   72 2987 3  399  741 0 1 1     > ../newoutputs/t459
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/458.tr
echo ">>>>>>>>running test 460"
../source/tcas.c.inst.exe  748 1 0  508   81 1372 0  740  739 0 1 1     > ../newoutputs/t460
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/459.tr
echo ">>>>>>>>running test 461"
../source/tcas.c.inst.exe  624 0 1 3277  264 5028 3  640  400 1 1 1     > ../newoutputs/t461
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/460.tr
echo ">>>>>>>>running test 462"
../source/tcas.c.inst.exe  570 1 1 5125   85 4371 0  400  499 1 1 0     > ../newoutputs/t462
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/461.tr
echo ">>>>>>>>running test 463"
../source/tcas.c.inst.exe  546 0 1 4364   90 4988 3  739  640 0 1 0     > ../newoutputs/t463
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/462.tr
echo ">>>>>>>>running test 464"
../source/tcas.c.inst.exe  732 0 0 2558  599 3531 0  399  739 1 0 0     > ../newoutputs/t464
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/463.tr
echo ">>>>>>>>running test 465"
../source/tcas.c.inst.exe  795 0 0 3378   59  440 0  399  740 0 1 1     > ../newoutputs/t465
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/464.tr
echo ">>>>>>>>running test 466"
../source/tcas.c.inst.exe  574 0 0  321  131 1814 0  639  641 1 1 0     > ../newoutputs/t466
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/465.tr
echo ">>>>>>>>running test 467"
../source/tcas.c.inst.exe  997 1 0 4466  100 4610 1  639  400 1 0 1     > ../newoutputs/t467
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/466.tr
echo ">>>>>>>>running test 468"
../source/tcas.c.inst.exe  740 1 1  972  312 3512 3  501  740 0 0 0     > ../newoutputs/t468
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/467.tr
echo ">>>>>>>>running test 469"
../source/tcas.c.inst.exe  869 0 0 5624   18  702 2  500  641 1 0 1     > ../newoutputs/t469
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/468.tr
echo ">>>>>>>>running test 470"
../source/tcas.c.inst.exe  955 0 1 1567  366  363 0  401  639 1 1 0     > ../newoutputs/t470
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/469.tr
echo ">>>>>>>>running test 471"
../source/tcas.c.inst.exe  735 1 0 2792  119  224 3  739  739 0 0 0     > ../newoutputs/t471
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/470.tr
echo ">>>>>>>>running test 472"
../source/tcas.c.inst.exe  912 1 0 4251  133  545 1  739  399 1 1 0     > ../newoutputs/t472
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/471.tr
echo ">>>>>>>>running test 473"
../source/tcas.c.inst.exe  607 1 0 5014  531  310 1  739  501 0 0 1     > ../newoutputs/t473
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/472.tr
echo ">>>>>>>>running test 474"
../source/tcas.c.inst.exe  733 1 0 1785  585  343 3  741  499 0 1 1     > ../newoutputs/t474
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/473.tr
echo ">>>>>>>>running test 475"
../source/tcas.c.inst.exe  811 1 1 4100  193 5500 3  641  500 0 1 0     > ../newoutputs/t475
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/474.tr
echo ">>>>>>>>running test 476"
../source/tcas.c.inst.exe  715 0 0 1768  391 1782 2  740  399 0 0 0     > ../newoutputs/t476
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/475.tr
echo ">>>>>>>>running test 477"
../source/tcas.c.inst.exe  797 0 0 4454  508  288 2  741  401 1 0 1     > ../newoutputs/t477
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/476.tr
echo ">>>>>>>>running test 478"
../source/tcas.c.inst.exe  578 0 0 4590  303  220 0  499  501 1 0 1     > ../newoutputs/t478
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/477.tr
echo ">>>>>>>>running test 479"
../source/tcas.c.inst.exe  621 0 1  675  520 3199 3  641  400 0 0 0     > ../newoutputs/t479
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/478.tr
echo ">>>>>>>>running test 480"
../source/tcas.c.inst.exe  841 0 1  427    9 4967 2  740  501 1 1 0     > ../newoutputs/t480
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/479.tr
echo ">>>>>>>>running test 481"
../source/tcas.c.inst.exe  524 0 0 2495  396  506 3  740  640 0 1 0     > ../newoutputs/t481
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/480.tr
echo ">>>>>>>>running test 482"
../source/tcas.c.inst.exe  848 0 0 2494  271 2583 1  501  641 1 0 1     > ../newoutputs/t482
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/481.tr
echo ">>>>>>>>running test 483"
../source/tcas.c.inst.exe  966 0 0 5272  252  451 3  499  740 0 1 0     > ../newoutputs/t483
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/482.tr
echo ">>>>>>>>running test 484"
../source/tcas.c.inst.exe  820 0 0 1557  524 1163 0  499  499 0 0 0     > ../newoutputs/t484
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/483.tr
echo ">>>>>>>>running test 485"
../source/tcas.c.inst.exe  679 1 1  541  338 5123 0  641  641 1 0 1     > ../newoutputs/t485
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/484.tr
echo ">>>>>>>>running test 486"
../source/tcas.c.inst.exe  565 0 0 4233   97 5531 1  739  641 0 0 0     > ../newoutputs/t486
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/485.tr
echo ">>>>>>>>running test 487"
../source/tcas.c.inst.exe  793 0 0 5989  606 3063 3  500  641 0 0 1     > ../newoutputs/t487
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/486.tr
echo ">>>>>>>>running test 488"
../source/tcas.c.inst.exe  609 0 0  259    8 3583 0  641  741 0 1 1     > ../newoutputs/t488
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/487.tr
echo ">>>>>>>>running test 489"
../source/tcas.c.inst.exe  962 0 0 3810  528 1326 2  641  400 0 0 1     > ../newoutputs/t489
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/488.tr
echo ">>>>>>>>running test 490"
../source/tcas.c.inst.exe  587 1 0 4426  303 1022 0  499  741 1 0 0     > ../newoutputs/t490
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/489.tr
echo ">>>>>>>>running test 491"
../source/tcas.c.inst.exe  607 0 0 3707  320 5543 0  639  639 1 1 1     > ../newoutputs/t491
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/490.tr
echo ">>>>>>>>running test 492"
../source/tcas.c.inst.exe  584 1 1 1289  401 4395 1  501  639 0 1 1     > ../newoutputs/t492
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/491.tr
echo ">>>>>>>>running test 493"
../source/tcas.c.inst.exe  564 1 1 4996  391 1494 3  640  500 0 1 1     > ../newoutputs/t493
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/492.tr
echo ">>>>>>>>running test 494"
../source/tcas.c.inst.exe  952 0 1 2813  121 3907 0  501  401 1 0 0     > ../newoutputs/t494
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/493.tr
echo ">>>>>>>>running test 495"
../source/tcas.c.inst.exe  817 0 1 4129   65 3077 0  739  401 1 0 1     > ../newoutputs/t495
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/494.tr
echo ">>>>>>>>running test 496"
../source/tcas.c.inst.exe  726 0 0 3176  519 2689 1  400  641 1 1 1     > ../newoutputs/t496
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/495.tr
echo ">>>>>>>>running test 497"
../source/tcas.c.inst.exe  895 0 1 5104  338  372 3  500  639 0 0 0     > ../newoutputs/t497
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/496.tr
echo ">>>>>>>>running test 498"
../source/tcas.c.inst.exe  928 1 1 3716  536 1907 2  501  639 1 0 0     > ../newoutputs/t498
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/497.tr
echo ">>>>>>>>running test 499"
../source/tcas.c.inst.exe  608 1 1 3093  528 5892 1  400  400 0 1 0     > ../newoutputs/t499
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/498.tr
echo ">>>>>>>>running test 500"
../source/tcas.c.inst.exe  627 1 0  151  446 1983 3  401  500 0 1 1     > ../newoutputs/t500
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/499.tr
echo ">>>>>>>>running test 501"
../source/tcas.c.inst.exe 597 -1 0 -1 577 0 0 605 931 0 2 0     > ../newoutputs/t501
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/500.tr
echo ">>>>>>>>running test 502"
../source/tcas.c.inst.exe 653 1 -1 740 -1 702 -1 0 -1 2 1 1     > ../newoutputs/t502
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/501.tr
echo ">>>>>>>>running test 503"
../source/tcas.c.inst.exe 0 0 0 0 609 -1 1 582 89 4 0 -1     > ../newoutputs/t503
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/502.tr
echo ">>>>>>>>running test 504"
../source/tcas.c.inst.exe -1 1 0 9343 0 127 3 -100 0 1 2 0     > ../newoutputs/t504
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/503.tr
echo ">>>>>>>>running test 505"
../source/tcas.c.inst.exe 640 0 0 569 400 586 1 1012 1037 0 1 1     > ../newoutputs/t505
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/504.tr
echo ">>>>>>>>running test 506"
../source/tcas.c.inst.exe 1174 1 0 586 373 559 2 259 351 0 2 0     > ../newoutputs/t506
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/505.tr
echo ">>>>>>>>running test 507"
../source/tcas.c.inst.exe 684 1 1 522 426 478 0 848 496 0 2 1     > ../newoutputs/t507
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/506.tr
echo ">>>>>>>>running test 508"
../source/tcas.c.inst.exe 1016 1 1 628 0 614 0 0 746 0 2 1     > ../newoutputs/t508
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/507.tr
echo ">>>>>>>>running test 509"
../source/tcas.c.inst.exe 913 0 1 722 520 657 2 714 822 0 2 0     > ../newoutputs/t509
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/508.tr
echo ">>>>>>>>running test 510"
../source/tcas.c.inst.exe 4 1 1 0 409 648 2 601 657 0 2 1     > ../newoutputs/t510
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/509.tr
echo ">>>>>>>>running test 511"
../source/tcas.c.inst.exe 595 0 1 647 357 695 1 536 593 0 1 0     > ../newoutputs/t511
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/510.tr
echo ">>>>>>>>running test 512"
../source/tcas.c.inst.exe 925 1 1 557 349 608 3 994 880 0 2 1     > ../newoutputs/t512
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/511.tr
echo ">>>>>>>>running test 513"
../source/tcas.c.inst.exe 1108 1 1 583 449 601 1 712 725 0 2 1     > ../newoutputs/t513
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/512.tr
echo ">>>>>>>>running test 514"
../source/tcas.c.inst.exe 681 1 0 614 482 0 0 707 757 0 2 0     > ../newoutputs/t514
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/513.tr
echo ">>>>>>>>running test 515"
../source/tcas.c.inst.exe 1081 1 0 675 428 638 0 917 920 0 2 1     > ../newoutputs/t515
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/514.tr
echo ">>>>>>>>running test 516"
../source/tcas.c.inst.exe 652 1 1 638 609 620 1 726 0 0 2 0     > ../newoutputs/t516
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/515.tr
echo ">>>>>>>>running test 517"
../source/tcas.c.inst.exe 1093 1 1 0 580 750 1 678 447 0 2 0     > ../newoutputs/t517
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/516.tr
echo ">>>>>>>>running test 518"
../source/tcas.c.inst.exe 859 1 0 632 355 662 2 379 97 0 2 0     > ../newoutputs/t518
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/517.tr
echo ">>>>>>>>running test 519"
../source/tcas.c.inst.exe 709 1 1 4523 547 657 3 743 743 0 2 1     > ../newoutputs/t519
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/518.tr
echo ">>>>>>>>running test 520"
../source/tcas.c.inst.exe 694 1 0 631 485 642 9 442 418 0 2 1     > ../newoutputs/t520
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/519.tr
echo ">>>>>>>>running test 521"
../source/tcas.c.inst.exe 647 1 1 570 505 615 1 341 392 0 2 1     > ../newoutputs/t521
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/520.tr
echo ">>>>>>>>running test 522"
../source/tcas.c.inst.exe 810 1 0 686 458 122 3 1017 980 0 1 1     > ../newoutputs/t522
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/521.tr
echo ">>>>>>>>running test 523"
../source/tcas.c.inst.exe 766 1 1 0 380 744 0 370 369 0 2 1     > ../newoutputs/t523
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/522.tr
echo ">>>>>>>>running test 524"
../source/tcas.c.inst.exe 860 1 1 618 329 574 4 893 914 0 2 0     > ../newoutputs/t524
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/523.tr
echo ">>>>>>>>running test 525"
../source/tcas.c.inst.exe 654 1 1 912 496 465 0 587 495 0 2 1     > ../newoutputs/t525
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/524.tr
echo ">>>>>>>>running test 526"
../source/tcas.c.inst.exe 760 1 1 753 595 619 0 679 630 0 2 0     > ../newoutputs/t526
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/525.tr
echo ">>>>>>>>running test 527"
../source/tcas.c.inst.exe 1149 1 0 562 485 272 1 670 633 2 2 1     > ../newoutputs/t527
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/526.tr
echo ">>>>>>>>running test 528"
../source/tcas.c.inst.exe 987 1 0 550 587 819 2 929 955 0 1 0     > ../newoutputs/t528
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/527.tr
echo ">>>>>>>>running test 529"
../source/tcas.c.inst.exe 907 1 0 560 342 601 3 961 399 2 2 1     > ../newoutputs/t529
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/528.tr
echo ">>>>>>>>running test 530"
../source/tcas.c.inst.exe 1207 1 1 591 996 658 1 556 0 0 1 1     > ../newoutputs/t530
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/529.tr
echo ">>>>>>>>running test 531"
../source/tcas.c.inst.exe -1 1 0 631 370 661 2 820 825 1 2 1     > ../newoutputs/t531
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/530.tr
echo ">>>>>>>>running test 532"
../source/tcas.c.inst.exe 775 1 1 0 506 596 0 906 685 0 2 1     > ../newoutputs/t532
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/531.tr
echo ">>>>>>>>running test 533"
../source/tcas.c.inst.exe 1018 1 1 3177 325 624 3 1026 1017 0 2 0     > ../newoutputs/t533
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/532.tr
echo ">>>>>>>>running test 534"
../source/tcas.c.inst.exe 868 1 1 731 361 699 1 672 690 0 2 0     > ../newoutputs/t534
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/533.tr
echo ">>>>>>>>running test 535"
../source/tcas.c.inst.exe 895 1 1 -1 403 718 2 694 708 0 2 1     > ../newoutputs/t535
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/534.tr
echo ">>>>>>>>running test 536"
../source/tcas.c.inst.exe 837 1 1 711 452 726 2 593 506 2 2 1     > ../newoutputs/t536
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/535.tr
echo ">>>>>>>>running test 537"
../source/tcas.c.inst.exe 887 1 1 591 589 -100 2 424 457 0 2 0     > ../newoutputs/t537
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/536.tr
echo ">>>>>>>>running test 538"
../source/tcas.c.inst.exe 1027 1 1 -100 369 599 1 737 708 0 2 0     > ../newoutputs/t538
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/537.tr
echo ">>>>>>>>running test 539"
../source/tcas.c.inst.exe 589 1 0 657 557 644 3 0 999 0 2 1     > ../newoutputs/t539
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/538.tr
echo ">>>>>>>>running test 540"
../source/tcas.c.inst.exe 1144 1 1 590 490 646 3 457 0 0 2 1     > ../newoutputs/t540
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/539.tr
echo ">>>>>>>>running test 541"
../source/tcas.c.inst.exe 646 1 1 630 310 615 2 318 314 0 1 1     > ../newoutputs/t541
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/540.tr
echo ">>>>>>>>running test 542"
../source/tcas.c.inst.exe 1168 1 1 0 590 673 0 387 377 0 2 1     > ../newoutputs/t542
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/541.tr
echo ">>>>>>>>running test 543"
../source/tcas.c.inst.exe 248 1 0 0 584 616 3 566 523 0 2 0     > ../newoutputs/t543
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/542.tr
echo ">>>>>>>>running test 544"
../source/tcas.c.inst.exe 837 1 0 691 396 0 0 949 942 0 1 0     > ../newoutputs/t544
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/543.tr
echo ">>>>>>>>running test 545"
../source/tcas.c.inst.exe 854 1 1 703 502 730 1 0 617 0 2 1     > ../newoutputs/t545
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/544.tr
echo ">>>>>>>>running test 546"
../source/tcas.c.inst.exe 1172 1 1 0 590 732 3 745 765 0 2 0     > ../newoutputs/t546
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/545.tr
echo ">>>>>>>>running test 547"
../source/tcas.c.inst.exe 746 1 0 0 391 601 3 837 957 0 2 0     > ../newoutputs/t547
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/546.tr
echo ">>>>>>>>running test 548"
../source/tcas.c.inst.exe 897 1 1 3257 470 707 2 744 693 0 1 0     > ../newoutputs/t548
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/547.tr
echo ">>>>>>>>running test 549"
../source/tcas.c.inst.exe 589 0 1 584 798 567 2 957 925 0 2 0     > ../newoutputs/t549
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/548.tr
echo ">>>>>>>>running test 550"
../source/tcas.c.inst.exe 697 0 0 726 322 725 3 638 650 0 2 1     > ../newoutputs/t550
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/549.tr
echo ">>>>>>>>running test 551"
../source/tcas.c.inst.exe 787 1 1 0 293 597 0 726 686 1 2 1     > ../newoutputs/t551
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/550.tr
echo ">>>>>>>>running test 552"
../source/tcas.c.inst.exe 866 0 1 657 464 43 2 403 424 0 2 1     > ../newoutputs/t552
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/551.tr
echo ">>>>>>>>running test 553"
../source/tcas.c.inst.exe 854 1 0 687 426 684 1 623 744 3 2 1     > ../newoutputs/t553
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/552.tr
echo ">>>>>>>>running test 554"
../source/tcas.c.inst.exe 1016 1 0 658 359 644 1 391 442 1 2 1     > ../newoutputs/t554
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/553.tr
echo ">>>>>>>>running test 555"
../source/tcas.c.inst.exe 905 0 1 699 436 742 1 372 331 0 2 0     > ../newoutputs/t555
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/554.tr
echo ">>>>>>>>running test 556"
../source/tcas.c.inst.exe 892 0 1 762 445 157 2 442 440 0 2 1     > ../newoutputs/t556
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/555.tr
echo ">>>>>>>>running test 557"
../source/tcas.c.inst.exe 1005 1 1 601 394 601 1 717 0 0 2 0     > ../newoutputs/t557
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/556.tr
echo ">>>>>>>>running test 558"
../source/tcas.c.inst.exe 934 1 0 5216 458 972 1 539 464 0 2 1     > ../newoutputs/t558
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/557.tr
echo ">>>>>>>>running test 559"
../source/tcas.c.inst.exe 1184 1 1 4983 523 689 0 653 938 0 1 1     > ../newoutputs/t559
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/558.tr
echo ">>>>>>>>running test 560"
../source/tcas.c.inst.exe 1146 1 0 656 392 691 0 860 0 1 2 1     > ../newoutputs/t560
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/559.tr
echo ">>>>>>>>running test 561"
../source/tcas.c.inst.exe 666 1 1 577 342 558 2 193 1016 0 2 0     > ../newoutputs/t561
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/560.tr
echo ">>>>>>>>running test 562"
../source/tcas.c.inst.exe 1059 0 0 640 380 580 0 748 692 2 2 0     > ../newoutputs/t562
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/561.tr
echo ">>>>>>>>running test 563"
../source/tcas.c.inst.exe 934 1 0 603 333 552 0 410 439 0 2 1     > ../newoutputs/t563
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/562.tr
echo ">>>>>>>>running test 564"
../source/tcas.c.inst.exe 947 1 1 677 237 681 2 594 352 0 2 0     > ../newoutputs/t564
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/563.tr
echo ">>>>>>>>running test 565"
../source/tcas.c.inst.exe 655 1 1 628 348 861 2 455 0 0 2 0     > ../newoutputs/t565
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/564.tr
echo ">>>>>>>>running test 566"
../source/tcas.c.inst.exe 1137 1 1 687 292 572 2 0 372 0 1 1     > ../newoutputs/t566
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/565.tr
echo ">>>>>>>>running test 567"
../source/tcas.c.inst.exe 812 1 0 663 336 587 0 518 20 0 2 0     > ../newoutputs/t567
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/566.tr
echo ">>>>>>>>running test 568"
../source/tcas.c.inst.exe 1022 1 1 554 320 598 2 914 494 2 1 0     > ../newoutputs/t568
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/567.tr
echo ">>>>>>>>running test 569"
../source/tcas.c.inst.exe 761 1 0 608 527 596 0 663 632 0 2 1     > ../newoutputs/t569
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/568.tr
echo ">>>>>>>>running test 570"
../source/tcas.c.inst.exe 0 0 1 60 432 738 3 863 852 0 2 1     > ../newoutputs/t570
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/569.tr
echo ">>>>>>>>running test 571"
../source/tcas.c.inst.exe 808 1 0 581 492 448 2 452 0 0 2 1     > ../newoutputs/t571
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/570.tr
echo ">>>>>>>>running test 572"
../source/tcas.c.inst.exe 845 1 1 667 661 683 1 446 404 2 2 0     > ../newoutputs/t572
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/571.tr
echo ">>>>>>>>running test 573"
../source/tcas.c.inst.exe 815 1 0 625 419 657 0 0 887 0 1 0     > ../newoutputs/t573
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/572.tr
echo ">>>>>>>>running test 574"
../source/tcas.c.inst.exe 756 1 1 586 341 824 3 417 361 0 2 1     > ../newoutputs/t574
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/573.tr
echo ">>>>>>>>running test 575"
../source/tcas.c.inst.exe 640 1 0 654 438 0 1 0 415 2 1 1     > ../newoutputs/t575
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/574.tr
echo ">>>>>>>>running test 576"
../source/tcas.c.inst.exe 1118 1 1 712 261 735 1 423 450 0 1 1     > ../newoutputs/t576
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/575.tr
echo ">>>>>>>>running test 577"
../source/tcas.c.inst.exe 1073 1 1 2223 379 752 0 435 438 2 2 0     > ../newoutputs/t577
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/576.tr
echo ">>>>>>>>running test 578"
../source/tcas.c.inst.exe 763 1 1 6514 0 643 3 816 756 0 2 1     > ../newoutputs/t578
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/577.tr
echo ">>>>>>>>running test 579"
../source/tcas.c.inst.exe 1064 1 1 674 401 663 9 560 900 0 1 0     > ../newoutputs/t579
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/578.tr
echo ">>>>>>>>running test 580"
../source/tcas.c.inst.exe 592 1 1 701 532 688 3 396 372 0 2 1     > ../newoutputs/t580
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/579.tr
echo ">>>>>>>>running test 581"
../source/tcas.c.inst.exe 1037 1 0 610 504 623 3 0 877 0 2 1     > ../newoutputs/t581
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/580.tr
echo ">>>>>>>>running test 582"
../source/tcas.c.inst.exe 795 1 -1 538 325 601 2 702 634 0 1 1     > ../newoutputs/t582
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/581.tr
echo ">>>>>>>>running test 583"
../source/tcas.c.inst.exe 709 1 1 686 483 672 1 465 475 1 2 1     > ../newoutputs/t583
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/582.tr
echo ">>>>>>>>running test 584"
../source/tcas.c.inst.exe 847 1 1 1325 360 668 2 817 803 0 1 1     > ../newoutputs/t584
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/583.tr
echo ">>>>>>>>running test 585"
../source/tcas.c.inst.exe 782 1 0 729 462 0 1 449 818 0 2 1     > ../newoutputs/t585
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/584.tr
echo ">>>>>>>>running test 586"
../source/tcas.c.inst.exe 964 1 1 2672 326 714 2 18 609 2 2 1     > ../newoutputs/t586
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/585.tr
echo ">>>>>>>>running test 587"
../source/tcas.c.inst.exe 796 1 1 0 535 627 1 329 0 0 2 1     > ../newoutputs/t587
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/586.tr
echo ">>>>>>>>running test 588"
../source/tcas.c.inst.exe 1058 1 0 707 0 703 0 901 906 0 2 0     > ../newoutputs/t588
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/587.tr
echo ">>>>>>>>running test 589"
../source/tcas.c.inst.exe 732 1 1 654 413 710 2 306 375 -1 2 1     > ../newoutputs/t589
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/588.tr
echo ">>>>>>>>running test 590"
../source/tcas.c.inst.exe 1122 1 1 705 374 716 1 0 547 0 2 0     > ../newoutputs/t590
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/589.tr
echo ">>>>>>>>running test 591"
../source/tcas.c.inst.exe 1022 1 0 716 503 -1 1 629 815 0 2 1     > ../newoutputs/t591
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/590.tr
echo ">>>>>>>>running test 592"
../source/tcas.c.inst.exe 1109 1 1 557 344 639 0 370 -100 0 2 1     > ../newoutputs/t592
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/591.tr
echo ">>>>>>>>running test 593"
../source/tcas.c.inst.exe 764 -1 0 561 530 592 1 593 619 0 2 1     > ../newoutputs/t593
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/592.tr
echo ">>>>>>>>running test 594"
../source/tcas.c.inst.exe 756 1 1 546 603 603 0 0 796 2 2 0     > ../newoutputs/t594
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/593.tr
echo ">>>>>>>>running test 595"
../source/tcas.c.inst.exe 811 1 0 691 350 0 0 619 0 0 2 0     > ../newoutputs/t595
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/594.tr
echo ">>>>>>>>running test 596"
../source/tcas.c.inst.exe 1149 1 1 606 399 602 1 441 369 0 2 0     > ../newoutputs/t596
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/595.tr
echo ">>>>>>>>running test 597"
../source/tcas.c.inst.exe 1096 1 0 714 496 682 1 944 908 0 1 0     > ../newoutputs/t597
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/596.tr
echo ">>>>>>>>running test 598"
../source/tcas.c.inst.exe 1039 0 1 1310 948 653 0 0 922 0 2 0     > ../newoutputs/t598
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/597.tr
echo ">>>>>>>>running test 599"
../source/tcas.c.inst.exe 806 1 0 744 0 349 2 839 -100 0 2 1     > ../newoutputs/t599
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/598.tr
echo ">>>>>>>>running test 600"
../source/tcas.c.inst.exe 1032 1 0 707 389 727 1 297 0 2 2 0     > ../newoutputs/t600
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/599.tr
echo ">>>>>>>>running test 601"
../source/tcas.c.inst.exe 854 1 1 4049 773 654 2 595 625 0 2 1     > ../newoutputs/t601
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/600.tr
echo ">>>>>>>>running test 602"
../source/tcas.c.inst.exe 1159 0 1 672 298 178 2 468 0 0 2 0     > ../newoutputs/t602
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/601.tr
echo ">>>>>>>>running test 603"
../source/tcas.c.inst.exe 752 1 1 733 398 746 3 328 0 0 2 9     > ../newoutputs/t603
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/602.tr
echo ">>>>>>>>running test 604"
../source/tcas.c.inst.exe 1143 0 0 604 365 0 1 451 458 0 2 1     > ../newoutputs/t604
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/603.tr
echo ">>>>>>>>running test 605"
../source/tcas.c.inst.exe -1 1 1 604 607 622 0 0 0 0 2 0     > ../newoutputs/t605
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/604.tr
echo ">>>>>>>>running test 606"
../source/tcas.c.inst.exe 943 1 1 668 833 956 2 588 556 0 2 0     > ../newoutputs/t606
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/605.tr
echo ">>>>>>>>running test 607"
../source/tcas.c.inst.exe 1175 1 0 619 491 684 1 693 60 2 1 1     > ../newoutputs/t607
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/606.tr
echo ">>>>>>>>running test 608"
../source/tcas.c.inst.exe 784 1 1 566 870 578 2 969 694 0 2 1     > ../newoutputs/t608
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/607.tr
echo ">>>>>>>>running test 609"
../source/tcas.c.inst.exe 708 1 1 871 369 712 3 427 478 0 2 1     > ../newoutputs/t609
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/608.tr
echo ">>>>>>>>running test 610"
../source/tcas.c.inst.exe 162 1 0 587 577 110 0 647 962 1 2 1     > ../newoutputs/t610
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/609.tr
echo ">>>>>>>>running test 611"
../source/tcas.c.inst.exe 1074 1 0 0 305 666 3 306 356 0 1 1     > ../newoutputs/t611
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/610.tr
echo ">>>>>>>>running test 612"
../source/tcas.c.inst.exe 800 1 0 735 323 724 2 233 584 0 2 0     > ../newoutputs/t612
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/611.tr
echo ">>>>>>>>running test 613"
../source/tcas.c.inst.exe 1078 1 0 673 311 692 2 551 490 2 2 0     > ../newoutputs/t613
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/612.tr
echo ">>>>>>>>running test 614"
../source/tcas.c.inst.exe 613 1 1 711 538 0 1 363 398 0 2 1     > ../newoutputs/t614
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/613.tr
echo ">>>>>>>>running test 615"
../source/tcas.c.inst.exe 860 1 0 -1 485 422 0 330 273 0 2 1     > ../newoutputs/t615
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/614.tr
echo ">>>>>>>>running test 616"
../source/tcas.c.inst.exe 615 1 1 767 616 0 1 751 673 0 2 0     > ../newoutputs/t616
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/615.tr
echo ">>>>>>>>running test 617"
../source/tcas.c.inst.exe 0 1 0 692 465 646 3 872 825 2 2 1     > ../newoutputs/t617
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/616.tr
echo ">>>>>>>>running test 618"
../source/tcas.c.inst.exe 792 0 0 625 409 541 2 381 403 0 2 0     > ../newoutputs/t618
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/617.tr
echo ">>>>>>>>running test 619"
../source/tcas.c.inst.exe -1 0 1 593 447 655 1 366 314 0 1 1     > ../newoutputs/t619
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/618.tr
echo ">>>>>>>>running test 620"
../source/tcas.c.inst.exe 1113 1 0 7965 430 596 1 820 876 0 2 0     > ../newoutputs/t620
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/619.tr
echo ">>>>>>>>running test 621"
../source/tcas.c.inst.exe 999 1 0 0 447 610 1 511 464 1 2 0     > ../newoutputs/t621
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/620.tr
echo ">>>>>>>>running test 622"
../source/tcas.c.inst.exe 865 1 1 634 344 699 1 -100 600 0 2 0     > ../newoutputs/t622
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/621.tr
echo ">>>>>>>>running test 623"
../source/tcas.c.inst.exe 974 0 1 651 539 671 1 955 997 1 2 0     > ../newoutputs/t623
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/622.tr
echo ">>>>>>>>running test 624"
../source/tcas.c.inst.exe 1016 1 0 712 426 0 0 361 745 0 2 1     > ../newoutputs/t624
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/623.tr
echo ">>>>>>>>running test 625"
../source/tcas.c.inst.exe 1051 1 0 618 294 236 1 230 872 0 1 0     > ../newoutputs/t625
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/624.tr
echo ">>>>>>>>running test 626"
../source/tcas.c.inst.exe 232 1 1 583 513 601 0 0 928 1 2 1     > ../newoutputs/t626
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/625.tr
echo ">>>>>>>>running test 627"
../source/tcas.c.inst.exe 661 0 0 544 598 0 1 573 566 0 2 0     > ../newoutputs/t627
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/626.tr
echo ">>>>>>>>running test 628"
../source/tcas.c.inst.exe 784 1 0 0 365 732 0 611 624 2 2 1     > ../newoutputs/t628
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/627.tr
echo ">>>>>>>>running test 629"
../source/tcas.c.inst.exe 695 0 0 593 451 568 2 981 0 0 2 1     > ../newoutputs/t629
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/628.tr
echo ">>>>>>>>running test 630"
../source/tcas.c.inst.exe 1112 1 1 601 400 663 1 298 0 1 2 0     > ../newoutputs/t630
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/629.tr
echo ">>>>>>>>running test 631"
../source/tcas.c.inst.exe 876 -1 1 745 375 892 1 930 930 0 2 1     > ../newoutputs/t631
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/630.tr
echo ">>>>>>>>running test 632"
../source/tcas.c.inst.exe 1063 1 0 662 0 592 3 416 346 0 2 1     > ../newoutputs/t632
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/631.tr
echo ">>>>>>>>running test 633"
../source/tcas.c.inst.exe 271 1 1 697 633 691 3 890 868 0 1 1     > ../newoutputs/t633
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/632.tr
echo ">>>>>>>>running test 634"
../source/tcas.c.inst.exe 1208 1 0 544 -1 605 1 797 801 0 2 1     > ../newoutputs/t634
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/633.tr
echo ">>>>>>>>running test 635"
../source/tcas.c.inst.exe 1185 1 -1 710 378 674 3 604 554 0 2 0     > ../newoutputs/t635
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/634.tr
echo ">>>>>>>>running test 636"
../source/tcas.c.inst.exe 1206 1 0 5140 355 730 2 980 693 2 2 0     > ../newoutputs/t636
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/635.tr
echo ">>>>>>>>running test 637"
../source/tcas.c.inst.exe 1155 1 0 603 349 514 3 816 863 1 2 0     > ../newoutputs/t637
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/636.tr
echo ">>>>>>>>running test 638"
../source/tcas.c.inst.exe 6 0 0 648 427 687 0 961 947 0 1 1     > ../newoutputs/t638
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/637.tr
echo ">>>>>>>>running test 639"
../source/tcas.c.inst.exe 601 1 0 672 0 660 3 577 545 0 2 3     > ../newoutputs/t639
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/638.tr
echo ">>>>>>>>running test 640"
../source/tcas.c.inst.exe 648 1 0 680 511 428 3 0 314 0 2 1     > ../newoutputs/t640
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/639.tr
echo ">>>>>>>>running test 641"
../source/tcas.c.inst.exe 774 1 1 0 433 239 0 -1 390 0 2 1     > ../newoutputs/t641
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/640.tr
echo ">>>>>>>>running test 642"
../source/tcas.c.inst.exe 909 1 0 575 444 -100 1 523 981 0 2 0     > ../newoutputs/t642
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/641.tr
echo ">>>>>>>>running test 643"
../source/tcas.c.inst.exe 780 0 1 669 562 387 1 0 951 0 2 1     > ../newoutputs/t643
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/642.tr
echo ">>>>>>>>running test 644"
../source/tcas.c.inst.exe 697 1 0 728 614 725 1 173 131 1 2 0     > ../newoutputs/t644
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/643.tr
echo ">>>>>>>>running test 645"
../source/tcas.c.inst.exe 0 1 1 752 563 695 1 602 656 0 2 1     > ../newoutputs/t645
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/644.tr
echo ">>>>>>>>running test 646"
../source/tcas.c.inst.exe 1004 1 0 0 393 597 1 450 743 0 2 0     > ../newoutputs/t646
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/645.tr
echo ">>>>>>>>running test 647"
../source/tcas.c.inst.exe 849 1 1 734 651 0 2 571 565 0 2 1     > ../newoutputs/t647
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/646.tr
echo ">>>>>>>>running test 648"
../source/tcas.c.inst.exe 777 1 0 6281 379 700 0 594 0 0 2 1     > ../newoutputs/t648
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/647.tr
echo ">>>>>>>>running test 649"
../source/tcas.c.inst.exe 1169 1 0 616 922 690 3 0 784 0 2 0     > ../newoutputs/t649
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/648.tr
echo ">>>>>>>>running test 650"
../source/tcas.c.inst.exe 1090 1 0 762 308 713 1 774 759 1 1 0     > ../newoutputs/t650
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/649.tr
echo ">>>>>>>>running test 651"
../source/tcas.c.inst.exe 1170 1 1 605 569 629 2 662 665 0 2 9     > ../newoutputs/t651
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/650.tr
echo ">>>>>>>>running test 652"
../source/tcas.c.inst.exe 981 1 1 459 317 590 2 533 544 2 2 1     > ../newoutputs/t652
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/651.tr
echo ">>>>>>>>running test 653"
../source/tcas.c.inst.exe 1158 0 0 608 441 601 0 671 812 0 2 1     > ../newoutputs/t653
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/652.tr
echo ">>>>>>>>running test 654"
../source/tcas.c.inst.exe 0 1 0 1049 563 594 3 401 372 0 2 0     > ../newoutputs/t654
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/653.tr
echo ">>>>>>>>running test 655"
../source/tcas.c.inst.exe 1105 1 1 -100 430 529 3 842 74 0 2 1     > ../newoutputs/t655
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/654.tr
echo ">>>>>>>>running test 656"
../source/tcas.c.inst.exe 680 1 1 3803 981 581 3 769 812 0 2 0     > ../newoutputs/t656
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/655.tr
echo ">>>>>>>>running test 657"
../source/tcas.c.inst.exe 1165 1 0 690 19 871 0 293 346 1 2 0     > ../newoutputs/t657
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/656.tr
echo ">>>>>>>>running test 658"
../source/tcas.c.inst.exe 0 1 0 570 620 611 0 992 1023 0 2 0     > ../newoutputs/t658
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/657.tr
echo ">>>>>>>>running test 659"
../source/tcas.c.inst.exe 1105 0 0 584 450 293 1 755 638 0 1 1     > ../newoutputs/t659
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/658.tr
echo ">>>>>>>>running test 660"
../source/tcas.c.inst.exe 966 -1 1 3658 196 660 1 0 452 0 2 1     > ../newoutputs/t660
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/659.tr
echo ">>>>>>>>running test 661"
../source/tcas.c.inst.exe 639 1 0 8459 370 678 1 737 810 0 1 0     > ../newoutputs/t661
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/660.tr
echo ">>>>>>>>running test 662"
../source/tcas.c.inst.exe 836 1 0 637 -1 0 0 984 1003 0 2 1     > ../newoutputs/t662
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/661.tr
echo ">>>>>>>>running test 663"
../source/tcas.c.inst.exe 903 1 1 684 368 661 0 725 0 0 2 1     > ../newoutputs/t663
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/662.tr
echo ">>>>>>>>running test 664"
../source/tcas.c.inst.exe 908 0 0 613 38 564 1 775 835 1 2 0     > ../newoutputs/t664
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/663.tr
echo ">>>>>>>>running test 665"
../source/tcas.c.inst.exe 1196 0 -1 688 398 663 0 485 434 0 1 1     > ../newoutputs/t665
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/664.tr
echo ">>>>>>>>running test 666"
../source/tcas.c.inst.exe 1055 1 0 9520 512 686 3 0 368 0 2 1     > ../newoutputs/t666
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/665.tr
echo ">>>>>>>>running test 667"
../source/tcas.c.inst.exe 618 -1 1 737 0 708 1 907 371 0 2 0     > ../newoutputs/t667
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/666.tr
echo ">>>>>>>>running test 668"
../source/tcas.c.inst.exe 825 1 1 783 329 499 3 931 914 1 2 1     > ../newoutputs/t668
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/667.tr
echo ">>>>>>>>running test 669"
../source/tcas.c.inst.exe 969 1 0 719 330 690 1 932 -1 0 2 0     > ../newoutputs/t669
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/668.tr
echo ">>>>>>>>running test 670"
../source/tcas.c.inst.exe 1072 1 1 0 457 603 0 481 759 1 2 1     > ../newoutputs/t670
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/669.tr
echo ">>>>>>>>running test 671"
../source/tcas.c.inst.exe 1101 1 1 713 422 0 3 785 778 1 2 1     > ../newoutputs/t671
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/670.tr
echo ">>>>>>>>running test 672"
../source/tcas.c.inst.exe 1119 1 1 586 386 221 2 830 979 0 2 0     > ../newoutputs/t672
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/671.tr
echo ">>>>>>>>running test 673"
../source/tcas.c.inst.exe 832 1 -1 82 314 0 2 0 806 0 2 1     > ../newoutputs/t673
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/672.tr
echo ">>>>>>>>running test 674"
../source/tcas.c.inst.exe 767 1 1 726 767 714 2 0 798 2 2 0     > ../newoutputs/t674
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/673.tr
echo ">>>>>>>>running test 675"
../source/tcas.c.inst.exe 1188 1 1 590 758 610 1 691 669 2 1 1     > ../newoutputs/t675
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/674.tr
echo ">>>>>>>>running test 676"
../source/tcas.c.inst.exe 1030 1 1 743 536 737 3 597 754 1 2 1     > ../newoutputs/t676
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/675.tr
echo ">>>>>>>>running test 677"
../source/tcas.c.inst.exe -1 1 0 5409 534 551 0 175 764 0 2 1     > ../newoutputs/t677
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/676.tr
echo ">>>>>>>>running test 678"
../source/tcas.c.inst.exe 880 1 1 651 496 696 2 716 283 0 1 1     > ../newoutputs/t678
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/677.tr
echo ">>>>>>>>running test 679"
../source/tcas.c.inst.exe 656 1 1 612 513 543 1 0 285 0 1 1     > ../newoutputs/t679
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/678.tr
echo ">>>>>>>>running test 680"
../source/tcas.c.inst.exe 990 1 1 9671 622 173 2 0 766 0 2 1     > ../newoutputs/t680
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/679.tr
echo ">>>>>>>>running test 681"
../source/tcas.c.inst.exe -100 1 1 650 497 655 3 806 764 0 2 1     > ../newoutputs/t681
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/680.tr
echo ">>>>>>>>running test 682"
../source/tcas.c.inst.exe 759 1 0 5966 544 494 2 965 955 -1 2 0     > ../newoutputs/t682
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/681.tr
echo ">>>>>>>>running test 683"
../source/tcas.c.inst.exe 636 1 0 637 352 716 1 335 -100 0 2 1     > ../newoutputs/t683
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/682.tr
echo ">>>>>>>>running test 684"
../source/tcas.c.inst.exe 922 1 0 583 576 558 1 435 474 1 2 0     > ../newoutputs/t684
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/683.tr
echo ">>>>>>>>running test 685"
../source/tcas.c.inst.exe 967 1 0 2215 354 582 0 999 0 0 2 1     > ../newoutputs/t685
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/684.tr
echo ">>>>>>>>running test 686"
../source/tcas.c.inst.exe 937 1 0 605 0 554 0 633 622 0 2 0     > ../newoutputs/t686
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/685.tr
echo ">>>>>>>>running test 687"
../source/tcas.c.inst.exe 594 1 1 770 455 751 0 610 -1 0 2 0     > ../newoutputs/t687
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/686.tr
echo ">>>>>>>>running test 688"
../source/tcas.c.inst.exe 1057 1 0 0 379 614 0 812 799 0 2 -1     > ../newoutputs/t688
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/687.tr
echo ">>>>>>>>running test 689"
../source/tcas.c.inst.exe 736 0 1 7870 571 700 3 469 438 0 2 1     > ../newoutputs/t689
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/688.tr
echo ">>>>>>>>running test 690"
../source/tcas.c.inst.exe 690 1 0 626 252 676 3 366 611 0 1 1     > ../newoutputs/t690
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/689.tr
echo ">>>>>>>>running test 691"
../source/tcas.c.inst.exe 458 1 0 4251 551 721 1 617 588 0 1 0     > ../newoutputs/t691
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/690.tr
echo ">>>>>>>>running test 692"
../source/tcas.c.inst.exe 795 1 1 1372 334 686 3 559 381 0 2 1     > ../newoutputs/t692
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/691.tr
echo ">>>>>>>>running test 693"
../source/tcas.c.inst.exe 842 0 0 631 599 623 3 910 875 1 2 1     > ../newoutputs/t693
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/692.tr
echo ">>>>>>>>running test 694"
../source/tcas.c.inst.exe 702 1 0 695 889 0 0 412 469 0 2 0     > ../newoutputs/t694
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/693.tr
echo ">>>>>>>>running test 695"
../source/tcas.c.inst.exe 681 1 0 1904 340 904 3 344 360 0 2 0     > ../newoutputs/t695
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/694.tr
echo ">>>>>>>>running test 696"
../source/tcas.c.inst.exe 945 1 0 720 292 692 1 890 888 0 1 0     > ../newoutputs/t696
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/695.tr
echo ">>>>>>>>running test 697"
../source/tcas.c.inst.exe 896 1 0 592 405 882 1 466 549 0 1 0     > ../newoutputs/t697
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/696.tr
echo ">>>>>>>>running test 698"
../source/tcas.c.inst.exe 832 1 0 9715 387 665 1 899 800 0 2 1     > ../newoutputs/t698
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/697.tr
echo ">>>>>>>>running test 699"
../source/tcas.c.inst.exe 651 1 0 -1 571 599 2 41 514 0 2 0     > ../newoutputs/t699
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/698.tr
echo ">>>>>>>>running test 700"
../source/tcas.c.inst.exe 1098 1 1 664 607 0 -1 580 162 0 2 0     > ../newoutputs/t700
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/699.tr
echo ">>>>>>>>running test 701"
../source/tcas.c.inst.exe 0 1 0 713 334 670 2 353 328 1 2 1     > ../newoutputs/t701
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/700.tr
echo ">>>>>>>>running test 702"
../source/tcas.c.inst.exe 603 -1 0 654 507 11 3 611 600 0 1 1     > ../newoutputs/t702
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/701.tr
echo ">>>>>>>>running test 703"
../source/tcas.c.inst.exe 848 1 0 645 519 579 9 512 970 0 2 0     > ../newoutputs/t703
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/702.tr
echo ">>>>>>>>running test 704"
../source/tcas.c.inst.exe 19 0 0 4907 421 657 1 665 0 0 2 0     > ../newoutputs/t704
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/703.tr
echo ">>>>>>>>running test 705"
../source/tcas.c.inst.exe 772 1 0 0 311 599 2 978 891 1 2 0     > ../newoutputs/t705
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/704.tr
echo ">>>>>>>>running test 706"
../source/tcas.c.inst.exe 613 1 0 0 413 696 3 794 743 0 2 1     > ../newoutputs/t706
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/705.tr
echo ">>>>>>>>running test 707"
../source/tcas.c.inst.exe 1092 1 1 2461 931 0 2 647 715 2 2 0     > ../newoutputs/t707
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/706.tr
echo ">>>>>>>>running test 708"
../source/tcas.c.inst.exe -1 1 0 655 565 658 0 858 870 0 2 0     > ../newoutputs/t708
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/707.tr
echo ">>>>>>>>running test 709"
../source/tcas.c.inst.exe 1106 0 0 521 0 592 2 220 0 0 2 1     > ../newoutputs/t709
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/708.tr
echo ">>>>>>>>running test 710"
../source/tcas.c.inst.exe 746 1 0 653 345 667 3 386 153 0 1 0     > ../newoutputs/t710
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/709.tr
echo ">>>>>>>>running test 711"
../source/tcas.c.inst.exe 683 1 1 8310 300 0 1 0 0 0 1 1     > ../newoutputs/t711
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/710.tr
echo ">>>>>>>>running test 712"
../source/tcas.c.inst.exe -100 0 0 636 630 0 0 467 507 1 2 0     > ../newoutputs/t712
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/711.tr
echo ">>>>>>>>running test 713"
../source/tcas.c.inst.exe 469 1 1 579 703 109 3 432 500 0 2 1     > ../newoutputs/t713
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/712.tr
echo ">>>>>>>>running test 714"
../source/tcas.c.inst.exe 717 1 -1 641 433 500 2 145 0 2 2 0     > ../newoutputs/t714
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/713.tr
echo ">>>>>>>>running test 715"
../source/tcas.c.inst.exe 699 1 0 -1 311 0 1 705 854 2 2 1     > ../newoutputs/t715
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/714.tr
echo ">>>>>>>>running test 716"
../source/tcas.c.inst.exe -1 1 1 685 442 -1 2 338 364 0 2 1     > ../newoutputs/t716
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/715.tr
echo ">>>>>>>>running test 717"
../source/tcas.c.inst.exe 844 1 0 683 0 663 2 361 725 2 2 0     > ../newoutputs/t717
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/716.tr
echo ">>>>>>>>running test 718"
../source/tcas.c.inst.exe 733 1 0 696 228 704 3 693 638 1 2 0     > ../newoutputs/t718
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/717.tr
echo ">>>>>>>>running test 719"
../source/tcas.c.inst.exe 733 0 0 730 717 747 1 767 288 2 2 0     > ../newoutputs/t719
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/718.tr
echo ">>>>>>>>running test 720"
../source/tcas.c.inst.exe 653 1 0 605 619 554 3 913 601 2 2 0     > ../newoutputs/t720
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/719.tr
echo ">>>>>>>>running test 721"
../source/tcas.c.inst.exe 1115 1 1 739 422 739 2 528 534 3 1 1     > ../newoutputs/t721
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/720.tr
echo ">>>>>>>>running test 722"
../source/tcas.c.inst.exe 926 1 0 590 50 532 3 957 922 0 2 0     > ../newoutputs/t722
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/721.tr
echo ">>>>>>>>running test 723"
../source/tcas.c.inst.exe 675 -1 0 656 506 655 0 564 590 0 2 0     > ../newoutputs/t723
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/722.tr
echo ">>>>>>>>running test 724"
../source/tcas.c.inst.exe 1179 1 0 697 805 691 0 594 213 0 2 1     > ../newoutputs/t724
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/723.tr
echo ">>>>>>>>running test 725"
../source/tcas.c.inst.exe 1166 1 1 0 352 748 3 297 318 0 1 0     > ../newoutputs/t725
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/724.tr
echo ">>>>>>>>running test 726"
../source/tcas.c.inst.exe 232 1 1 564 333 0 1 862 601 0 2 0     > ../newoutputs/t726
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/725.tr
echo ">>>>>>>>running test 727"
../source/tcas.c.inst.exe 0 1 0 743 318 747 2 694 726 0 1 1     > ../newoutputs/t727
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/726.tr
echo ">>>>>>>>running test 728"
../source/tcas.c.inst.exe 829 1 0 0 464 314 3 784 809 0 1 0     > ../newoutputs/t728
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/727.tr
echo ">>>>>>>>running test 729"
../source/tcas.c.inst.exe 1195 1 0 0 460 666 3 509 492 0 2 0     > ../newoutputs/t729
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/728.tr
echo ">>>>>>>>running test 730"
../source/tcas.c.inst.exe 790 1 1 719 436 697 1 681 417 2 2 1     > ../newoutputs/t730
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/729.tr
echo ">>>>>>>>running test 731"
../source/tcas.c.inst.exe 878 1 0 681 131 650 1 855 816 2 2 1     > ../newoutputs/t731
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/730.tr
echo ">>>>>>>>running test 732"
../source/tcas.c.inst.exe 0 1 0 634 577 673 2 527 635 0 2 0     > ../newoutputs/t732
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/731.tr
echo ">>>>>>>>running test 733"
../source/tcas.c.inst.exe -1 1 1 513 194 552 0 0 331 0 2 0     > ../newoutputs/t733
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/732.tr
echo ">>>>>>>>running test 734"
../source/tcas.c.inst.exe 616 0 1 752 604 702 0 459 857 0 2 1     > ../newoutputs/t734
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/733.tr
echo ">>>>>>>>running test 735"
../source/tcas.c.inst.exe 1129 1 0 665 586 225 2 785 973 0 2 0     > ../newoutputs/t735
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/734.tr
echo ">>>>>>>>running test 736"
../source/tcas.c.inst.exe 1017 1 0 666 369 646 3 -1 772 0 2 1     > ../newoutputs/t736
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/735.tr
echo ">>>>>>>>running test 737"
../source/tcas.c.inst.exe 1124 1 0 605 233 507 1 0 409 0 2 1     > ../newoutputs/t737
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/736.tr
echo ">>>>>>>>running test 738"
../source/tcas.c.inst.exe 608 1 1 685 588 718 3 17 883 0 1 1     > ../newoutputs/t738
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/737.tr
echo ">>>>>>>>running test 739"
../source/tcas.c.inst.exe 983 1 1 0 636 741 2 460 275 0 1 0     > ../newoutputs/t739
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/738.tr
echo ">>>>>>>>running test 740"
../source/tcas.c.inst.exe 334 1 0 728 533 660 2 481 496 0 1 0     > ../newoutputs/t740
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/739.tr
echo ">>>>>>>>running test 741"
../source/tcas.c.inst.exe 611 1 0 660 667 0 1 936 924 0 1 0     > ../newoutputs/t741
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/740.tr
echo ">>>>>>>>running test 742"
../source/tcas.c.inst.exe 1036 0 0 586 585 304 0 505 578 1 2 0     > ../newoutputs/t742
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/741.tr
echo ">>>>>>>>running test 743"
../source/tcas.c.inst.exe 881 1 -1 740 521 722 3 311 958 1 2 0     > ../newoutputs/t743
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/742.tr
echo ">>>>>>>>running test 744"
../source/tcas.c.inst.exe 1173 1 0 5952 576 657 0 292 741 2 1 1     > ../newoutputs/t744
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/743.tr
echo ">>>>>>>>running test 745"
../source/tcas.c.inst.exe 930 1 0 642 311 0 3 0 699 0 1 1     > ../newoutputs/t745
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/744.tr
echo ">>>>>>>>running test 746"
../source/tcas.c.inst.exe 1108 1 0 772 879 723 0 286 340 0 1 0     > ../newoutputs/t746
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/745.tr
echo ">>>>>>>>running test 747"
../source/tcas.c.inst.exe 0 1 0 592 607 626 1 586 642 0 2 1     > ../newoutputs/t747
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/746.tr
echo ">>>>>>>>running test 748"
../source/tcas.c.inst.exe 0 1 1 771 401 503 2 513 822 0 2 1     > ../newoutputs/t748
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/747.tr
echo ">>>>>>>>running test 749"
../source/tcas.c.inst.exe 1019 0 1 6630 400 631 0 416 384 0 2 0     > ../newoutputs/t749
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/748.tr
echo ">>>>>>>>running test 750"
../source/tcas.c.inst.exe -1 1 0 -100 606 721 3 927 947 2 2 1     > ../newoutputs/t750
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/749.tr
echo ">>>>>>>>running test 751"
../source/tcas.c.inst.exe 915 0 0 721 613 784 2 330 356 2 1 0     > ../newoutputs/t751
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/750.tr
echo ">>>>>>>>running test 752"
../source/tcas.c.inst.exe 816 1 0 706 496 737 1 917 908 -1 2 0     > ../newoutputs/t752
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/751.tr
echo ">>>>>>>>running test 753"
../source/tcas.c.inst.exe 1150 1 1 594 -100 533 2 494 548 0 2 0     > ../newoutputs/t753
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/752.tr
echo ">>>>>>>>running test 754"
../source/tcas.c.inst.exe 0 1 0 767 593 798 2 657 678 1 2 0     > ../newoutputs/t754
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/753.tr
echo ">>>>>>>>running test 755"
../source/tcas.c.inst.exe 833 0 1 648 385 621 0 446 0 0 2 1     > ../newoutputs/t755
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/754.tr
echo ">>>>>>>>running test 756"
../source/tcas.c.inst.exe 991 0 0 6052 411 45 0 1028 977 2 2 0     > ../newoutputs/t756
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/755.tr
echo ">>>>>>>>running test 757"
../source/tcas.c.inst.exe 1058 -1 0 643 495 661 0 1001 978 0 1 1     > ../newoutputs/t757
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/756.tr
echo ">>>>>>>>running test 758"
../source/tcas.c.inst.exe 693 0 1 639 352 609 1 470 793 0 2 0     > ../newoutputs/t758
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/757.tr
echo ">>>>>>>>running test 759"
../source/tcas.c.inst.exe 925 1 1 625 491 584 0 421 592 1 1 1     > ../newoutputs/t759
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/758.tr
echo ">>>>>>>>running test 760"
../source/tcas.c.inst.exe 810 1 0 0 296 50 1 446 -1 0 2 0     > ../newoutputs/t760
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/759.tr
echo ">>>>>>>>running test 761"
../source/tcas.c.inst.exe 855 1 0 4592 49 290 0 627 617 0 2 0     > ../newoutputs/t761
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/760.tr
echo ">>>>>>>>running test 762"
../source/tcas.c.inst.exe 834 1 0 638 378 0 2 0 842 0 2 1     > ../newoutputs/t762
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/761.tr
echo ">>>>>>>>running test 763"
../source/tcas.c.inst.exe 573 1 0 667 0 623 0 651 671 1 1 0     > ../newoutputs/t763
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/762.tr
echo ">>>>>>>>running test 764"
../source/tcas.c.inst.exe 1134 0 0 559 587 0 0 1003 0 0 2 0     > ../newoutputs/t764
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/763.tr
echo ">>>>>>>>running test 765"
../source/tcas.c.inst.exe 817 1 0 566 402 603 2 348 760 0 2 1     > ../newoutputs/t765
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/764.tr
echo ">>>>>>>>running test 766"
../source/tcas.c.inst.exe 610 0 0 0 587 665 3 673 722 0 2 1     > ../newoutputs/t766
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/765.tr
echo ">>>>>>>>running test 767"
../source/tcas.c.inst.exe -1 1 0 631 461 0 0 645 604 0 2 1     > ../newoutputs/t767
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/766.tr
echo ">>>>>>>>running test 768"
../source/tcas.c.inst.exe 1046 1 -1 565 505 553 1 -100 975 0 2 1     > ../newoutputs/t768
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/767.tr
echo ">>>>>>>>running test 769"
../source/tcas.c.inst.exe 832 1 0 562 347 788 0 0 785 2 2 1     > ../newoutputs/t769
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/768.tr
echo ">>>>>>>>running test 770"
../source/tcas.c.inst.exe 621 1 1 6021 353 718 1 320 561 0 1 1     > ../newoutputs/t770
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/769.tr
echo ">>>>>>>>running test 771"
../source/tcas.c.inst.exe 789 -1 0 707 518 636 3 137 0 0 1 1     > ../newoutputs/t771
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/770.tr
echo ">>>>>>>>running test 772"
../source/tcas.c.inst.exe 649 0 0 645 347 702 1 502 76 0 2 1     > ../newoutputs/t772
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/771.tr
echo ">>>>>>>>running test 773"
../source/tcas.c.inst.exe 657 1 0 666 0 613 0 840 976 0 2 0     > ../newoutputs/t773
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/772.tr
echo ">>>>>>>>running test 774"
../source/tcas.c.inst.exe 688 0 0 0 561 594 0 713 675 0 2 0     > ../newoutputs/t774
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/773.tr
echo ">>>>>>>>running test 775"
../source/tcas.c.inst.exe 612 1 0 555 479 560 4 0 651 0 2 1     > ../newoutputs/t775
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/774.tr
echo ">>>>>>>>running test 776"
../source/tcas.c.inst.exe 1046 0 0 8338 578 663 3 936 892 0 1 0     > ../newoutputs/t776
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/775.tr
echo ">>>>>>>>running test 777"
../source/tcas.c.inst.exe 1153 1 1 745 861 0 1 748 566 1 2 0     > ../newoutputs/t777
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/776.tr
echo ">>>>>>>>running test 778"
../source/tcas.c.inst.exe 824 1 0 0 519 426 1 357 694 0 2 0     > ../newoutputs/t778
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/777.tr
echo ">>>>>>>>running test 779"
../source/tcas.c.inst.exe 815 1 0 582 0 543 0 906 897 2 2 0     > ../newoutputs/t779
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/778.tr
echo ">>>>>>>>running test 780"
../source/tcas.c.inst.exe 1188 1 0 592 426 979 1 911 -1 2 2 1     > ../newoutputs/t780
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/779.tr
echo ">>>>>>>>running test 781"
../source/tcas.c.inst.exe 0 0 1 6241 380 757 3 0 890 0 2 0     > ../newoutputs/t781
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/780.tr
echo ">>>>>>>>running test 782"
../source/tcas.c.inst.exe 1132 1 0 0 607 565 1 351 593 2 2 1     > ../newoutputs/t782
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/781.tr
echo ">>>>>>>>running test 783"
../source/tcas.c.inst.exe 813 1 1 694 381 722 0 357 0 0 2 1     > ../newoutputs/t783
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/782.tr
echo ">>>>>>>>running test 784"
../source/tcas.c.inst.exe 1075 1 1 515 0 611 1 830 0 0 2 0     > ../newoutputs/t784
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/783.tr
echo ">>>>>>>>running test 785"
../source/tcas.c.inst.exe 1140 1 1 9266 412 763 0 344 384 2 2 0     > ../newoutputs/t785
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/784.tr
echo ">>>>>>>>running test 786"
../source/tcas.c.inst.exe 633 0 0 636 533 661 0 573 553 2 1 1     > ../newoutputs/t786
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/785.tr
echo ">>>>>>>>running test 787"
../source/tcas.c.inst.exe 1000 0 0 -100 566 687 1 477 241 0 1 0     > ../newoutputs/t787
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/786.tr
echo ">>>>>>>>running test 788"
../source/tcas.c.inst.exe 1022 1 0 647 988 694 1 0 0 0 2 0     > ../newoutputs/t788
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/787.tr
echo ">>>>>>>>running test 789"
../source/tcas.c.inst.exe 607 1 0 603 447 688 -1 787 829 0 2 0     > ../newoutputs/t789
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/788.tr
echo ">>>>>>>>running test 790"
../source/tcas.c.inst.exe -1 1 0 538 409 0 2 474 479 2 2 0     > ../newoutputs/t790
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/789.tr
echo ">>>>>>>>running test 791"
../source/tcas.c.inst.exe 627 0 0 697 398 828 -1 915 919 0 2 1     > ../newoutputs/t791
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/790.tr
echo ">>>>>>>>running test 792"
../source/tcas.c.inst.exe 892 1 1 1424 630 0 3 550 586 0 2 3     > ../newoutputs/t792
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/791.tr
echo ">>>>>>>>running test 793"
../source/tcas.c.inst.exe 764 1 0 9447 619 0 3 747 769 1 2 1     > ../newoutputs/t793
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/792.tr
echo ">>>>>>>>running test 794"
../source/tcas.c.inst.exe 664 0 1 693 536 655 1 -100 0 0 2 0     > ../newoutputs/t794
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/793.tr
echo ">>>>>>>>running test 795"
../source/tcas.c.inst.exe 1101 0 1 4426 372 625 1 518 566 0 2 0     > ../newoutputs/t795
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/794.tr
echo ">>>>>>>>running test 796"
../source/tcas.c.inst.exe 890 1 0 3344 502 537 1 417 578 0 2 0     > ../newoutputs/t796
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/795.tr
echo ">>>>>>>>running test 797"
../source/tcas.c.inst.exe 154 1 0 642 514 661 2 999 0 0 1 0     > ../newoutputs/t797
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/796.tr
echo ">>>>>>>>running test 798"
../source/tcas.c.inst.exe 774 0 0 0 623 664 0 817 807 0 2 1     > ../newoutputs/t798
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/797.tr
echo ">>>>>>>>running test 799"
../source/tcas.c.inst.exe 741 1 0 5872 449 649 2 0 -1 2 2 0     > ../newoutputs/t799
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/798.tr
echo ">>>>>>>>running test 800"
../source/tcas.c.inst.exe 739 1 0 7 609 597 3 0 343 0 2 0     > ../newoutputs/t800
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/799.tr
echo ">>>>>>>>running test 801"
../source/tcas.c.inst.exe 681 -1 1 9974 308 564 2 391 396 0 2 0     > ../newoutputs/t801
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/800.tr
echo ">>>>>>>>running test 802"
../source/tcas.c.inst.exe 789 1 1 635 557 720 4 694 0 0 2 1     > ../newoutputs/t802
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/801.tr
echo ">>>>>>>>running test 803"
../source/tcas.c.inst.exe 1009 1 1 606 320 530 2 0 0 0 2 1     > ../newoutputs/t803
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/802.tr
echo ">>>>>>>>running test 804"
../source/tcas.c.inst.exe 608 1 0 531 628 547 3 -1 482 1 2 1     > ../newoutputs/t804
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/803.tr
echo ">>>>>>>>running test 805"
../source/tcas.c.inst.exe 1200 0 1 626 534 642 0 758 744 1 2 1     > ../newoutputs/t805
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/804.tr
echo ">>>>>>>>running test 806"
../source/tcas.c.inst.exe 1181 0 0 714 351 781 0 419 0 0 1 1     > ../newoutputs/t806
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/805.tr
echo ">>>>>>>>running test 807"
../source/tcas.c.inst.exe 0 1 0 734 330 755 3 831 892 0 1 0     > ../newoutputs/t807
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/806.tr
echo ">>>>>>>>running test 808"
../source/tcas.c.inst.exe 994 0 1 7341 364 742 0 606 659 0 2 1     > ../newoutputs/t808
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/807.tr
echo ">>>>>>>>running test 809"
../source/tcas.c.inst.exe 586 0 1 790 79 0 0 689 677 0 2 0     > ../newoutputs/t809
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/808.tr
echo ">>>>>>>>running test 810"
../source/tcas.c.inst.exe -1 1 0 1231 543 671 2 545 545 0 2 1     > ../newoutputs/t810
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/809.tr
echo ">>>>>>>>running test 811"
../source/tcas.c.inst.exe 890 1 0 0 577 622 0 0 284 0 2 1     > ../newoutputs/t811
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/810.tr
echo ">>>>>>>>running test 812"
../source/tcas.c.inst.exe 695 1 0 560 0 578 3 807 988 0 2 1     > ../newoutputs/t812
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/811.tr
echo ">>>>>>>>running test 813"
../source/tcas.c.inst.exe 47 1 1 685 497 668 3 812 817 0 2 0     > ../newoutputs/t813
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/812.tr
echo ">>>>>>>>running test 814"
../source/tcas.c.inst.exe 1157 0 0 766 480 432 3 0 0 0 2 0     > ../newoutputs/t814
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/813.tr
echo ">>>>>>>>running test 815"
../source/tcas.c.inst.exe 659 1 0 0 865 578 3 452 538 1 2 1     > ../newoutputs/t815
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/814.tr
echo ">>>>>>>>running test 816"
../source/tcas.c.inst.exe 1046 1 0 531 505 557 2 261 0 0 1 0     > ../newoutputs/t816
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/815.tr
echo ">>>>>>>>running test 817"
../source/tcas.c.inst.exe 724 0 1 662 0 0 0 762 728 0 2 1     > ../newoutputs/t817
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/816.tr
echo ">>>>>>>>running test 818"
../source/tcas.c.inst.exe 989 1 1 714 693 746 2 960 903 0 2 9     > ../newoutputs/t818
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/817.tr
echo ">>>>>>>>running test 819"
../source/tcas.c.inst.exe 377 0 0 5169 412 572 3 801 797 0 2 1     > ../newoutputs/t819
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/818.tr
echo ">>>>>>>>running test 820"
../source/tcas.c.inst.exe 619 1 0 0 480 0 0 928 0 0 1 1     > ../newoutputs/t820
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/819.tr
echo ">>>>>>>>running test 821"
../source/tcas.c.inst.exe 879 1 1 793 310 -1 2 622 593 0 2 1     > ../newoutputs/t821
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/820.tr
echo ">>>>>>>>running test 822"
../source/tcas.c.inst.exe 635 1 0 585 -1 0 1 0 971 0 2 1     > ../newoutputs/t822
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/821.tr
echo ">>>>>>>>running test 823"
../source/tcas.c.inst.exe 0 0 0 621 413 714 2 416 360 0 2 1     > ../newoutputs/t823
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/822.tr
echo ">>>>>>>>running test 824"
../source/tcas.c.inst.exe -1 1 0 770 600 0 0 401 359 0 2 0     > ../newoutputs/t824
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/823.tr
echo ">>>>>>>>running test 825"
../source/tcas.c.inst.exe 674 1 0 679 472 655 3 523 -1 1 1 1     > ../newoutputs/t825
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/824.tr
echo ">>>>>>>>running test 826"
../source/tcas.c.inst.exe 1041 1 -1 0 494 660 3 68 546 0 2 0     > ../newoutputs/t826
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/825.tr
echo ">>>>>>>>running test 827"
../source/tcas.c.inst.exe 1136 1 0 600 151 0 2 699 867 0 2 1     > ../newoutputs/t827
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/826.tr
echo ">>>>>>>>running test 828"
../source/tcas.c.inst.exe -1 1 1 679 532 628 3 0 360 0 2 0     > ../newoutputs/t828
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/827.tr
echo ">>>>>>>>running test 829"
../source/tcas.c.inst.exe 890 1 1 0 523 931 1 880 866 2 2 1     > ../newoutputs/t829
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/828.tr
echo ">>>>>>>>running test 830"
../source/tcas.c.inst.exe 970 1 1 620 469 126 0 0 0 0 2 0     > ../newoutputs/t830
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/829.tr
echo ">>>>>>>>running test 831"
../source/tcas.c.inst.exe 1195 1 1 622 378 621 2 520 0 2 2 0     > ../newoutputs/t831
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/830.tr
echo ">>>>>>>>running test 832"
../source/tcas.c.inst.exe 834 0 0 573 887 599 1 0 874 0 2 0     > ../newoutputs/t832
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/831.tr
echo ">>>>>>>>running test 833"
../source/tcas.c.inst.exe 629 0 1 615 603 663 0 897 874 -1 1 1     > ../newoutputs/t833
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/832.tr
echo ">>>>>>>>running test 834"
../source/tcas.c.inst.exe 1145 1 0 718 520 628 0 639 0 3 2 1     > ../newoutputs/t834
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/833.tr
echo ">>>>>>>>running test 835"
../source/tcas.c.inst.exe 623 -1 0 683 461 732 3 634 671 0 2 1     > ../newoutputs/t835
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/834.tr
echo ">>>>>>>>running test 836"
../source/tcas.c.inst.exe 774 0 0 654 427 636 1 0 0 1 2 1     > ../newoutputs/t836
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/835.tr
echo ">>>>>>>>running test 837"
../source/tcas.c.inst.exe 653 1 1 688 592 709 3 883 849 0 1 -1     > ../newoutputs/t837
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/836.tr
echo ">>>>>>>>running test 838"
../source/tcas.c.inst.exe 987 0 1 740 67 735 3 330 326 0 2 1     > ../newoutputs/t838
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/837.tr
echo ">>>>>>>>running test 839"
../source/tcas.c.inst.exe 852 1 0 694 586 708 1 -100 621 0 2 1     > ../newoutputs/t839
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/838.tr
echo ">>>>>>>>running test 840"
../source/tcas.c.inst.exe 847 1 0 626 888 580 1 0 172 0 2 1     > ../newoutputs/t840
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/839.tr
echo ">>>>>>>>running test 841"
../source/tcas.c.inst.exe 1099 1 1 670 349 680 3 729 789 2 2 0     > ../newoutputs/t841
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/840.tr
echo ">>>>>>>>running test 842"
../source/tcas.c.inst.exe 841 1 0 0 351 719 3 485 0 0 1 0     > ../newoutputs/t842
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/841.tr
echo ">>>>>>>>running test 843"
../source/tcas.c.inst.exe 929 0 0 0 408 754 0 211 941 0 2 1     > ../newoutputs/t843
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/842.tr
echo ">>>>>>>>running test 844"
../source/tcas.c.inst.exe 691 0 0 0 548 737 1 410 364 1 1 0     > ../newoutputs/t844
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/843.tr
echo ">>>>>>>>running test 845"
../source/tcas.c.inst.exe 0 0 1 604 473 650 3 536 0 0 2 1     > ../newoutputs/t845
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/844.tr
echo ">>>>>>>>running test 846"
../source/tcas.c.inst.exe 1002 1 0 706 306 668 2 0 -100 0 2 1     > ../newoutputs/t846
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/845.tr
echo ">>>>>>>>running test 847"
../source/tcas.c.inst.exe 819 1 1 9386 518 775 1 707 726 2 2 0     > ../newoutputs/t847
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/846.tr
echo ">>>>>>>>running test 848"
../source/tcas.c.inst.exe 1077 1 -1 593 324 636 2 0 448 0 2 1     > ../newoutputs/t848
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/847.tr
echo ">>>>>>>>running test 849"
../source/tcas.c.inst.exe 822 1 1 701 453 872 2 851 849 0 2 9     > ../newoutputs/t849
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/848.tr
echo ">>>>>>>>running test 850"
../source/tcas.c.inst.exe 925 1 -1 650 432 655 0 859 891 0 2 0     > ../newoutputs/t850
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/849.tr
echo ">>>>>>>>running test 851"
../source/tcas.c.inst.exe 1162 1 1 1025 344 631 3 453 466 0 2 4     > ../newoutputs/t851
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/850.tr
echo ">>>>>>>>running test 852"
../source/tcas.c.inst.exe 1078 1 0 581 567 655 3 637 906 2 2 0     > ../newoutputs/t852
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/851.tr
echo ">>>>>>>>running test 853"
../source/tcas.c.inst.exe 777 1 0 646 616 628 2 904 0 0 1 1     > ../newoutputs/t853
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/852.tr
echo ">>>>>>>>running test 854"
../source/tcas.c.inst.exe 782 1 0 0 418 610 1 0 618 0 2 0     > ../newoutputs/t854
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/853.tr
echo ">>>>>>>>running test 855"
../source/tcas.c.inst.exe 1084 1 1 995 501 604 2 0 482 -1 2 1     > ../newoutputs/t855
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/854.tr
echo ">>>>>>>>running test 856"
../source/tcas.c.inst.exe 1013 1 0 643 373 706 3 0 808 2 2 1     > ../newoutputs/t856
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/855.tr
echo ">>>>>>>>running test 857"
../source/tcas.c.inst.exe -1 1 0 706 291 643 1 644 564 0 2 0     > ../newoutputs/t857
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/856.tr
echo ">>>>>>>>running test 858"
../source/tcas.c.inst.exe 0 1 0 552 382 612 1 0 754 0 2 1     > ../newoutputs/t858
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/857.tr
echo ">>>>>>>>running test 859"
../source/tcas.c.inst.exe 733 1 1 590 341 589 3 534 620 1 2 0     > ../newoutputs/t859
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/858.tr
echo ">>>>>>>>running test 860"
../source/tcas.c.inst.exe 706 1 1 4649 316 935 3 605 850 0 2 1     > ../newoutputs/t860
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/859.tr
echo ">>>>>>>>running test 861"
../source/tcas.c.inst.exe 0 1 1 2311 594 715 3 906 926 0 2 1     > ../newoutputs/t861
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/860.tr
echo ">>>>>>>>running test 862"
../source/tcas.c.inst.exe 995 1 1 756 419 339 0 0 540 0 2 0     > ../newoutputs/t862
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/861.tr
echo ">>>>>>>>running test 863"
../source/tcas.c.inst.exe 850 1 0 187 443 542 0 410 407 4 2 0     > ../newoutputs/t863
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/862.tr
echo ">>>>>>>>running test 864"
../source/tcas.c.inst.exe 878 1 1 0 321 0 2 550 596 0 2 0     > ../newoutputs/t864
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/863.tr
echo ">>>>>>>>running test 865"
../source/tcas.c.inst.exe 1146 0 0 0 550 530 2 899 857 0 1 0     > ../newoutputs/t865
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/864.tr
echo ">>>>>>>>running test 866"
../source/tcas.c.inst.exe 862 1 0 0 383 0 2 474 721 0 2 1     > ../newoutputs/t866
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/865.tr
echo ">>>>>>>>running test 867"
../source/tcas.c.inst.exe 757 1 1 692 581 640 1 840 841 1 2 0     > ../newoutputs/t867
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/866.tr
echo ">>>>>>>>running test 868"
../source/tcas.c.inst.exe 692 0 0 0 439 655 3 852 539 0 2 0     > ../newoutputs/t868
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/867.tr
echo ">>>>>>>>running test 869"
../source/tcas.c.inst.exe 1165 1 0 592 -1 605 0 0 596 0 2 1     > ../newoutputs/t869
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/868.tr
echo ">>>>>>>>running test 870"
../source/tcas.c.inst.exe 760 1 -1 0 314 0 3 452 423 0 2 1     > ../newoutputs/t870
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/869.tr
echo ">>>>>>>>running test 871"
../source/tcas.c.inst.exe 948 0 1 584 415 574 3 665 642 2 2 1     > ../newoutputs/t871
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/870.tr
echo ">>>>>>>>running test 872"
../source/tcas.c.inst.exe -100 0 0 1879 547 626 0 854 875 0 2 0     > ../newoutputs/t872
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/871.tr
echo ">>>>>>>>running test 873"
../source/tcas.c.inst.exe 615 0 0 2299 456 549 0 748 0 2 2 0     > ../newoutputs/t873
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/872.tr
echo ">>>>>>>>running test 874"
../source/tcas.c.inst.exe 1117 0 1 0 569 0 2 716 741 0 2 1     > ../newoutputs/t874
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/873.tr
echo ">>>>>>>>running test 875"
../source/tcas.c.inst.exe 818 1 1 563 554 999 1 0 615 1 2 1     > ../newoutputs/t875
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/874.tr
echo ">>>>>>>>running test 876"
../source/tcas.c.inst.exe 780 1 0 6500 579 -1 1 730 683 0 2 0     > ../newoutputs/t876
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/875.tr
echo ">>>>>>>>running test 877"
../source/tcas.c.inst.exe 463 1 1 0 387 590 1 907 867 0 1 0     > ../newoutputs/t877
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/876.tr
echo ">>>>>>>>running test 878"
../source/tcas.c.inst.exe 990 1 1 0 325 0 0 727 665 0 2 1     > ../newoutputs/t878
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/877.tr
echo ">>>>>>>>running test 879"
../source/tcas.c.inst.exe 952 1 0 588 0 774 0 593 639 -1 2 0     > ../newoutputs/t879
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/878.tr
echo ">>>>>>>>running test 880"
../source/tcas.c.inst.exe 1019 1 0 4248 0 551 2 544 550 1 2 1     > ../newoutputs/t880
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/879.tr
echo ">>>>>>>>running test 881"
../source/tcas.c.inst.exe 974 1 0 611 978 521 3 0 962 2 1 0     > ../newoutputs/t881
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/880.tr
echo ">>>>>>>>running test 882"
../source/tcas.c.inst.exe -1 1 1 576 500 0 0 641 883 4 2 1     > ../newoutputs/t882
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/881.tr
echo ">>>>>>>>running test 883"
../source/tcas.c.inst.exe 868 1 1 729 501 740 3 1017 0 0 2 1     > ../newoutputs/t883
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/882.tr
echo ">>>>>>>>running test 884"
../source/tcas.c.inst.exe 1084 1 1 704 538 707 2 0 -1 0 2 0     > ../newoutputs/t884
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/883.tr
echo ">>>>>>>>running test 885"
../source/tcas.c.inst.exe 935 1 0 4528 388 0 0 853 956 0 2 0     > ../newoutputs/t885
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/884.tr
echo ">>>>>>>>running test 886"
../source/tcas.c.inst.exe 1058 1 1 365 560 652 1 0 682 0 2 0     > ../newoutputs/t886
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/885.tr
echo ">>>>>>>>running test 887"
../source/tcas.c.inst.exe 1032 1 1 7944 330 0 1 361 0 0 2 1     > ../newoutputs/t887
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/886.tr
echo ">>>>>>>>running test 888"
../source/tcas.c.inst.exe 987 1 0 642 606 0 0 413 0 0 2 1     > ../newoutputs/t888
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/887.tr
echo ">>>>>>>>running test 889"
../source/tcas.c.inst.exe 994 1 0 647 755 410 0 564 548 1 2 1     > ../newoutputs/t889
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/888.tr
echo ">>>>>>>>running test 890"
../source/tcas.c.inst.exe 911 1 0 527 516 541 0 0 465 2 1 0     > ../newoutputs/t890
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/889.tr
echo ">>>>>>>>running test 891"
../source/tcas.c.inst.exe 754 1 0 0 335 604 3 531 453 3 2 1     > ../newoutputs/t891
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/890.tr
echo ">>>>>>>>running test 892"
../source/tcas.c.inst.exe 856 0 1 5631 380 590 0 961 695 0 2 0     > ../newoutputs/t892
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/891.tr
echo ">>>>>>>>running test 893"
../source/tcas.c.inst.exe 36 0 0 622 340 620 1 0 423 0 1 0     > ../newoutputs/t893
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/892.tr
echo ">>>>>>>>running test 894"
../source/tcas.c.inst.exe 716 1 1 618 341 767 1 0 0 0 2 1     > ../newoutputs/t894
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/893.tr
echo ">>>>>>>>running test 895"
../source/tcas.c.inst.exe 753 1 1 620 583 650 1 826 779 2 1 0     > ../newoutputs/t895
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/894.tr
echo ">>>>>>>>running test 896"
../source/tcas.c.inst.exe 872 1 1 0 669 561 1 955 931 0 2 0     > ../newoutputs/t896
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/895.tr
echo ">>>>>>>>running test 897"
../source/tcas.c.inst.exe 1119 0 0 749 332 696 1 533 526 1 2 0     > ../newoutputs/t897
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/896.tr
echo ">>>>>>>>running test 898"
../source/tcas.c.inst.exe 1032 1 0 5936 652 0 2 893 920 0 2 0     > ../newoutputs/t898
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/897.tr
echo ">>>>>>>>running test 899"
../source/tcas.c.inst.exe 903 1 1 577 396 -100 2 314 515 0 2 0     > ../newoutputs/t899
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/898.tr
echo ">>>>>>>>running test 900"
../source/tcas.c.inst.exe 1130 1 1 8164 493 665 2 421 424 0 2 -1     > ../newoutputs/t900
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/899.tr
echo ">>>>>>>>running test 901"
../source/tcas.c.inst.exe -1 1 1 9836 458 698 2 530 552 2 1 0     > ../newoutputs/t901
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/900.tr
echo ">>>>>>>>running test 902"
../source/tcas.c.inst.exe 1141 0 1 687 434 690 0 0 438 0 1 0     > ../newoutputs/t902
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/901.tr
echo ">>>>>>>>running test 903"
../source/tcas.c.inst.exe 692 0 1 650 353 2 3 408 435 1 2 1     > ../newoutputs/t903
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/902.tr
echo ">>>>>>>>running test 904"
../source/tcas.c.inst.exe 814 -1 1 652 309 705 2 716 687 0 1 0     > ../newoutputs/t904
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/903.tr
echo ">>>>>>>>running test 905"
../source/tcas.c.inst.exe 722 1 0 693 573 674 1 862 822 0 2 3     > ../newoutputs/t905
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/904.tr
echo ">>>>>>>>running test 906"
../source/tcas.c.inst.exe 1089 1 0 0 587 0 0 449 -100 1 2 1     > ../newoutputs/t906
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/905.tr
echo ">>>>>>>>running test 907"
../source/tcas.c.inst.exe 986 1 1 535 478 521 2 934 874 1 1 1     > ../newoutputs/t907
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/906.tr
echo ">>>>>>>>running test 908"
../source/tcas.c.inst.exe 609 1 1 8407 595 583 2 560 485 0 2 0     > ../newoutputs/t908
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/907.tr
echo ">>>>>>>>running test 909"
../source/tcas.c.inst.exe 898 1 0 688 0 741 1 703 44 0 2 1     > ../newoutputs/t909
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/908.tr
echo ">>>>>>>>running test 910"
../source/tcas.c.inst.exe 1154 1 1 552 433 593 4 727 829 0 2 9     > ../newoutputs/t910
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/909.tr
echo ">>>>>>>>running test 911"
../source/tcas.c.inst.exe 856 1 1 574 -100 515 3 941 674 0 2 1     > ../newoutputs/t911
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/910.tr
echo ">>>>>>>>running test 912"
../source/tcas.c.inst.exe 1034 1 0 642 397 581 1 445 -1 0 1 0     > ../newoutputs/t912
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/911.tr
echo ">>>>>>>>running test 913"
../source/tcas.c.inst.exe 840 1 1 0 515 573 0 0 54 0 1 0     > ../newoutputs/t913
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/912.tr
echo ">>>>>>>>running test 914"
../source/tcas.c.inst.exe 757 1 0 0 527 205 3 698 750 2 2 0     > ../newoutputs/t914
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/913.tr
echo ">>>>>>>>running test 915"
../source/tcas.c.inst.exe 397 1 1 685 603 656 2 501 991 0 2 1     > ../newoutputs/t915
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/914.tr
echo ">>>>>>>>running test 916"
../source/tcas.c.inst.exe 793 1 1 8753 425 622 1 744 0 0 2 0     > ../newoutputs/t916
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/915.tr
echo ">>>>>>>>running test 917"
../source/tcas.c.inst.exe 1084 1 0 58 197 731 2 547 984 0 2 0     > ../newoutputs/t917
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/916.tr
echo ">>>>>>>>running test 918"
../source/tcas.c.inst.exe 1156 1 1 9408 599 0 0 904 902 0 2 0     > ../newoutputs/t918
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/917.tr
echo ">>>>>>>>running test 919"
../source/tcas.c.inst.exe 721 1 0 690 438 613 2 0 991 0 2 1     > ../newoutputs/t919
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/918.tr
echo ">>>>>>>>running test 920"
../source/tcas.c.inst.exe 0 1 0 709 851 776 3 214 588 0 2 0     > ../newoutputs/t920
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/919.tr
echo ">>>>>>>>running test 921"
../source/tcas.c.inst.exe -100 1 1 753 474 747 1 920 420 0 2 0     > ../newoutputs/t921
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/920.tr
echo ">>>>>>>>running test 922"
../source/tcas.c.inst.exe 133 1 1 611 507 0 2 801 860 0 2 0     > ../newoutputs/t922
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/921.tr
echo ">>>>>>>>running test 923"
../source/tcas.c.inst.exe 988 1 1 -1 312 655 2 749 734 0 1 1     > ../newoutputs/t923
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/922.tr
echo ">>>>>>>>running test 924"
../source/tcas.c.inst.exe 1171 0 1 718 630 688 3 252 769 0 1 1     > ../newoutputs/t924
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/923.tr
echo ">>>>>>>>running test 925"
../source/tcas.c.inst.exe 1065 1 0 -1 597 582 3 840 881 2 2 0     > ../newoutputs/t925
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/924.tr
echo ">>>>>>>>running test 926"
../source/tcas.c.inst.exe 619 1 -1 746 349 961 0 0 868 0 2 0     > ../newoutputs/t926
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/925.tr
echo ">>>>>>>>running test 927"
../source/tcas.c.inst.exe 911 1 0 -1 549 -100 3 396 383 0 2 0     > ../newoutputs/t927
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/926.tr
echo ">>>>>>>>running test 928"
../source/tcas.c.inst.exe 1001 1 1 737 -100 741 1 828 0 0 2 0     > ../newoutputs/t928
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/927.tr
echo ">>>>>>>>running test 929"
../source/tcas.c.inst.exe 590 1 0 610 325 417 1 578 287 0 2 0     > ../newoutputs/t929
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/928.tr
echo ">>>>>>>>running test 930"
../source/tcas.c.inst.exe 1062 1 1 1941 575 682 3 872 880 1 2 0     > ../newoutputs/t930
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/929.tr
echo ">>>>>>>>running test 931"
../source/tcas.c.inst.exe 604 1 0 652 354 0 2 371 323 2 2 1     > ../newoutputs/t931
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/930.tr
echo ">>>>>>>>running test 932"
../source/tcas.c.inst.exe 1130 0 0 581 426 657 0 848 0 0 2 0     > ../newoutputs/t932
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/931.tr
echo ">>>>>>>>running test 933"
../source/tcas.c.inst.exe 924 0 0 770 424 756 2 0 0 0 2 1     > ../newoutputs/t933
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/932.tr
echo ">>>>>>>>running test 934"
../source/tcas.c.inst.exe 1129 1 1 2950 208 669 1 724 512 0 2 0     > ../newoutputs/t934
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/933.tr
echo ">>>>>>>>running test 935"
../source/tcas.c.inst.exe 599 1 1 654 522 0 0 659 399 0 2 0     > ../newoutputs/t935
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/934.tr
echo ">>>>>>>>running test 936"
../source/tcas.c.inst.exe 954 1 0 672 625 744 2 732 810 2 2 1     > ../newoutputs/t936
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/935.tr
echo ">>>>>>>>running test 937"
../source/tcas.c.inst.exe 972 1 1 460 299 688 1 440 0 0 1 1     > ../newoutputs/t937
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/936.tr
echo ">>>>>>>>running test 938"
../source/tcas.c.inst.exe 0 1 1 522 555 530 1 933 914 2 2 0     > ../newoutputs/t938
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/937.tr
echo ">>>>>>>>running test 939"
../source/tcas.c.inst.exe 801 1 0 782 524 0 3 381 435 0 1 0     > ../newoutputs/t939
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/938.tr
echo ">>>>>>>>running test 940"
../source/tcas.c.inst.exe 0 0 0 598 440 637 2 437 455 0 2 0     > ../newoutputs/t940
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/939.tr
echo ">>>>>>>>running test 941"
../source/tcas.c.inst.exe 817 0 1 0 364 15 0 886 851 0 2 1     > ../newoutputs/t941
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/940.tr
echo ">>>>>>>>running test 942"
../source/tcas.c.inst.exe 1157 1 1 0 563 797 2 459 58 0 2 0     > ../newoutputs/t942
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/941.tr
echo ">>>>>>>>running test 943"
../source/tcas.c.inst.exe 1151 1 0 578 611 0 0 331 378 0 1 1     > ../newoutputs/t943
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/942.tr
echo ">>>>>>>>running test 944"
../source/tcas.c.inst.exe 1149 1 1 0 527 607 3 818 860 2 1 0     > ../newoutputs/t944
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/943.tr
echo ">>>>>>>>running test 945"
../source/tcas.c.inst.exe 1079 1 0 613 397 0 3 524 477 1 2 0     > ../newoutputs/t945
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/944.tr
echo ">>>>>>>>running test 946"
../source/tcas.c.inst.exe 949 1 0 648 515 619 2 0 825 0 2 0     > ../newoutputs/t946
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/945.tr
echo ">>>>>>>>running test 947"
../source/tcas.c.inst.exe 1078 1 0 589 605 584 1 -1 323 0 2 1     > ../newoutputs/t947
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/946.tr
echo ">>>>>>>>running test 948"
../source/tcas.c.inst.exe 903 0 1 660 612 703 1 867 883 0 2 1     > ../newoutputs/t948
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/947.tr
echo ">>>>>>>>running test 949"
../source/tcas.c.inst.exe 1159 1 0 730 910 738 0 740 747 1 2 1     > ../newoutputs/t949
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/948.tr
echo ">>>>>>>>running test 950"
../source/tcas.c.inst.exe 1156 1 0 693 104 674 2 499 883 2 2 1     > ../newoutputs/t950
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/949.tr
echo ">>>>>>>>running test 951"
../source/tcas.c.inst.exe 886 0 0 5515 447 700 3 478 597 0 2 0     > ../newoutputs/t951
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/950.tr
echo ">>>>>>>>running test 952"
../source/tcas.c.inst.exe 1107 1 1 665 853 701 0 653 892 1 2 1     > ../newoutputs/t952
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/951.tr
echo ">>>>>>>>running test 953"
../source/tcas.c.inst.exe 655 1 0 749 487 139 2 477 850 0 2 0     > ../newoutputs/t953
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/952.tr
echo ">>>>>>>>running test 954"
../source/tcas.c.inst.exe 1184 -1 0 0 391 534 3 491 476 0 2 1     > ../newoutputs/t954
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/953.tr
echo ">>>>>>>>running test 955"
../source/tcas.c.inst.exe 879 0 0 0 -100 728 0 517 507 0 2 1     > ../newoutputs/t955
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/954.tr
echo ">>>>>>>>running test 956"
../source/tcas.c.inst.exe 826 1 0 655 326 577 0 0 425 1 2 0     > ../newoutputs/t956
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/955.tr
echo ">>>>>>>>running test 957"
../source/tcas.c.inst.exe 323 1 0 4964 498 697 3 780 810 0 2 1     > ../newoutputs/t957
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/956.tr
echo ">>>>>>>>running test 958"
../source/tcas.c.inst.exe 1084 1 1 703 387 726 3 384 0 1 2 1     > ../newoutputs/t958
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/957.tr
echo ">>>>>>>>running test 959"
../source/tcas.c.inst.exe 988 1 0 622 496 613 1 379 404 0 2 0     > ../newoutputs/t959
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/958.tr
echo ">>>>>>>>running test 960"
../source/tcas.c.inst.exe 1039 -1 1 630 618 0 3 0 801 1 2 1     > ../newoutputs/t960
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/959.tr
echo ">>>>>>>>running test 961"
../source/tcas.c.inst.exe 1185 1 1 595 0 534 1 560 0 0 2 1     > ../newoutputs/t961
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/960.tr
echo ">>>>>>>>running test 962"
../source/tcas.c.inst.exe 700 1 0 575 415 -1 0 795 796 2 2 0     > ../newoutputs/t962
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/961.tr
echo ">>>>>>>>running test 963"
../source/tcas.c.inst.exe 665 1 1 585 445 533 0 209 848 0 2 1     > ../newoutputs/t963
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/962.tr
echo ">>>>>>>>running test 964"
../source/tcas.c.inst.exe 820 1 1 561 0 599 2 993 817 0 2 0     > ../newoutputs/t964
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/963.tr
echo ">>>>>>>>running test 965"
../source/tcas.c.inst.exe 1189 1 1 753 620 761 2 0 185 0 1 0     > ../newoutputs/t965
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/964.tr
echo ">>>>>>>>running test 966"
../source/tcas.c.inst.exe 910 1 1 722 601 707 3 0 0 0 2 0     > ../newoutputs/t966
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/965.tr
echo ">>>>>>>>running test 967"
../source/tcas.c.inst.exe 986 1 1 618 321 595 1 0 418 0 1 4     > ../newoutputs/t967
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/966.tr
echo ">>>>>>>>running test 968"
../source/tcas.c.inst.exe 1079 1 1 631 547 663 2 401 314 4 1 0     > ../newoutputs/t968
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/967.tr
echo ">>>>>>>>running test 969"
../source/tcas.c.inst.exe 204 1 0 707 601 741 1 695 652 2 2 1     > ../newoutputs/t969
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/968.tr
echo ">>>>>>>>running test 970"
../source/tcas.c.inst.exe 797 0 0 8545 149 589 3 278 280 1 1 1     > ../newoutputs/t970
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/969.tr
echo ">>>>>>>>running test 971"
../source/tcas.c.inst.exe -100 1 0 1362 527 922 2 437 358 0 2 1     > ../newoutputs/t971
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/970.tr
echo ">>>>>>>>running test 972"
../source/tcas.c.inst.exe 965 1 1 7468 524 693 1 830 0 0 2 0     > ../newoutputs/t972
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/971.tr
echo ">>>>>>>>running test 973"
../source/tcas.c.inst.exe 0 1 0 7119 153 556 2 836 841 1 1 1     > ../newoutputs/t973
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/972.tr
echo ">>>>>>>>running test 974"
../source/tcas.c.inst.exe 1006 0 -1 8234 374 598 1 811 514 0 2 0     > ../newoutputs/t974
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/973.tr
echo ">>>>>>>>running test 975"
../source/tcas.c.inst.exe 830 1 0 -1 473 631 3 22 0 0 2 1     > ../newoutputs/t975
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/974.tr
echo ">>>>>>>>running test 976"
../source/tcas.c.inst.exe 904 1 0 530 438 0 2 951 0 1 2 0     > ../newoutputs/t976
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/975.tr
echo ">>>>>>>>running test 977"
../source/tcas.c.inst.exe 638 0 1 545 325 589 1 900 798 0 2 0     > ../newoutputs/t977
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/976.tr
echo ">>>>>>>>running test 978"
../source/tcas.c.inst.exe 0 1 -1 0 388 737 3 0 470 0 2 1     > ../newoutputs/t978
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/977.tr
echo ">>>>>>>>running test 979"
../source/tcas.c.inst.exe 1053 1 0 6178 547 127 0 518 489 0 2 0     > ../newoutputs/t979
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/978.tr
echo ">>>>>>>>running test 980"
../source/tcas.c.inst.exe 610 1 1 611 0 616 1 541 578 9 2 1     > ../newoutputs/t980
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/979.tr
echo ">>>>>>>>running test 981"
../source/tcas.c.inst.exe 899 1 1 -100 601 571 3 618 595 4 1 0     > ../newoutputs/t981
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/980.tr
echo ">>>>>>>>running test 982"
../source/tcas.c.inst.exe 1085 1 1 1017 510 614 0 595 614 2 2 4     > ../newoutputs/t982
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/981.tr
echo ">>>>>>>>running test 983"
../source/tcas.c.inst.exe 650 1 1 0 197 701 0 682 711 0 2 -1     > ../newoutputs/t983
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/982.tr
echo ">>>>>>>>running test 984"
../source/tcas.c.inst.exe 1015 0 1 600 526 629 1 569 0 0 2 1     > ../newoutputs/t984
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/983.tr
echo ">>>>>>>>running test 985"
../source/tcas.c.inst.exe -100 0 1 3803 419 630 3 -1 437 0 2 1     > ../newoutputs/t985
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/984.tr
echo ">>>>>>>>running test 986"
../source/tcas.c.inst.exe 598 0 0 639 0 327 1 411 374 0 2 0     > ../newoutputs/t986
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/985.tr
echo ">>>>>>>>running test 987"
../source/tcas.c.inst.exe 1118 0 1 725 0 756 2 860 846 0 2 1     > ../newoutputs/t987
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/986.tr
echo ">>>>>>>>running test 988"
../source/tcas.c.inst.exe 652 1 0 -100 478 779 0 356 371 -1 2 0     > ../newoutputs/t988
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/987.tr
echo ">>>>>>>>running test 989"
../source/tcas.c.inst.exe 698 1 0 3071 59 307 0 849 904 0 2 0     > ../newoutputs/t989
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/988.tr
echo ">>>>>>>>running test 990"
../source/tcas.c.inst.exe 734 1 1 615 -100 591 2 889 -1 0 2 0     > ../newoutputs/t990
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/989.tr
echo ">>>>>>>>running test 991"
../source/tcas.c.inst.exe 628 1 0 706 1 976 0 417 652 2 2 1     > ../newoutputs/t991
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/990.tr
echo ">>>>>>>>running test 992"
../source/tcas.c.inst.exe 913 1 1 661 -100 255 3 0 668 0 2 0     > ../newoutputs/t992
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/991.tr
echo ">>>>>>>>running test 993"
../source/tcas.c.inst.exe 618 0 1 754 390 215 0 250 830 0 2 1     > ../newoutputs/t993
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/992.tr
echo ">>>>>>>>running test 994"
../source/tcas.c.inst.exe 617 0 1 640 441 662 1 677 528 4 2 1     > ../newoutputs/t994
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/993.tr
echo ">>>>>>>>running test 995"
../source/tcas.c.inst.exe 766 1 0 719 300 700 3 406 378 1 1 1     > ../newoutputs/t995
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/994.tr
echo ">>>>>>>>running test 996"
../source/tcas.c.inst.exe 119 1 0 715 292 212 0 322 341 0 2 1     > ../newoutputs/t996
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/995.tr
echo ">>>>>>>>running test 997"
../source/tcas.c.inst.exe 939 1 1 532 534 -100 2 335 971 1 2 1     > ../newoutputs/t997
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/996.tr
echo ">>>>>>>>running test 998"
../source/tcas.c.inst.exe 190 1 1 724 567 715 1 1011 1021 1 2 1     > ../newoutputs/t998
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/997.tr
echo ">>>>>>>>running test 999"
../source/tcas.c.inst.exe -100 1 1 680 602 702 0 831 860 2 2 1     > ../newoutputs/t999
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/998.tr
echo ">>>>>>>>running test 1000"
../source/tcas.c.inst.exe 685 1 0 586 0 601 1 646 701 0 1 0     > ../newoutputs/t1000
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/999.tr
echo ">>>>>>>>running test 1001"
../source/tcas.c.inst.exe  679 1 1  541  338 5123 0  641  641 0 0 1     > ../newoutputs/t1001
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1000.tr
echo ">>>>>>>>running test 1002"
../source/tcas.c.inst.exe  644 1 1 1886  596 2348 0  741  400 1 0 0     > ../newoutputs/t1002
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1001.tr
echo ">>>>>>>>running test 1003"
../source/tcas.c.inst.exe  722 1 1 1415  245  316 0  401  739 0 0 0     > ../newoutputs/t1003
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1002.tr
echo ">>>>>>>>running test 1004"
../source/tcas.c.inst.exe  722 1 1 1415  275  316 0  401  799 0 0 0     > ../newoutputs/t1004
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1003.tr
echo ">>>>>>>>running test 1005"
../source/tcas.c.inst.exe  782 1 1  513  224 5295 0  641  639 0 1 1     > ../newoutputs/t1005
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1004.tr
echo ">>>>>>>>running test 1006"
../source/tcas.c.inst.exe  782 1 1  413  224 4295 0  641  639 0 1 1     > ../newoutputs/t1006
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1005.tr
echo ">>>>>>>>running test 1007"
../source/tcas.c.inst.exe  786 1 1  383  548 5870 0  639  399 1 0 1     > ../newoutputs/t1007
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1006.tr
echo ">>>>>>>>running test 1008"
../source/tcas.c.inst.exe  786 1 1  383  448 4870 0  639  399 1 0 1     > ../newoutputs/t1008
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1007.tr
echo ">>>>>>>>running test 1009"
../source/tcas.c.inst.exe  638 1 0 2578  156 3757 0  400  399 1 0 1     > ../newoutputs/t1009
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1008.tr
echo ">>>>>>>>running test 1010"
../source/tcas.c.inst.exe  638 1 0 2278  156 3757 0  650  399 1 0 1     > ../newoutputs/t1010
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1009.tr
echo ">>>>>>>>running test 1011"
../source/tcas.c.inst.exe  727 1 1 1935  339  968 0  399  740 0 1 1     > ../newoutputs/t1011
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1010.tr
echo ">>>>>>>>running test 1012"
../source/tcas.c.inst.exe  927 1 1 4902  351 2093 0  739  740 1 0 0     > ../newoutputs/t1012
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1011.tr
echo ">>>>>>>>running test 1013"
../source/tcas.c.inst.exe  927 1 1 4702  251 1093 0  739  740 1 0 0     > ../newoutputs/t1013
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1012.tr
echo ">>>>>>>>running test 1014"
../source/tcas.c.inst.exe  867 1 1 1774  101 2204 0  499  499 1 0 1     > ../newoutputs/t1014
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1013.tr
echo ">>>>>>>>running test 1015"
../source/tcas.c.inst.exe  867 1 1 1674  101 2104 0  499  499 1 0 1     > ../newoutputs/t1015
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1014.tr
echo ">>>>>>>>running test 1016"
../source/tcas.c.inst.exe  653 1 0 3203  448 1267 0  541  641 0 0 0     > ../newoutputs/t1016
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1015.tr
echo ">>>>>>>>running test 1017"
../source/tcas.c.inst.exe  653 1 0 3203  448 1267 0  541  641 1 0 0     > ../newoutputs/t1017
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1016.tr
echo ">>>>>>>>running test 1018"
../source/tcas.c.inst.exe  653 1 0  632  167  203 0  401  401 1 0 0     > ../newoutputs/t1018
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1017.tr
echo ">>>>>>>>running test 1019"
../source/tcas.c.inst.exe  958 1 1 2297  574 4253 0  399  400 0 0 1     > ../newoutputs/t1019
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1018.tr
echo ">>>>>>>>running test 1020"
../source/tcas.c.inst.exe  958 1 1 2297  574 4253 0  399  300 0 0 1     > ../newoutputs/t1020
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1019.tr
echo ">>>>>>>>running test 1021"
../source/tcas.c.inst.exe  958 1 1 2297  574 4253 0  399  300 1 0 1     > ../newoutputs/t1021
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1020.tr
echo ">>>>>>>>running test 1022"
../source/tcas.c.inst.exe  635 1 0 1142  411 4704 1  740  500 0 0 1     > ../newoutputs/t1022
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1021.tr
echo ">>>>>>>>running test 1023"
../source/tcas.c.inst.exe  635 1 0 1142  511 2704 1  740  500 0 0 1     > ../newoutputs/t1023
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1022.tr
echo ">>>>>>>>running test 1024"
../source/tcas.c.inst.exe  635 1 0 1142  511 2704 1  740  500 1 0 1     > ../newoutputs/t1024
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1023.tr
echo ">>>>>>>>running test 1025"
../source/tcas.c.inst.exe  635 1 0 1142  511 1704 1  740  500 1 0 1     > ../newoutputs/t1025
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1024.tr
echo ">>>>>>>>running test 1026"
../source/tcas.c.inst.exe  635 1 0 1142  411 1704 1  740  500 1 0 1     > ../newoutputs/t1026
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1025.tr
echo ">>>>>>>>running test 1027"
../source/tcas.c.inst.exe  675 1 0 1142  411 1704 1  740  500 1 0 1     > ../newoutputs/t1027
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1026.tr
echo ">>>>>>>>running test 1028"
../source/tcas.c.inst.exe  675 1 0 1142  411 1704 1  640  500 1 0 1     > ../newoutputs/t1028
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1027.tr
echo ">>>>>>>>running test 1029"
../source/tcas.c.inst.exe  675 1 1 1142  411 1704 1  640  500 1 0 1     > ../newoutputs/t1029
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1028.tr
echo ">>>>>>>>running test 1030"
../source/tcas.c.inst.exe  775 1 1 1142  411 1704 1  640  500 1 0 1     > ../newoutputs/t1030
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1029.tr
echo ">>>>>>>>running test 1031"
../source/tcas.c.inst.exe  775 1 1 1142  411 1704 1  540  500 1 0 1     > ../newoutputs/t1031
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1030.tr
echo ">>>>>>>>running test 1032"
../source/tcas.c.inst.exe  775 1 1 1142  411 1504 1  540  500 1 0 1     > ../newoutputs/t1032
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1031.tr
echo ">>>>>>>>running test 1033"
../source/tcas.c.inst.exe  775 1 1 1042  411 1504 1  540  500 1 0 1     > ../newoutputs/t1033
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1032.tr
echo ">>>>>>>>running test 1034"
../source/tcas.c.inst.exe  775 1 1 942  411 1504 1  540  500 1 0 1     > ../newoutputs/t1034
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1033.tr
echo ">>>>>>>>running test 1035"
../source/tcas.c.inst.exe  775 1 1 942  311 1504 1  540  500 1 0 1     > ../newoutputs/t1035
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1034.tr
echo ">>>>>>>>running test 1036"
../source/tcas.c.inst.exe  775 1 1 942  211 1504 1  540  500 1 0 1     > ../newoutputs/t1036
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1035.tr
echo ">>>>>>>>running test 1037"
../source/tcas.c.inst.exe  775 1 1 942  211 1204 1  540  500 1 0 1     > ../newoutputs/t1037
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1036.tr
echo ">>>>>>>>running test 1038"
../source/tcas.c.inst.exe  644 1 1 1986  596 2448 0  741  400 1 0 1     > ../newoutputs/t1038
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1037.tr
echo ">>>>>>>>running test 1039"
../source/tcas.c.inst.exe  644 1 0 1986  596 2448 0  741  400 1 0 1     > ../newoutputs/t1039
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1038.tr
echo ">>>>>>>>running test 1040"
../source/tcas.c.inst.exe  644 1 0 1786  596 2448 0  741  400 1 0 1     > ../newoutputs/t1040
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1039.tr
echo ">>>>>>>>running test 1041"
../source/tcas.c.inst.exe  644 1 0 1786  596 2248 0  741  400 1 0 1     > ../newoutputs/t1041
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1040.tr
echo ">>>>>>>>running test 1042"
../source/tcas.c.inst.exe  644 1 0 1786  596 2248 0  721  400 1 0 1     > ../newoutputs/t1042
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1041.tr
echo ">>>>>>>>running test 1043"
../source/tcas.c.inst.exe  624 1 0 1786  596 2248 0  721  400 1 0 1     > ../newoutputs/t1043
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1042.tr
echo ">>>>>>>>running test 1044"
../source/tcas.c.inst.exe  624 1 0 1786  496 2248 0  721  400 1 0 1     > ../newoutputs/t1044
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1043.tr
echo ">>>>>>>>running test 1045"
../source/tcas.c.inst.exe  624 1 0 1286  496 2248 0  721  400 1 0 1     > ../newoutputs/t1045
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1044.tr
echo ">>>>>>>>running test 1046"
../source/tcas.c.inst.exe  624 1 0 1086  496 2248 0  721  400 1 0 1     > ../newoutputs/t1046
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1045.tr
echo ">>>>>>>>running test 1047"
../source/tcas.c.inst.exe  604 1 0 1086  496 2248 0  721  400 1 0 1     > ../newoutputs/t1047
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1046.tr
echo ">>>>>>>>running test 1048"
../source/tcas.c.inst.exe  604 1 0 1086  496 1248 0  721  400 1 0 1     > ../newoutputs/t1048
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1047.tr
echo ">>>>>>>>running test 1049"
../source/tcas.c.inst.exe  604 1 0 1086  396 1248 0  721  400 1 0 1     > ../newoutputs/t1049
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1048.tr
echo ">>>>>>>>running test 1050"
../source/tcas.c.inst.exe  958 1 0 2597  574 4253 0  399  400 0 0 1     > ../newoutputs/t1050
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1049.tr
echo ">>>>>>>>running test 1051"
../source/tcas.c.inst.exe  958 1 0 2597  574 4253 0  379  400 0 0 1     > ../newoutputs/t1051
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1050.tr
echo ">>>>>>>>running test 1052"
../source/tcas.c.inst.exe  958 1 0 2597  574 4253 0  379  400 1 0 1     > ../newoutputs/t1052
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1051.tr
echo ">>>>>>>>running test 1053"
../source/tcas.c.inst.exe  958 1 0 2597  574 3253 0  379  400 1 0 1     > ../newoutputs/t1053
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1052.tr
echo ">>>>>>>>running test 1054"
../source/tcas.c.inst.exe  958 1 0 2597  474 3253 0  379  400 1 0 1     > ../newoutputs/t1054
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1053.tr
echo ">>>>>>>>running test 1055"
../source/tcas.c.inst.exe  958 1 0 2597  474 3253 0  379  400 0 0 1     > ../newoutputs/t1055
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1054.tr
echo ">>>>>>>>running test 1056"
../source/tcas.c.inst.exe  958 1 1 2597  574 4253 0  399  400 0 0 1     > ../newoutputs/t1056
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1055.tr
echo ">>>>>>>>running test 1057"
../source/tcas.c.inst.exe  939 1 1 532 434 -100 2 335 971 1 2 1     > ../newoutputs/t1057
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1056.tr
echo ">>>>>>>>running test 1058"
../source/tcas.c.inst.exe  939 1 1 532 434 0 2 335 971 1 2 1     > ../newoutputs/t1058
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1057.tr
echo ">>>>>>>>running test 1059"
../source/tcas.c.inst.exe  939 1 0 532 434 0 2 335 971 1 2 1     > ../newoutputs/t1059
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1058.tr
echo ">>>>>>>>running test 1060"
../source/tcas.c.inst.exe  839 1 0 532 434 0 2 335 971 1 2 1     > ../newoutputs/t1060
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1059.tr
echo ">>>>>>>>running test 1061"
../source/tcas.c.inst.exe  839 1 0 532 234 0 2 335 971 1 2 1     > ../newoutputs/t1061
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1060.tr
echo ">>>>>>>>running test 1062"
../source/tcas.c.inst.exe  839 1 0 532 234 0 2 325 971 1 2 1     > ../newoutputs/t1062
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1061.tr
echo ">>>>>>>>running test 1063"
../source/tcas.c.inst.exe  820 1 1 561 0 599 2 993 817 1 2 0     > ../newoutputs/t1063
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1062.tr
echo ">>>>>>>>running test 1064"
../source/tcas.c.inst.exe  820 1 0 561 0 599 2 993 817 1 2 0     > ../newoutputs/t1064
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1063.tr
echo ">>>>>>>>running test 1065"
../source/tcas.c.inst.exe  820 1 0 561 0 599 2 893 817 1 2 0     > ../newoutputs/t1065
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1064.tr
echo ">>>>>>>>running test 1066"
../source/tcas.c.inst.exe  720 1 0 561 0 599 2 893 817 1 2 0     > ../newoutputs/t1066
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1065.tr
echo ">>>>>>>>running test 1067"
../source/tcas.c.inst.exe  720 1 0 461 0 599 2 893 817 1 2 0     > ../newoutputs/t1067
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1066.tr
echo ">>>>>>>>running test 1068"
../source/tcas.c.inst.exe  655 1 0 749 487 139 2 477 850 1 2 0     > ../newoutputs/t1068
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1067.tr
echo ">>>>>>>>running test 1069"
../source/tcas.c.inst.exe  655 1 0 749 487 139 2 477 850 1 2 1     > ../newoutputs/t1069
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1068.tr
echo ">>>>>>>>running test 1070"
../source/tcas.c.inst.exe  655 1 1 749 487 139 2 477 850 1 2 1     > ../newoutputs/t1070
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1069.tr
echo ">>>>>>>>running test 1071"
../source/tcas.c.inst.exe  655 1 0 749 387 139 2 477 850 1 2 1     > ../newoutputs/t1071
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1070.tr
echo ">>>>>>>>running test 1072"
../source/tcas.c.inst.exe  755 1 0 749 387 139 2 477 850 1 2 1     > ../newoutputs/t1072
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1071.tr
echo ">>>>>>>>running test 1073"
../source/tcas.c.inst.exe  755 1 0 649 387 139 2 477 850 1 2 1     > ../newoutputs/t1073
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1072.tr
echo ">>>>>>>>running test 1074"
../source/tcas.c.inst.exe  698 1 0 3071 59 307 0 849 904 1 2 0     > ../newoutputs/t1074
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1073.tr
echo ">>>>>>>>running test 1075"
../source/tcas.c.inst.exe  698 1 0 2071 59 307 0 849 904 1 2 0     > ../newoutputs/t1075
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1074.tr
echo ">>>>>>>>running test 1076"
../source/tcas.c.inst.exe  698 1 0 2071 49 307 0 849 904 1 2 0     > ../newoutputs/t1076
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1075.tr
echo ">>>>>>>>running test 1077"
../source/tcas.c.inst.exe  798 1 0 2071 49 307 0 849 904 1 2 0     > ../newoutputs/t1077
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1076.tr
echo ">>>>>>>>running test 1078"
../source/tcas.c.inst.exe  798 1 1 2071 49 307 0 849 904 1 2 0     > ../newoutputs/t1078
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1077.tr
echo ">>>>>>>>running test 1079"
../source/tcas.c.inst.exe  700 1 0 575 415 1 0 795 796 2 2 0     > ../newoutputs/t1079
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1078.tr
echo ">>>>>>>>running test 1080"
../source/tcas.c.inst.exe  700 1 1 575 415 1 0 795 796 2 2 0     > ../newoutputs/t1080
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1079.tr
echo ">>>>>>>>running test 1081"
../source/tcas.c.inst.exe  700 1 1 575 415 1 0 795 796 1 2 0     > ../newoutputs/t1081
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1080.tr
echo ">>>>>>>>running test 1082"
../source/tcas.c.inst.exe  700 1 1 275 415 1 0 795 796 1 2 0     > ../newoutputs/t1082
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1081.tr
echo ">>>>>>>>running test 1083"
../source/tcas.c.inst.exe  700 1 1 275 415 1 0 695 796 1 2 0     > ../newoutputs/t1083
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1082.tr
echo ">>>>>>>>running test 1084"
../source/tcas.c.inst.exe  800 1 1 275 415 1 0 695 796 1 2 0     > ../newoutputs/t1084
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1083.tr
echo ">>>>>>>>running test 1085"
../source/tcas.c.inst.exe  1062 1 0 1941 575 682 3 872 880 1 2 0     > ../newoutputs/t1085
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1084.tr
echo ">>>>>>>>running test 1086"
../source/tcas.c.inst.exe  1062 1 0 1941 545 582 3 872 880 1 2 0     > ../newoutputs/t1086
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1085.tr
echo ">>>>>>>>running test 1087"
../source/tcas.c.inst.exe  1062 1 0 1941 545 582 2 872 880 1 2 0     > ../newoutputs/t1087
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1086.tr
echo ">>>>>>>>running test 1088"
../source/tcas.c.inst.exe  1062 1 0 1941 545 582 2 772 880 1 2 0     > ../newoutputs/t1088
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1087.tr
echo ">>>>>>>>running test 1089"
../source/tcas.c.inst.exe  1062 1 0 1941 545 582 2 772 780 1 2 0     > ../newoutputs/t1089
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1088.tr
echo ">>>>>>>>running test 1090"
../source/tcas.c.inst.exe  1062 1 1 1941 545 582 2 772 780 1 2 0     > ../newoutputs/t1090
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1089.tr
echo ">>>>>>>>running test 1091"
../source/tcas.c.inst.exe  1062 1 0 1941 445 582 2 772 780 1 2 0     > ../newoutputs/t1091
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1090.tr
echo ">>>>>>>>running test 1092"
../source/tcas.c.inst.exe  1062 1 0 1241 445 582 2 772 780 1 2 0     > ../newoutputs/t1092
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1091.tr
echo ">>>>>>>>running test 1093"
../source/tcas.c.inst.exe  1062 1 0 1241 445 582 2 712 780 1 2 0     > ../newoutputs/t1093
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1092.tr
echo ">>>>>>>>running test 1094"
../source/tcas.c.inst.exe  935 1 0 3528 388 0 0 853 956 0 2 0     > ../newoutputs/t1094
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1093.tr
echo ">>>>>>>>running test 1095"
../source/tcas.c.inst.exe  935 1 0 3528 288 0 0 853 956 0 2 0     > ../newoutputs/t1095
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1094.tr
echo ">>>>>>>>running test 1096"
../source/tcas.c.inst.exe  935 1 1 3528 288 0 0 853 956 0 2 0     > ../newoutputs/t1096
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1095.tr
echo ">>>>>>>>running test 1097"
../source/tcas.c.inst.exe  935 1 1 3528 288 0 0 853 956 1 2 0     > ../newoutputs/t1097
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1096.tr
echo ">>>>>>>>running test 1098"
../source/tcas.c.inst.exe  935 1 1 2528 288 0 0 853 956 1 2 0     > ../newoutputs/t1098
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1097.tr
echo ">>>>>>>>running test 1099"
../source/tcas.c.inst.exe  757 1 0 692 581 640 1 840 841 1 2 0     > ../newoutputs/t1099
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1098.tr
echo ">>>>>>>>running test 1100"
../source/tcas.c.inst.exe  757 1 0 692 581 640 1 840 841 0 2 0     > ../newoutputs/t1100
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1099.tr
echo ">>>>>>>>running test 1101"
../source/tcas.c.inst.exe  757 1 1 692 481 640 1 840 841 0 2 0     > ../newoutputs/t1101
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1100.tr
echo ">>>>>>>>running test 1102"
../source/tcas.c.inst.exe  757 1 1 692 481 640 2 840 841 1 2 0     > ../newoutputs/t1102
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1101.tr
echo ">>>>>>>>running test 1103"
../source/tcas.c.inst.exe  757 1 1 692 481 640 2 840 891 1 2 0     > ../newoutputs/t1103
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1102.tr
echo ">>>>>>>>running test 1104"
../source/tcas.c.inst.exe  913 1 0 661 -100 255 3 0 668 0 2 0     > ../newoutputs/t1104
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1103.tr
echo ">>>>>>>>running test 1105"
../source/tcas.c.inst.exe  913 1 0 661 0 255 3 0 668 0 2 0     > ../newoutputs/t1105
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1104.tr
echo ">>>>>>>>running test 1106"
../source/tcas.c.inst.exe  913 1 0 661 0 255 3 0 368 0 2 0     > ../newoutputs/t1106
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1105.tr
echo ">>>>>>>>running test 1107"
../source/tcas.c.inst.exe  913 1 0 661 0 255 3 1 368 0 2 0     > ../newoutputs/t1107
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1106.tr
echo ">>>>>>>>running test 1108"
../source/tcas.c.inst.exe  913 1 0 661 0 255 3 100 368 0 2 0     > ../newoutputs/t1108
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1107.tr
echo ">>>>>>>>running test 1109"
../source/tcas.c.inst.exe  713 1 0 661 0 255 3 100 368 0 2 0     > ../newoutputs/t1109
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1108.tr
echo ">>>>>>>>running test 1110"
../source/tcas.c.inst.exe  713 1 0 661 0 255 3 100 368 1 2 0     > ../newoutputs/t1110
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1109.tr
echo ">>>>>>>>running test 1111"
../source/tcas.c.inst.exe  713 1 0 661 0 255 3 100 228 1 2 0     > ../newoutputs/t1111
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1110.tr
echo ">>>>>>>>running test 1112"
../source/tcas.c.inst.exe  613 1 0 661 0 255 3 100 228 1 2 0     > ../newoutputs/t1112
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1111.tr
echo ">>>>>>>>running test 1113"
../source/tcas.c.inst.exe  613 1 0 661 0 155 3 100 228 1 2 0     > ../newoutputs/t1113
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1112.tr
echo ">>>>>>>>running test 1114"
../source/tcas.c.inst.exe  613 1 0 561 0 155 3 100 228 1 2 0     > ../newoutputs/t1114
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1113.tr
echo ">>>>>>>>running test 1115"
../source/tcas.c.inst.exe  613 1 0 461 0 155 3 100 228 1 2 0     > ../newoutputs/t1115
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1114.tr
echo ">>>>>>>>running test 1116"
../source/tcas.c.inst.exe  613 1 0 461 0 55 3 100 228 1 2 0     > ../newoutputs/t1116
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1115.tr
echo ">>>>>>>>running test 1117"
../source/tcas.c.inst.exe  758 1 1 2597  574 4253 0  399  400 0 0 1     > ../newoutputs/t1117
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1116.tr
echo ">>>>>>>>running test 1118"
../source/tcas.c.inst.exe  1058 1 1 2597  574 4253 0  399  400 0 0 1     > ../newoutputs/t1118
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1117.tr
echo ">>>>>>>>running test 1119"
../source/tcas.c.inst.exe  1058 1 1 2597  574 3253 0  399  400 0 0 1     > ../newoutputs/t1119
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1118.tr
echo ">>>>>>>>running test 1120"
../source/tcas.c.inst.exe  1058 1 1 2597  274 3253 0  399  400 0 0 1     > ../newoutputs/t1120
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1119.tr
echo ">>>>>>>>running test 1121"
../source/tcas.c.inst.exe  1058 1 0 2597  274 3253 0  399  400 0 0 1     > ../newoutputs/t1121
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1120.tr
echo ">>>>>>>>running test 1122"
../source/tcas.c.inst.exe  1058 1 0 2597  174 3253 0  399  400 0 0 1     > ../newoutputs/t1122
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1121.tr
echo ">>>>>>>>running test 1123"
../source/tcas.c.inst.exe  1058 1 0 1597  174 3253 0  399  400 0 0 1     > ../newoutputs/t1123
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1122.tr
echo ">>>>>>>>running test 1124"
../source/tcas.c.inst.exe  1058 1 0 1597  174 4253 0  399  400 0 0 1     > ../newoutputs/t1124
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1123.tr
echo ">>>>>>>>running test 1125"
../source/tcas.c.inst.exe  1058 1 0 1597  174 7253 0  399  400 0 0 1     > ../newoutputs/t1125
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1124.tr
echo ">>>>>>>>running test 1126"
../source/tcas.c.inst.exe  775 1 1 942  211 5204 1  540  500 1 0 1     > ../newoutputs/t1126
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1125.tr
echo ">>>>>>>>running test 1127"
../source/tcas.c.inst.exe  775 1 1 642  211 5204 1  540  500 1 0 1     > ../newoutputs/t1127
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1126.tr
echo ">>>>>>>>running test 1128"
../source/tcas.c.inst.exe  775 1 0 642  211 5204 1  540  500 1 0 1     > ../newoutputs/t1128
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1127.tr
echo ">>>>>>>>running test 1129"
../source/tcas.c.inst.exe  605 1 0 1142  511 4704 1  740  500 0 0 1     > ../newoutputs/t1129
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1128.tr
echo ">>>>>>>>running test 1130"
../source/tcas.c.inst.exe  611 1 1 1142  511 4704 1  740  500 0 0 1     > ../newoutputs/t1130
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1129.tr
echo ">>>>>>>>running test 1131"
../source/tcas.c.inst.exe  611 1 1 1142  511 4704 1  740  500 1 0 1     > ../newoutputs/t1131
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1130.tr
echo ">>>>>>>>running test 1132"
../source/tcas.c.inst.exe  604 1 0 1086  496 8248 0  721  400 1 0 1     > ../newoutputs/t1132
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1131.tr
echo ">>>>>>>>running test 1133"
../source/tcas.c.inst.exe  604 1 0 1086  196 8248 0  721  400 1 0 1     > ../newoutputs/t1133
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1132.tr
echo ">>>>>>>>running test 1134"
../source/tcas.c.inst.exe  604 1 0 1111  196 8248 0  721  400 1 0 1     > ../newoutputs/t1134
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1133.tr
echo ">>>>>>>>running test 1135"
../source/tcas.c.inst.exe  604 1 0 1111  196 8248 0  721  400 0 0 0     > ../newoutputs/t1135
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1134.tr
echo ">>>>>>>>running test 1136"
../source/tcas.c.inst.exe  604 1 0 911  196 8248 0  721  400 0 0 0     > ../newoutputs/t1136
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1135.tr
echo ">>>>>>>>running test 1137"
../source/tcas.c.inst.exe  604 1 0 911  96 8248 0  721  400 0 0 0     > ../newoutputs/t1137
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1136.tr
echo ">>>>>>>>running test 1138"
../source/tcas.c.inst.exe  604 1 1 911  96 8248 0  721  400 1 0 1     > ../newoutputs/t1138
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1137.tr
echo ">>>>>>>>running test 1139"
../source/tcas.c.inst.exe 1058 1 0 1597  174 3253 0  399  400 1 0 1     > ../newoutputs/t1139
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1138.tr
echo ">>>>>>>>running test 1140"
../source/tcas.c.inst.exe 1058 1 0 597  174 3253 0  399  400 1 0 1     > ../newoutputs/t1140
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1139.tr
echo ">>>>>>>>running test 1141"
../source/tcas.c.inst.exe 958 1 0 597  174 3253 0  399  400 1 0 1     > ../newoutputs/t1141
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1140.tr
echo ">>>>>>>>running test 1142"
../source/tcas.c.inst.exe 958 1 0 597  64 3253 0  399  400 1 0 1     > ../newoutputs/t1142
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1141.tr
echo ">>>>>>>>running test 1143"
../source/tcas.c.inst.exe 958 1 0 497  64 3253 0  399  400 1 0 1     > ../newoutputs/t1143
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1142.tr
echo ">>>>>>>>running test 1144"
../source/tcas.c.inst.exe 958 1 0 497  64 3253 0  399  200 1 0 1     > ../newoutputs/t1144
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1143.tr
echo ">>>>>>>>running test 1145"
../source/tcas.c.inst.exe 958 1 0 797  64 3253 0  399  200 1 0 1     > ../newoutputs/t1145
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1144.tr
echo ">>>>>>>>running test 1146"
../source/tcas.c.inst.exe 958 1 0 797  64 3253 0  399  100 1 0 1     > ../newoutputs/t1146
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1145.tr
echo ">>>>>>>>running test 1147"
../source/tcas.c.inst.exe 958 1 0 997  64 3253 0  399  120 1 0 1     > ../newoutputs/t1147
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1146.tr
echo ">>>>>>>>running test 1148"
../source/tcas.c.inst.exe 918 1 0 917  64 2253 0  399  120 1 0 1     > ../newoutputs/t1148
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1147.tr
echo ">>>>>>>>running test 1149"
../source/tcas.c.inst.exe 918 1 0 917  64 2153 0  299  126 1 0 1     > ../newoutputs/t1149
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1148.tr
echo ">>>>>>>>running test 1150"
../source/tcas.c.inst.exe 918 1 0 917  64 1153 0  299  126 1 0 1     > ../newoutputs/t1150
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1149.tr
echo ">>>>>>>>running test 1151"
../source/tcas.c.inst.exe 718 1 0 917  64 1153 0  299  126 1 0 1     > ../newoutputs/t1151
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1150.tr
echo ">>>>>>>>running test 1152"
../source/tcas.c.inst.exe 718 1 0 717  64 1153 0  299  126 1 0 1     > ../newoutputs/t1152
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1151.tr
echo ">>>>>>>>running test 1153"
../source/tcas.c.inst.exe 718 1 0 717  34 1153 0  299  126 1 0 1      > ../newoutputs/t1153
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1152.tr
echo ">>>>>>>>running test 1154"
../source/tcas.c.inst.exe 718 1 0 717  34 1153 0  229  126 1 0 1     > ../newoutputs/t1154
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1153.tr
echo ">>>>>>>>running test 1155"
../source/tcas.c.inst.exe 718 1 0 717  334 1153 0  229  126 1 0 1     > ../newoutputs/t1155
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1154.tr
echo ">>>>>>>>running test 1156"
../source/tcas.c.inst.exe 1058 1 0 997  174 7253 0  399  400 0 0 1     > ../newoutputs/t1156
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1155.tr
echo ">>>>>>>>running test 1157"
../source/tcas.c.inst.exe 1058 1 0 997  174 7253 0  329  400 0 0 1     > ../newoutputs/t1157
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1156.tr
echo ">>>>>>>>running test 1158"
../source/tcas.c.inst.exe 1258 1 0 897  174 7253 1  629  500 0 0 1     > ../newoutputs/t1158
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1157.tr
echo ">>>>>>>>running test 1159"
../source/tcas.c.inst.exe 1558 1 0 897  174 7253 2  729  640  0 0 1     > ../newoutputs/t1159
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1158.tr
echo ">>>>>>>>running test 1160"
../source/tcas.c.inst.exe 1558 1 0 697  174 7253 2  729  640  0 0 1     > ../newoutputs/t1160
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1159.tr
echo ">>>>>>>>running test 1161"
../source/tcas.c.inst.exe 1558 1 0 697  174 7253 2  729  640  1 0 1     > ../newoutputs/t1161
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1160.tr
echo ">>>>>>>>running test 1162"
../source/tcas.c.inst.exe 1558 1 1 697  174 7253 2  729  640  1 0 1     > ../newoutputs/t1162
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1161.tr
echo ">>>>>>>>running test 1163"
../source/tcas.c.inst.exe 1558 1 1 697  174 7253 2  929  640  1 0 1     > ../newoutputs/t1163
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1162.tr
echo ">>>>>>>>running test 1164"
../source/tcas.c.inst.exe 1558 1 1 697  174 7253 3  929  740  1 0 1     > ../newoutputs/t1164
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1163.tr
echo ">>>>>>>>running test 1165"
../source/tcas.c.inst.exe 1558 1 1 697  174 7253 3  741  740  1 0 1     > ../newoutputs/t1165
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1164.tr
echo ">>>>>>>>running test 1166"
../source/tcas.c.inst.exe 701 1 1 697  174 7253 3  741  740  1 0 1     > ../newoutputs/t1166
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1165.tr
echo ">>>>>>>>running test 1167"
../source/tcas.c.inst.exe 701 1 1 697  174 753 3  741  740  1 0 1     > ../newoutputs/t1167
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1166.tr
echo ">>>>>>>>running test 1168"
../source/tcas.c.inst.exe 701 1 1 697  174 753 3  749  740  0 0 1     > ../newoutputs/t1168
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1167.tr
echo ">>>>>>>>running test 1169"
../source/tcas.c.inst.exe 734 1 0 343 30 545 0 565 321 1 0 1     > ../newoutputs/t1169
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1168.tr
echo ">>>>>>>>running test 1170"
../source/tcas.c.inst.exe 934 1 0 343 30 545 0 565 21 0 0 1     > ../newoutputs/t1170
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1169.tr
echo ">>>>>>>>running test 1171"
../source/tcas.c.inst.exe 934 1 0 533 30 545 0 565 21 0 0 1     > ../newoutputs/t1171
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1170.tr
echo ">>>>>>>>running test 1172"
../source/tcas.c.inst.exe 934 1 0 533 30 545 1 565 21 0 0 1     > ../newoutputs/t1172
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1171.tr
echo ">>>>>>>>running test 1173"
../source/tcas.c.inst.exe 934 1 0 533 30 545 2 565 21 0 0 1     > ../newoutputs/t1173
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1172.tr
echo ">>>>>>>>running test 1174"
../source/tcas.c.inst.exe 934 1 0 533 30 545 3 565 21 0 0 1     > ../newoutputs/t1174
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1173.tr
echo ">>>>>>>>running test 1175"
../source/tcas.c.inst.exe 934 1 0 533 30 545 3 565 421 0 0 1     > ../newoutputs/t1175
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1174.tr
echo ">>>>>>>>running test 1176"
../source/tcas.c.inst.exe 934 1 0 533 30 545 3 765 621 0 0 1     > ../newoutputs/t1176
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1175.tr
echo ">>>>>>>>running test 1177"
../source/tcas.c.inst.exe 934 0 0 533 30 545 3 765 621 0 0 1     > ../newoutputs/t1177
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1176.tr
echo ">>>>>>>>running test 1178"
../source/tcas.c.inst.exe 934 1 0 533 730 545 3 765 621 0 0 1     > ../newoutputs/t1178
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1177.tr
echo ">>>>>>>>running test 1179"
../source/tcas.c.inst.exe 34 1 0 533 30 545 3 765 621 0 0 1     > ../newoutputs/t1179
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1178.tr
echo ">>>>>>>>running test 1180"
../source/tcas.c.inst.exe 734 1 1 533 30 545 3 765 621 1 1 1     > ../newoutputs/t1180
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1179.tr
echo ">>>>>>>>running test 1181"
../source/tcas.c.inst.exe 734 1 0 533 30 545 3 765 621 1 1 1     > ../newoutputs/t1181
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1180.tr
echo ">>>>>>>>running test 1182"
../source/tcas.c.inst.exe 734 1 0 343 30 545 0 265 321 1 0 0     > ../newoutputs/t1182
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1181.tr
echo ">>>>>>>>running test 1183"
../source/tcas.c.inst.exe 934 1 0 343 30 545 0 5 121 0 0 1     > ../newoutputs/t1183
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1182.tr
echo ">>>>>>>>running test 1184"
../source/tcas.c.inst.exe 934 1 0 533 30 545 0 65 421 0 0 1     > ../newoutputs/t1184
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1183.tr
echo ">>>>>>>>running test 1185"
../source/tcas.c.inst.exe 934 1 0 533 30 545 1 65 165 0 0 1     > ../newoutputs/t1185
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1184.tr
echo ">>>>>>>>running test 1186"
../source/tcas.c.inst.exe 934 1 0 533 30 545 2 565 721 0 0 1     > ../newoutputs/t1186
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1185.tr
echo ">>>>>>>>running test 1187"
../source/tcas.c.inst.exe 934 1 0 533 30 545 3 565 621 0 0 1     > ../newoutputs/t1187
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1186.tr
echo ">>>>>>>>running test 1188"
../source/tcas.c.inst.exe 934 1 0 533 30 545 3 365 421 0 0 0     > ../newoutputs/t1188
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1187.tr
echo ">>>>>>>>running test 1189"
../source/tcas.c.inst.exe 934 1 0 533 30 545 3 365 365 0 0 0     > ../newoutputs/t1189
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1188.tr
echo ">>>>>>>>running test 1190"
../source/tcas.c.inst.exe 1058 1 0 997  174 7253 0  399  200 0 0 1     > ../newoutputs/t1190
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1189.tr
echo ">>>>>>>>running test 1191"
../source/tcas.c.inst.exe 1058 1 0 997  174 7253 0  329  100 0 0 1     > ../newoutputs/t1191
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1190.tr
echo ">>>>>>>>running test 1192"
../source/tcas.c.inst.exe 1258 1 0 897  174 7253 1  629  650 0 0 0     > ../newoutputs/t1192
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1191.tr
echo ">>>>>>>>running test 1193"
../source/tcas.c.inst.exe 1558 1 0 897  174 7253 2  729  840  0 0 1     > ../newoutputs/t1193
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1192.tr
echo ">>>>>>>>running test 1194"
../source/tcas.c.inst.exe 934 1 0 533 30 545 1 65 165 0 0 1     > ../newoutputs/t1194
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1193.tr
echo ">>>>>>>>running test 1195"
../source/tcas.c.inst.exe 934 1 0 533 30 545 1 65 165 1 0 1     > ../newoutputs/t1195
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1194.tr
echo ">>>>>>>>running test 1196"
../source/tcas.c.inst.exe 634 1 0 533 30 545 1 65 165 1 0 1     > ../newoutputs/t1196
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1195.tr
echo ">>>>>>>>running test 1197"
../source/tcas.c.inst.exe 634 1 0 533 30 545 2 65 165 1 0 1     > ../newoutputs/t1197
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1196.tr
echo ">>>>>>>>running test 1198"
../source/tcas.c.inst.exe 634 1 0 533 30 545 3 65 165 1 0 1     > ../newoutputs/t1198
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1197.tr
echo ">>>>>>>>running test 1199"
../source/tcas.c.inst.exe 634 1 0 533 300 545 3 65 465 1 0 1     > ../newoutputs/t1199
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1198.tr
echo ">>>>>>>>running test 1200"
../source/tcas.c.inst.exe 634 1 0 533 400 645 3 265 465 1 0 1     > ../newoutputs/t1200
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1199.tr
echo ">>>>>>>>running test 1201"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 3 265 465 1 0 1     > ../newoutputs/t1201
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1200.tr
echo ">>>>>>>>running test 1202"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 3 265 465 0 0 1     > ../newoutputs/t1202
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1201.tr
echo ">>>>>>>>running test 1203"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 0 265 465 0 0 1     > ../newoutputs/t1203
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1202.tr
echo ">>>>>>>>running test 1204"
../source/tcas.c.inst.exe 1034 1 0 433 400 645 0 265 465 0 0 1     > ../newoutputs/t1204
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1203.tr
echo ">>>>>>>>running test 1205"
../source/tcas.c.inst.exe 634 1 0 533 30 545 2 65 165 1 0 1     > ../newoutputs/t1205
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1204.tr
echo ">>>>>>>>running test 1206"
../source/tcas.c.inst.exe 634 1 0 533 300 545 2 65 465 1 0 1     > ../newoutputs/t1206
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1205.tr
echo ">>>>>>>>running test 1207"
../source/tcas.c.inst.exe 634 1 0 533 400 645 2 265 465 1 0 1     > ../newoutputs/t1207
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1206.tr
echo ">>>>>>>>running test 1208"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 2 265 465 1 0 1     > ../newoutputs/t1208
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1207.tr
echo ">>>>>>>>running test 1209"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 2 265 465 0 0 1     > ../newoutputs/t1209
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1208.tr
echo ">>>>>>>>running test 1210"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 2 265 465 0 0 1     > ../newoutputs/t1210
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1209.tr
echo ">>>>>>>>running test 1211"
../source/tcas.c.inst.exe 958 1 0 497  64 3253 2  399  400 1 0 1     > ../newoutputs/t1211
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1210.tr
echo ">>>>>>>>running test 1212"
../source/tcas.c.inst.exe 958 1 0 497  64 3253 2  399  200 1 0 1     > ../newoutputs/t1212
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1211.tr
echo ">>>>>>>>running test 1213"
../source/tcas.c.inst.exe 958 1 0 797  64 3253 2  399  200 1 0 1     > ../newoutputs/t1213
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1212.tr
echo ">>>>>>>>running test 1214"
../source/tcas.c.inst.exe 958 1 0 797  64 3253 2  399  100 1 0 1     > ../newoutputs/t1214
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1213.tr
echo ">>>>>>>>running test 1215"
../source/tcas.c.inst.exe 958 1 0 997  64 3253 2  399  120 1 0 1     > ../newoutputs/t1215
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1214.tr
echo ">>>>>>>>running test 1216"
../source/tcas.c.inst.exe 918 1 0 917  64 2253 2  399  120 1 0 1     > ../newoutputs/t1216
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1215.tr
echo ">>>>>>>>running test 1217"
../source/tcas.c.inst.exe 918 1 0 917  64 2153 2  299  126 1 0 1     > ../newoutputs/t1217
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1216.tr
echo ">>>>>>>>running test 1218"
../source/tcas.c.inst.exe 918 1 0 917  64 1153 2  299  126 1 0 1     > ../newoutputs/t1218
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1217.tr
echo ">>>>>>>>running test 1219"
../source/tcas.c.inst.exe 718 1 0 917  64 1153 2  299  126 1 0 1     > ../newoutputs/t1219
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1218.tr
echo ">>>>>>>>running test 1220"
../source/tcas.c.inst.exe 718 1 0 717  64 1153 2  299  126 1 0 1     > ../newoutputs/t1220
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1219.tr
echo ">>>>>>>>running test 1221"
../source/tcas.c.inst.exe 718 1 0 717  34 1153 2  299  126 1 0 1      > ../newoutputs/t1221
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1220.tr
echo ">>>>>>>>running test 1222"
../source/tcas.c.inst.exe 718 1 0 717  34 1153 2  229  126 1 0 1     > ../newoutputs/t1222
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1221.tr
echo ">>>>>>>>running test 1223"
../source/tcas.c.inst.exe 718 1 0 717  334 1153 2  229  126 1 0 1     > ../newoutputs/t1223
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1222.tr
echo ">>>>>>>>running test 1224"
../source/tcas.c.inst.exe 1034 1 0 433 200 245 0 565 765 0 0 1     > ../newoutputs/t1224
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1223.tr
echo ">>>>>>>>running test 1225"
../source/tcas.c.inst.exe 1034 1 0 433 200 245 0 565 665 0 0 1     > ../newoutputs/t1225
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1224.tr
echo ">>>>>>>>running test 1226"
../source/tcas.c.inst.exe 1034 1 0 433 200 245 0 565 665 1 0 1     > ../newoutputs/t1226
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1225.tr
echo ">>>>>>>>running test 1227"
../source/tcas.c.inst.exe 1034 1 0 433 200 245 1 565 665 0 0 1     > ../newoutputs/t1227
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1226.tr
echo ">>>>>>>>running test 1228"
../source/tcas.c.inst.exe 634 1 0 433 200 245 1 565 795 0 0 1     > ../newoutputs/t1228
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1227.tr
echo ">>>>>>>>running test 1229"
../source/tcas.c.inst.exe 634 1 0 433 200 245 1 565 795 1 0 1     > ../newoutputs/t1229
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1228.tr
echo ">>>>>>>>running test 1230"
../source/tcas.c.inst.exe 634 1 1 433 200 245 1 565 795 1 0 1     > ../newoutputs/t1230
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1229.tr
echo ">>>>>>>>running test 1231"
../source/tcas.c.inst.exe 634 1 0 633 200 535 1 565 795 0 0 1     > ../newoutputs/t1231
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1230.tr
echo ">>>>>>>>running test 1232"
../source/tcas.c.inst.exe 634 1 0 633 200 535 2 665 795 0 0 1     > ../newoutputs/t1232
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1231.tr
echo ">>>>>>>>running test 1233"
../source/tcas.c.inst.exe 634 1 0 633 200 535 2 665 795 1 0 1     > ../newoutputs/t1233
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1232.tr
echo ">>>>>>>>running test 1234"
../source/tcas.c.inst.exe 634 1 1 633 200 535 1 565 795 0 1 1     > ../newoutputs/t1234
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1233.tr
echo ">>>>>>>>running test 1235"
../source/tcas.c.inst.exe 634 1 1 633 200 535 0 565 795 0 1 1     > ../newoutputs/t1235
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1234.tr
echo ">>>>>>>>running test 1236"
../source/tcas.c.inst.exe 634 1 1 633 200 535 2 665 795 0 1 1     > ../newoutputs/t1236
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1235.tr
echo ">>>>>>>>running test 1237"
../source/tcas.c.inst.exe 634 1 1 633 200 535 3 765 795 1 1 1     > ../newoutputs/t1237
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1236.tr
echo ">>>>>>>>running test 1238"
../source/tcas.c.inst.exe 634 1 1 633 200 535 3 765 995 0 1 1     > ../newoutputs/t1238
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1237.tr
echo ">>>>>>>>running test 1239"
../source/tcas.c.inst.exe 634 1 0 533 30 545 3 65 165 1 0 1     > ../newoutputs/t1239
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1238.tr
echo ">>>>>>>>running test 1240"
../source/tcas.c.inst.exe 634 1 0 533 300 545 3 65 465 1 0 1     > ../newoutputs/t1240
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1239.tr
echo ">>>>>>>>running test 1241"
../source/tcas.c.inst.exe 634 1 0 533 400 645 3 265 465 1 0 1     > ../newoutputs/t1241
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1240.tr
echo ">>>>>>>>running test 1242"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 3 265 465 1 0 1     > ../newoutputs/t1242
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1241.tr
echo ">>>>>>>>running test 1243"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 3 265 465 0 0 1     > ../newoutputs/t1243
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1242.tr
echo ">>>>>>>>running test 1244"
../source/tcas.c.inst.exe 1034 1 0 533 400 645 3 265 465 0 0 1     > ../newoutputs/t1244
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1243.tr
echo ">>>>>>>>running test 1245"
../source/tcas.c.inst.exe 958 1 0 497  64 3253 3  399  400 1 0 1     > ../newoutputs/t1245
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1244.tr
echo ">>>>>>>>running test 1246"
../source/tcas.c.inst.exe 958 1 0 497  64 3253 3  399  200 1 0 1     > ../newoutputs/t1246
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1245.tr
echo ">>>>>>>>running test 1247"
../source/tcas.c.inst.exe 958 1 0 797  64 3253 3  399  200 1 0 1     > ../newoutputs/t1247
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1246.tr
echo ">>>>>>>>running test 1248"
../source/tcas.c.inst.exe 958 1 0 797  64 3253 3  399  100 1 0 1     > ../newoutputs/t1248
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1247.tr
echo ">>>>>>>>running test 1249"
../source/tcas.c.inst.exe 958 1 0 997  64 3253 3  399  120 1 0 1     > ../newoutputs/t1249
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1248.tr
echo ">>>>>>>>running test 1250"
../source/tcas.c.inst.exe 918 1 0 917  64 2253 3  399  120 1 0 1     > ../newoutputs/t1250
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1249.tr
echo ">>>>>>>>running test 1251"
../source/tcas.c.inst.exe 918 1 0 917  64 2153 3  299  126 1 0 1     > ../newoutputs/t1251
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1250.tr
echo ">>>>>>>>running test 1252"
../source/tcas.c.inst.exe 918 1 0 917  64 1153 3  299  126 1 0 1     > ../newoutputs/t1252
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1251.tr
echo ">>>>>>>>running test 1253"
../source/tcas.c.inst.exe 718 1 0 917  64 1153 3  299  126 1 0 1     > ../newoutputs/t1253
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1252.tr
echo ">>>>>>>>running test 1254"
../source/tcas.c.inst.exe 718 1 0 717  64 1153 3  299  126 1 0 1     > ../newoutputs/t1254
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1253.tr
echo ">>>>>>>>running test 1255"
../source/tcas.c.inst.exe 718 1 0 717  34 1153 3  299  126 1 0 1      > ../newoutputs/t1255
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1254.tr
echo ">>>>>>>>running test 1256"
../source/tcas.c.inst.exe 718 1 0 717  34 1153 3  229  126 1 0 1     > ../newoutputs/t1256
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1255.tr
echo ">>>>>>>>running test 1257"
../source/tcas.c.inst.exe 718 1 0 717  334 1153 3  229  126 1 0 1     > ../newoutputs/t1257
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1256.tr
echo ">>>>>>>>running test 1258"
../source/tcas.c.inst.exe 634 1 0 633 200 535 0 565 795 1 0 1     > ../newoutputs/t1258
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1257.tr
echo ">>>>>>>>running test 1259"
../source/tcas.c.inst.exe 634 1 0 633 200 535 0 265 795 1 0 1     > ../newoutputs/t1259
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1258.tr
echo ">>>>>>>>running test 1260"
../source/tcas.c.inst.exe 634 1 0 633 300 535 0 265 795 1 0 1     > ../newoutputs/t1260
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1259.tr
echo ">>>>>>>>running test 1261"
../source/tcas.c.inst.exe 634 1 0 633 300 535 0 665 795 0 0 1     > ../newoutputs/t1261
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1260.tr
echo ">>>>>>>>running test 1262"
../source/tcas.c.inst.exe 634 1 1 633 300 535 0 665 795 0 1 1     > ../newoutputs/t1262
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1261.tr
echo ">>>>>>>>running test 1263"
../source/tcas.c.inst.exe 634 1 1 633 100 535 0 665 795 0 1 1     > ../newoutputs/t1263
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1262.tr
echo ">>>>>>>>running test 1264"
../source/tcas.c.inst.exe 634 1 1 633 100 535 0 665 795 0 1 0     > ../newoutputs/t1264
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1263.tr
echo ">>>>>>>>running test 1265"
../source/tcas.c.inst.exe 634 1 0 633 100 535 0 665 795 1 0 0     > ../newoutputs/t1265
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1264.tr
echo ">>>>>>>>running test 1266"
../source/tcas.c.inst.exe 634 1 0 633 500 535 0 665 795 1 0 0     > ../newoutputs/t1266
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1265.tr
echo ">>>>>>>>running test 1267"
../source/tcas.c.inst.exe 634 1 0 633 500 335 0 665 795 1 0 0     > ../newoutputs/t1267
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1266.tr
echo ">>>>>>>>running test 1268"
../source/tcas.c.inst.exe 634 1 0 233 500 335 3 845 740 1 0 0     > ../newoutputs/t1268
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1267.tr
echo ">>>>>>>>running test 1269"
../source/tcas.c.inst.exe 634 1 0 233 500 335 3 845 740 1 0 1     > ../newoutputs/t1269
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1268.tr
echo ">>>>>>>>running test 1270"
../source/tcas.c.inst.exe 634 1 1 233 500 335 3 845 740 0 1 1     > ../newoutputs/t1270
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1269.tr
echo ">>>>>>>>running test 1271"
../source/tcas.c.inst.exe 934 1 1 233 500 335 2 845 640 0 1 1     > ../newoutputs/t1271
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1270.tr
echo ">>>>>>>>running test 1272"
../source/tcas.c.inst.exe 934 1 1 233 500 335 1 845 500 0 1 1     > ../newoutputs/t1272
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1271.tr
echo ">>>>>>>>running test 1273"
../source/tcas.c.inst.exe 934 1 1 233 500 335 0 845 400 0 1 1     > ../newoutputs/t1273
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1272.tr
echo ">>>>>>>>running test 1274"
../source/tcas.c.inst.exe 934 1 1 233 100 335 0 845 400 0 1 1     > ../newoutputs/t1274
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1273.tr
echo ">>>>>>>>running test 1275"
../source/tcas.c.inst.exe 634 1 1 233 100 335 0 845 400 0 1 1     > ../newoutputs/t1275
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1274.tr
echo ">>>>>>>>running test 1276"
../source/tcas.c.inst.exe 634 1 1 233 100 335 0 445 400 0 1 1     > ../newoutputs/t1276
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1275.tr
echo ">>>>>>>>running test 1277"
../source/tcas.c.inst.exe 634 1 1 233 400 335 0 445 400 0 1 1     > ../newoutputs/t1277
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1276.tr
echo ">>>>>>>>running test 1278"
../source/tcas.c.inst.exe 634 1 1 233 400 235 0 445 400 0 1 1     > ../newoutputs/t1278
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1277.tr
echo ">>>>>>>>running test 1279"
../source/tcas.c.inst.exe 634 1 1 233 400 234 0 445 400 0 1 1     > ../newoutputs/t1279
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1278.tr
echo ">>>>>>>>running test 1280"
../source/tcas.c.inst.exe 934 1 0 233 500 335 0 845 400 1 0 1     > ../newoutputs/t1280
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1279.tr
echo ">>>>>>>>running test 1281"
../source/tcas.c.inst.exe 934 1 0 233 100 335 0 845 400 0 0 1     > ../newoutputs/t1281
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1280.tr
echo ">>>>>>>>running test 1282"
../source/tcas.c.inst.exe 634 1 0 233 100 335 0 845 400 0 0 1     > ../newoutputs/t1282
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1281.tr
echo ">>>>>>>>running test 1283"
../source/tcas.c.inst.exe 634 1 0 233 100 335 0 445 400 1 0 1     > ../newoutputs/t1283
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1282.tr
echo ">>>>>>>>running test 1284"
../source/tcas.c.inst.exe 634 1 0 233 400 335 0 445 400 0 0 1     > ../newoutputs/t1284
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1283.tr
echo ">>>>>>>>running test 1285"
../source/tcas.c.inst.exe 634 1 0 233 400 235 0 445 400 0 0 1     > ../newoutputs/t1285
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1284.tr
echo ">>>>>>>>running test 1286"
../source/tcas.c.inst.exe 634 1 0 233 400 234 0 445 400 1 0 1     > ../newoutputs/t1286
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1285.tr
echo ">>>>>>>>running test 1287"
../source/tcas.c.inst.exe 634 1 0 433 400 634 0 345 500 1 0 1     > ../newoutputs/t1287
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1286.tr
echo ">>>>>>>>running test 1288"
../source/tcas.c.inst.exe 634 1 1 433 400 634 0 345 500 0 1 1     > ../newoutputs/t1288
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1287.tr
echo ">>>>>>>>running test 1289"
../source/tcas.c.inst.exe 634 1 1 433 200 634 0 345 500 0 1 1     > ../newoutputs/t1289
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1288.tr
echo ">>>>>>>>running test 1290"
../source/tcas.c.inst.exe 634 1 0 433 200 634 0 345 500 0 0 1     > ../newoutputs/t1290
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1289.tr
echo ">>>>>>>>running test 1291"
../source/tcas.c.inst.exe 634 1 0 433 200 634 0 345 500 1 0 1     > ../newoutputs/t1291
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1290.tr
echo ">>>>>>>>running test 1292"
../source/tcas.c.inst.exe 634 1 0 433 300 634 0 345 450 1 0 1     > ../newoutputs/t1292
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1291.tr
echo ">>>>>>>>running test 1293"
../source/tcas.c.inst.exe 1934 1 0 433 300 634 0 345 450 1 0 1     > ../newoutputs/t1293
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1292.tr
echo ">>>>>>>>running test 1294"
../source/tcas.c.inst.exe 634 1 0 633 200 535 2 565 795 1 0 1     > ../newoutputs/t1294
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1293.tr
echo ">>>>>>>>running test 1295"
../source/tcas.c.inst.exe 634 1 0 633 200 535 2 265 795 1 0 1     > ../newoutputs/t1295
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1294.tr
echo ">>>>>>>>running test 1296"
../source/tcas.c.inst.exe 634 1 0 633 300 535 2 265 795 1 0 1     > ../newoutputs/t1296
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1295.tr
echo ">>>>>>>>running test 1297"
../source/tcas.c.inst.exe 634 1 0 633 300 535 2 665 795 0 0 1     > ../newoutputs/t1297
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1296.tr
echo ">>>>>>>>running test 1298"
../source/tcas.c.inst.exe 634 1 1 633 300 535 2 665 795 0 1 1     > ../newoutputs/t1298
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1297.tr
echo ">>>>>>>>running test 1299"
../source/tcas.c.inst.exe 634 1 1 633 100 535 2 665 795 0 1 1     > ../newoutputs/t1299
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1298.tr
echo ">>>>>>>>running test 1300"
../source/tcas.c.inst.exe 634 1 1 633 100 535 2 665 795 0 1 0     > ../newoutputs/t1300
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1299.tr
echo ">>>>>>>>running test 1301"
../source/tcas.c.inst.exe 634 1 0 633 100 535 2 665 795 1 0 0     > ../newoutputs/t1301
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1300.tr
echo ">>>>>>>>running test 1302"
../source/tcas.c.inst.exe 634 1 0 633 500 535 2 665 795 1 0 0     > ../newoutputs/t1302
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1301.tr
echo ">>>>>>>>running test 1303"
../source/tcas.c.inst.exe 634 1 0 633 500 335 2 665 795 1 0 0     > ../newoutputs/t1303
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1302.tr
echo ">>>>>>>>running test 1304"
../source/tcas.c.inst.exe 934 1 0 433 400 234 0 445 550 1 0 1     > ../newoutputs/t1304
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1303.tr
echo ">>>>>>>>running test 1305"
../source/tcas.c.inst.exe 934 1 1 433 400 234 0 445 550 0 1 1     > ../newoutputs/t1305
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1304.tr
echo ">>>>>>>>running test 1306"
../source/tcas.c.inst.exe 934 1 1 433 400 234 0 445 550 0 1 0     > ../newoutputs/t1306
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1305.tr
echo ">>>>>>>>running test 1307"
../source/tcas.c.inst.exe 634 1 1 433 500 234 0 445 550 0 1 1     > ../newoutputs/t1307
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1306.tr
echo ">>>>>>>>running test 1308"
../source/tcas.c.inst.exe 634 1 0 433 500 234 0 445 550 1 0 1     > ../newoutputs/t1308
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1307.tr
echo ">>>>>>>>running test 1309"
../source/tcas.c.inst.exe 634 1 0 433 500 334 0 445 550 1 0 1     > ../newoutputs/t1309
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1308.tr
echo ">>>>>>>>running test 1310"
../source/tcas.c.inst.exe 634 1 0 633 200 535 3 565 795 1 0 1     > ../newoutputs/t1310
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1309.tr
echo ">>>>>>>>running test 1311"
../source/tcas.c.inst.exe 634 1 0 633 200 535 3 265 795 1 0 1     > ../newoutputs/t1311
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1310.tr
echo ">>>>>>>>running test 1312"
../source/tcas.c.inst.exe 634 1 0 633 300 535 3 265 795 1 0 1     > ../newoutputs/t1312
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1311.tr
echo ">>>>>>>>running test 1313"
../source/tcas.c.inst.exe 634 1 0 633 300 535 3 665 795 0 0 1     > ../newoutputs/t1313
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1312.tr
echo ">>>>>>>>running test 1314"
../source/tcas.c.inst.exe 634 1 1 633 300 535 3 665 795 0 1 1     > ../newoutputs/t1314
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1313.tr
echo ">>>>>>>>running test 1315"
../source/tcas.c.inst.exe 634 1 1 633 100 535 3 665 795 0 1 1     > ../newoutputs/t1315
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1314.tr
echo ">>>>>>>>running test 1316"
../source/tcas.c.inst.exe 634 1 1 633 100 535 3 665 795 0 1 0     > ../newoutputs/t1316
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1315.tr
echo ">>>>>>>>running test 1317"
../source/tcas.c.inst.exe 634 1 0 633 100 535 3 665 795 1 0 0     > ../newoutputs/t1317
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1316.tr
echo ">>>>>>>>running test 1318"
../source/tcas.c.inst.exe 634 1 0 633 500 535 3 665 795 1 0 0     > ../newoutputs/t1318
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1317.tr
echo ">>>>>>>>running test 1319"
../source/tcas.c.inst.exe 634 1 0 633 500 335 3 665 795 1 0 0     > ../newoutputs/t1319
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1318.tr
echo ">>>>>>>>running test 1320"
../source/tcas.c.inst.exe 634 1 0 433 500 334 0 445 350 1 0 1     > ../newoutputs/t1320
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1319.tr
echo ">>>>>>>>running test 1321"
../source/tcas.c.inst.exe 634 1 1 433 500 334 0 445 350 0 1 1     > ../newoutputs/t1321
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1320.tr
echo ">>>>>>>>running test 1322"
../source/tcas.c.inst.exe 634 1 1 433 500 334 0 445 350 0 1 0     > ../newoutputs/t1322
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1321.tr
echo ">>>>>>>>running test 1323"
../source/tcas.c.inst.exe 634 1 0 433 300 433 0 445 350 1 0 1     > ../newoutputs/t1323
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1322.tr
echo ">>>>>>>>running test 1324"
../source/tcas.c.inst.exe 934 1 0 433 400 433 0 445 350 1 0 0     > ../newoutputs/t1324
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1323.tr
echo ">>>>>>>>running test 1325"
../source/tcas.c.inst.exe 934 1 0 433 400 433 1 445 350 1 0 0     > ../newoutputs/t1325
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1324.tr
echo ">>>>>>>>running test 1326"
../source/tcas.c.inst.exe 934 1 0 433 400 433 2 445 350 1 0 0     > ../newoutputs/t1326
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1325.tr
echo ">>>>>>>>running test 1327"
../source/tcas.c.inst.exe 934 1 0 433 400 433 3 445 350 1 0 0     > ../newoutputs/t1327
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1326.tr
echo ">>>>>>>>running test 1328"
../source/tcas.c.inst.exe 934 1 0 433 400 433 3 445 350 1 0 1     > ../newoutputs/t1328
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1327.tr
echo ">>>>>>>>running test 1329"
../source/tcas.c.inst.exe 934 1 1 433 400 433 3 445 350 0 1 1     > ../newoutputs/t1329
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1328.tr
echo ">>>>>>>>running test 1330"
../source/tcas.c.inst.exe 934 1 1 433 500 433 3 445 350 0 1 1     > ../newoutputs/t1330
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1329.tr
echo ">>>>>>>>running test 1331"
../source/tcas.c.inst.exe 734 1 1 433 100 433 3 445 350 0 1 1     > ../newoutputs/t1331
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1330.tr
echo ">>>>>>>>running test 1332"
../source/tcas.c.inst.exe 634 1 0 633 200 535 1 565 795 1 0 1     > ../newoutputs/t1332
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1331.tr
echo ">>>>>>>>running test 1333"
../source/tcas.c.inst.exe 634 1 0 633 200 535 1 265 795 1 0 1     > ../newoutputs/t1333
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1332.tr
echo ">>>>>>>>running test 1334"
../source/tcas.c.inst.exe 634 1 0 633 300 535 1 265 795 1 0 1     > ../newoutputs/t1334
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1333.tr
echo ">>>>>>>>running test 1335"
../source/tcas.c.inst.exe 634 1 0 633 300 535 1 665 795 0 0 1     > ../newoutputs/t1335
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1334.tr
echo ">>>>>>>>running test 1336"
../source/tcas.c.inst.exe 634 1 1 633 300 535 1 665 795 0 1 1     > ../newoutputs/t1336
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1335.tr
echo ">>>>>>>>running test 1337"
../source/tcas.c.inst.exe 634 1 1 633 100 535 1 665 795 0 1 1     > ../newoutputs/t1337
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1336.tr
echo ">>>>>>>>running test 1338"
../source/tcas.c.inst.exe 634 1 1 633 100 535 1 665 795 0 1 0     > ../newoutputs/t1338
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1337.tr
echo ">>>>>>>>running test 1339"
../source/tcas.c.inst.exe 634 1 0 633 100 535 1 665 795 1 0 0     > ../newoutputs/t1339
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1338.tr
echo ">>>>>>>>running test 1340"
../source/tcas.c.inst.exe 634 1 0 633 500 535 1 665 795 1 0 0     > ../newoutputs/t1340
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1339.tr
echo ">>>>>>>>running test 1341"
../source/tcas.c.inst.exe 634 1 0 633 500 335 1 665 795 1 0 0     > ../newoutputs/t1341
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1340.tr
echo ">>>>>>>>running test 1342"
../source/tcas.c.inst.exe 934 1 0 433 400 234 0 445 550 1 0 0     > ../newoutputs/t1342
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1341.tr
echo ">>>>>>>>running test 1343"
../source/tcas.c.inst.exe 934 1 0 433 200 234 0 445 550 1 0 0     > ../newoutputs/t1343
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1342.tr
echo ">>>>>>>>running test 1344"
../source/tcas.c.inst.exe 934 1 0 433 200 234 0 445 550 0 0 0      > ../newoutputs/t1344
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1343.tr
echo ">>>>>>>>running test 1345"
../source/tcas.c.inst.exe 601 1 0 502 100 602 0 500 400 1 0 0     > ../newoutputs/t1345
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1344.tr
echo ">>>>>>>>running test 1346"
../source/tcas.c.inst.exe 601 1 0 502 200 602 0 599 400 1 0 1     > ../newoutputs/t1346
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1345.tr
echo ">>>>>>>>running test 1347"
../source/tcas.c.inst.exe 601 1 0 502 200 602 0 599 400 0 0 1     > ../newoutputs/t1347
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1346.tr
echo ">>>>>>>>running test 1348"
../source/tcas.c.inst.exe 901 1 0 502 200 602 0 599 400 0 0 0     > ../newoutputs/t1348
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1347.tr
echo ">>>>>>>>running test 1349"
../source/tcas.c.inst.exe 901 1 1 502 200 602 0 599 400 0 1 0     > ../newoutputs/t1349
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1348.tr
echo ">>>>>>>>running test 1350"
../source/tcas.c.inst.exe 901 1 1 502 200 503 0 401 400 0 1 0     > ../newoutputs/t1350
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1349.tr
echo ">>>>>>>>running test 1351"
../source/tcas.c.inst.exe 901 1 1 502 200 503 0 401 400 0 1 1     > ../newoutputs/t1351
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1350.tr
echo ">>>>>>>>running test 1352"
../source/tcas.c.inst.exe 901 1 1 502 200 503 1 401 500 0 1 1     > ../newoutputs/t1352
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1351.tr
echo ">>>>>>>>running test 1353"
../source/tcas.c.inst.exe 901 1 1 502 200 503 1 401 500 0 1 0     > ../newoutputs/t1353
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1352.tr
echo ">>>>>>>>running test 1354"
../source/tcas.c.inst.exe 901 1 1 502 200 650 2 701 640 0 1 0     > ../newoutputs/t1354
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1353.tr
echo ">>>>>>>>running test 1355"
../source/tcas.c.inst.exe 901 1 1 502 200 650 2 701 640 0 1 1     > ../newoutputs/t1355
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1354.tr
echo ">>>>>>>>running test 1356"
../source/tcas.c.inst.exe 901 1 1 502 200 650 3 801 740 0 1 1     > ../newoutputs/t1356
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1355.tr
echo ">>>>>>>>running test 1357"
../source/tcas.c.inst.exe 901 1 1 502 200 650 3 801 740 0 1 0     > ../newoutputs/t1357
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1356.tr
echo ">>>>>>>>running test 1358"
../source/tcas.c.inst.exe 901 1 0 502 200 503 1 401 500 0 0 1     > ../newoutputs/t1358
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1357.tr
echo ">>>>>>>>running test 1359"
../source/tcas.c.inst.exe 901 1 0 502 200 503 1 401 500 0 0 0     > ../newoutputs/t1359
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1358.tr
echo ">>>>>>>>running test 1360"
../source/tcas.c.inst.exe 901 1 0 502 200 650 2 701 640 0 0 0     > ../newoutputs/t1360
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1359.tr
echo ">>>>>>>>running test 1361"
../source/tcas.c.inst.exe 901 1 0 502 200 650 2 701 640 0 0 1     > ../newoutputs/t1361
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1360.tr
echo ">>>>>>>>running test 1362"
../source/tcas.c.inst.exe 901 1 0 502 200 650 3 801 740 0 0 1     > ../newoutputs/t1362
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1361.tr
echo ">>>>>>>>running test 1363"
../source/tcas.c.inst.exe 901 1 0 502 200 650 3 801 740 0 0 0     > ../newoutputs/t1363
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1362.tr
echo ">>>>>>>>running test 1364"
../source/tcas.c.inst.exe 599 0 0 400 100 300 0 800 400 0 0 0     > ../newoutputs/t1364
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1363.tr
echo ">>>>>>>>running test 1365"
../source/tcas.c.inst.exe 601 0 0 400 100 300 0 800 400 0 0 0     > ../newoutputs/t1365
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1364.tr
echo ">>>>>>>>running test 1366"
../source/tcas.c.inst.exe 599 1 0 400 601 300 0 800 400 0 0 0     > ../newoutputs/t1366
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1365.tr
echo ">>>>>>>>running test 1367"
../source/tcas.c.inst.exe 602 1 0 400 601 300 0 800 400 0 0 0     > ../newoutputs/t1367
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1366.tr
echo ">>>>>>>>running test 1368"
../source/tcas.c.inst.exe 602 1 0 400 601 300 0 800 400 0 1 0     > ../newoutputs/t1368
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1367.tr
echo ">>>>>>>>running test 1369"
../source/tcas.c.inst.exe 602 1 0 400 601 300 0 800 400 1 1 0     > ../newoutputs/t1369
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1368.tr
echo ">>>>>>>>running test 1370"
../source/tcas.c.inst.exe 602 1 0 400 601 300 0 800 400 1 1 1     > ../newoutputs/t1370
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1369.tr
echo ">>>>>>>>running test 1371"
../source/tcas.c.inst.exe 602 1 1 400 601 300 0 800 400 1 1 1     > ../newoutputs/t1371
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1370.tr
echo ">>>>>>>>running test 1372"
../source/tcas.c.inst.exe 602 1 1 400 601 300 3 800 400 1 1 1     > ../newoutputs/t1372
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1371.tr
echo ">>>>>>>>running test 1373"
../source/tcas.c.inst.exe 602 1 1 400 601 300 3 800 400 1 0 1     > ../newoutputs/t1373
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1372.tr
echo ">>>>>>>>running test 1374"
../source/tcas.c.inst.exe 602 1 1 400 601 300 3 800 400 0 0 1     > ../newoutputs/t1374
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1373.tr
echo ">>>>>>>>running test 1375"
../source/tcas.c.inst.exe 602 0 1 400 601 300 3 800 400 0 0 1     > ../newoutputs/t1375
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1374.tr
echo ">>>>>>>>running test 1376"
../source/tcas.c.inst.exe 602 0 1 400 601 300 3 800 400 1 0 1     > ../newoutputs/t1376
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1375.tr
echo ">>>>>>>>running test 1377"
../source/tcas.c.inst.exe 602 0 1 400 601 300 3 800 400 1 1 1     > ../newoutputs/t1377
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1376.tr
echo ">>>>>>>>running test 1378"
../source/tcas.c.inst.exe 602 0 1 400 601 300 3 800 400 1 1 0     > ../newoutputs/t1378
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1377.tr
echo ">>>>>>>>running test 1379"
../source/tcas.c.inst.exe 601 1 0 502 100 602 0 300 400 1 0 0     > ../newoutputs/t1379
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1378.tr
echo ">>>>>>>>running test 1380"
../source/tcas.c.inst.exe 601 1 0 502 200 602 0 299 400 1 0 1     > ../newoutputs/t1380
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1379.tr
echo ">>>>>>>>running test 1381"
../source/tcas.c.inst.exe 601 1 0 502 200 602 0 299 400 0 0 1     > ../newoutputs/t1381
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1380.tr
echo ">>>>>>>>running test 1382"
../source/tcas.c.inst.exe 901 1 0 502 200 602 0 299 400 0 0 0     > ../newoutputs/t1382
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1381.tr
echo ">>>>>>>>running test 1383"
../source/tcas.c.inst.exe 901 1 1 502 200 602 0 299 400 0 1 0     > ../newoutputs/t1383
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1382.tr
echo ">>>>>>>>running test 1384"
../source/tcas.c.inst.exe 901 1 1 502 200 503 0 301 400 0 1 0     > ../newoutputs/t1384
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1383.tr
echo ">>>>>>>>running test 1385"
../source/tcas.c.inst.exe 901 1 1 502 200 503 0 301 400 0 1 1     > ../newoutputs/t1385
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1384.tr
echo ">>>>>>>>running test 1386"
../source/tcas.c.inst.exe 901 1 1 502 200 503 1 201 500 0 1 1     > ../newoutputs/t1386
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1385.tr
echo ">>>>>>>>running test 1387"
../source/tcas.c.inst.exe 901 1 1 502 200 503 1 201 500 0 1 0     > ../newoutputs/t1387
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1386.tr
echo ">>>>>>>>running test 1388"
../source/tcas.c.inst.exe 901 1 1 502 200 650 2 501 640 0 1 0     > ../newoutputs/t1388
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1387.tr
echo ">>>>>>>>running test 1389"
../source/tcas.c.inst.exe 901 1 1 502 200 650 2 301 640 0 1 1     > ../newoutputs/t1389
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1388.tr
echo ">>>>>>>>running test 1390"
../source/tcas.c.inst.exe 901 1 1 502 200 650 3 401 740 0 1 1     > ../newoutputs/t1390
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1389.tr
echo ">>>>>>>>running test 1391"
../source/tcas.c.inst.exe 901 1 1 502 200 650 3 201 740 0 1 0     > ../newoutputs/t1391
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1390.tr
echo ">>>>>>>>running test 1392"
../source/tcas.c.inst.exe 901 1 0 502 200 503 1 101 500 0 0 1     > ../newoutputs/t1392
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1391.tr
echo ">>>>>>>>running test 1393"
../source/tcas.c.inst.exe 901 1 0 502 200 503 1 401 500 0 0 0     > ../newoutputs/t1393
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1392.tr
echo ">>>>>>>>running test 1394"
../source/tcas.c.inst.exe 901 1 0 502 200 650 2 301 640 0 0 0     > ../newoutputs/t1394
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1393.tr
echo ">>>>>>>>running test 1395"
../source/tcas.c.inst.exe 901 1 0 502 200 650 2 201 640 0 0 1     > ../newoutputs/t1395
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1394.tr
echo ">>>>>>>>running test 1396"
../source/tcas.c.inst.exe 901 1 0 502 200 650 3 401 740 0 0 1     > ../newoutputs/t1396
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1395.tr
echo ">>>>>>>>running test 1397"
../source/tcas.c.inst.exe 901 1 0 502 200 650 3 601 740 0 0 0     > ../newoutputs/t1397
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1396.tr
echo ">>>>>>>>running test 1398"
../source/tcas.c.inst.exe 601 1 0 502 100 402 0 500 400 1 0 0     > ../newoutputs/t1398
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1397.tr
echo ">>>>>>>>running test 1399"
../source/tcas.c.inst.exe 601 1 0 502 200 402 0 599 400 1 0 1     > ../newoutputs/t1399
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1398.tr
echo ">>>>>>>>running test 1400"
../source/tcas.c.inst.exe 601 1 0 502 200 502 0 599 400 0 0 1     > ../newoutputs/t1400
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1399.tr
echo ">>>>>>>>running test 1401"
../source/tcas.c.inst.exe 901 1 0 502 200 402 0 599 400 0 0 0     > ../newoutputs/t1401
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1400.tr
echo ">>>>>>>>running test 1402"
../source/tcas.c.inst.exe 901 1 1 502 200 302 0 599 400 0 1 0     > ../newoutputs/t1402
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1401.tr
echo ">>>>>>>>running test 1403"
../source/tcas.c.inst.exe 901 1 1 502 200 403 0 401 400 0 1 0     > ../newoutputs/t1403
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1402.tr
echo ">>>>>>>>running test 1404"
../source/tcas.c.inst.exe 901 1 1 502 200 403 0 401 400 0 1 1     > ../newoutputs/t1404
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1403.tr
echo ">>>>>>>>running test 1405"
../source/tcas.c.inst.exe 901 1 1 502 200 303 1 401 500 0 1 1     > ../newoutputs/t1405
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1404.tr
echo ">>>>>>>>running test 1406"
../source/tcas.c.inst.exe 901 1 1 502 200 203 1 401 500 0 1 0     > ../newoutputs/t1406
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1405.tr
echo ">>>>>>>>running test 1407"
../source/tcas.c.inst.exe 901 1 1 502 200 450 2 701 640 0 1 0     > ../newoutputs/t1407
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1406.tr
echo ">>>>>>>>running test 1408"
../source/tcas.c.inst.exe 901 1 1 502 200 450 2 701 640 0 1 1     > ../newoutputs/t1408
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1407.tr
echo ">>>>>>>>running test 1409"
../source/tcas.c.inst.exe 901 1 1 502 200 450 3 801 740 0 1 1     > ../newoutputs/t1409
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1408.tr
echo ">>>>>>>>running test 1410"
../source/tcas.c.inst.exe 901 1 1 502 200 350 3 801 740 0 1 0     > ../newoutputs/t1410
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1409.tr
echo ">>>>>>>>running test 1411"
../source/tcas.c.inst.exe 901 1 0 502 200 403 1 401 500 0 0 1     > ../newoutputs/t1411
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1410.tr
echo ">>>>>>>>running test 1412"
../source/tcas.c.inst.exe 901 1 0 502 200 303 1 401 500 0 0 0     > ../newoutputs/t1412
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1411.tr
echo ">>>>>>>>running test 1413"
../source/tcas.c.inst.exe 901 1 0 502 200 450 2 701 640 0 0 0     > ../newoutputs/t1413
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1412.tr
echo ">>>>>>>>running test 1414"
../source/tcas.c.inst.exe 901 1 0 502 200 350 2 701 640 0 0 1     > ../newoutputs/t1414
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1413.tr
echo ">>>>>>>>running test 1415"
../source/tcas.c.inst.exe 901 1 0 502 200 450 3 801 740 0 0 1     > ../newoutputs/t1415
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1414.tr
echo ">>>>>>>>running test 1416"
../source/tcas.c.inst.exe 901 1 0 502 200 350 3 801 740 0 0 0     > ../newoutputs/t1416
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1415.tr
echo ">>>>>>>>running test 1417"
../source/tcas.c.inst.exe 675 1 0 300 599 424 0 500 400 1 0 1     > ../newoutputs/t1417
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1416.tr
echo ">>>>>>>>running test 1418"
../source/tcas.c.inst.exe 675 1 0 300 599 424 0 400 400 0 0 1     > ../newoutputs/t1418
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1417.tr
echo ">>>>>>>>running test 1419"
../source/tcas.c.inst.exe 675 1 0 300 599 424 1 500 500 0 0 1     > ../newoutputs/t1419
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1418.tr
echo ">>>>>>>>running test 1420"
../source/tcas.c.inst.exe 675 1 1 300 0 424 1 500 500 0 1 1     > ../newoutputs/t1420
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1419.tr
echo ">>>>>>>>running test 1421"
../source/tcas.c.inst.exe 675 1 1 300 0 424 1 600 500 0 1 1      > ../newoutputs/t1421
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1420.tr
echo ">>>>>>>>running test 1422"
../source/tcas.c.inst.exe 675 1 1 300 0 424 1 600 500 0 1 0     > ../newoutputs/t1422
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1421.tr
echo ">>>>>>>>running test 1423"
../source/tcas.c.inst.exe 675 1 0 300 599 424 2 700 640  1 0 1     > ../newoutputs/t1423
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1422.tr
echo ">>>>>>>>running test 1424"
../source/tcas.c.inst.exe 675 1 0 300 599 424 2 800 640 0 0 1     > ../newoutputs/t1424
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1423.tr
echo ">>>>>>>>running test 1425"
../source/tcas.c.inst.exe 675 1 0 300 599 424 3 900 740 0 0 1     > ../newoutputs/t1425
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1424.tr
echo ">>>>>>>>running test 1426"
../source/tcas.c.inst.exe 675 1 1 300 0 424 3 900 740 0 1 1     > ../newoutputs/t1426
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1425.tr
echo ">>>>>>>>running test 1427"
../source/tcas.c.inst.exe 675 1 1 300 0 424 3 900 740 0 1 1      > ../newoutputs/t1427
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1426.tr
echo ">>>>>>>>running test 1428"
../source/tcas.c.inst.exe 675 1 1 300 0 424 3 900 740 0 1 0     > ../newoutputs/t1428
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1427.tr
echo ">>>>>>>>running test 1429"
../source/tcas.c.inst.exe 675 0 0 300 0 424 5 600 500 1 1 1     > ../newoutputs/t1429
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1428.tr
echo ">>>>>>>>running test 1430"
../source/tcas.c.inst.exe 675 1 0 300 0 424 1 600 500 0 1 0     > ../newoutputs/t1430
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1429.tr
echo ">>>>>>>>running test 1431"
../source/tcas.c.inst.exe 675 1 0 300 0 424 5 600 500 0 1 0     > ../newoutputs/t1431
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1430.tr
echo ">>>>>>>>running test 1432"
../source/tcas.c.inst.exe 675 1 0 300 0 424 5 600 500 1 1 0     > ../newoutputs/t1432
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1431.tr
echo ">>>>>>>>running test 1433"
../source/tcas.c.inst.exe 675 1 0 300 0 424 5 600 500 1 1 1     > ../newoutputs/t1433
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1432.tr
echo ">>>>>>>>running test 1434"
../source/tcas.c.inst.exe 675 0 0 300 0 424 5 600 500 1 1 1     > ../newoutputs/t1434
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1433.tr
echo ">>>>>>>>running test 1435"
../source/tcas.c.inst.exe 65 0 0 300 0 424 5 600 500 1 1 1     > ../newoutputs/t1435
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1434.tr
echo ">>>>>>>>running test 1436"
../source/tcas.c.inst.exe 65 0 1 300 0 424 5 600 500 1 1 1      > ../newoutputs/t1436
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1435.tr
echo ">>>>>>>>running test 1437"
../source/tcas.c.inst.exe 65 0 1 300 0 424 5 600 500 0 0 0     > ../newoutputs/t1437
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1436.tr
echo ">>>>>>>>running test 1438"
../source/tcas.c.inst.exe 65 0 1 300 700 424 5 600 500 0 0 0     > ../newoutputs/t1438
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1437.tr
echo ">>>>>>>>running test 1439"
../source/tcas.c.inst.exe 65 0 1 300 700 424 5 600 500 1 1 1     > ../newoutputs/t1439
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1438.tr
echo ">>>>>>>>running test 1440"
../source/tcas.c.inst.exe 765 1 0 300 400 424 5 400 500 1 0 1     > ../newoutputs/t1440
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1439.tr
echo ">>>>>>>>running test 1441"
../source/tcas.c.inst.exe 765 1 0 300 400 424 5 400 500 0 0 1     > ../newoutputs/t1441
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1440.tr
echo ">>>>>>>>running test 1442"
../source/tcas.c.inst.exe 765 1 0 300 400 424 5 400 500 0 0 0     > ../newoutputs/t1442
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1441.tr
echo ">>>>>>>>running test 1443"
../source/tcas.c.inst.exe 765 1 0 300 400 424 2 400 500 0 0 0     > ../newoutputs/t1443
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1442.tr
echo ">>>>>>>>running test 1444"
../source/tcas.c.inst.exe 765 1 0 300 400 424 3 400 500 0 0 0     > ../newoutputs/t1444
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1443.tr
echo ">>>>>>>>running test 1445"
../source/tcas.c.inst.exe 765 1 0 300 400 424 4 400 500 0 1 0     > ../newoutputs/t1445
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1444.tr
echo ">>>>>>>>running test 1446"
../source/tcas.c.inst.exe 765 1 0 300 400 424 4 400 500 0 1 1     > ../newoutputs/t1446
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1445.tr
echo ">>>>>>>>running test 1447"
../source/tcas.c.inst.exe 765 1 0 300 400 424 4 400 500 1 1 1     > ../newoutputs/t1447
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1446.tr
echo ">>>>>>>>running test 1448"
../source/tcas.c.inst.exe 765 1 0 300 500 424 3 400 500 1 1 1     > ../newoutputs/t1448
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1447.tr
echo ">>>>>>>>running test 1449"
../source/tcas.c.inst.exe 765 1 0 300 600 424 3 400 500 1 1 1     > ../newoutputs/t1449
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1448.tr
echo ">>>>>>>>running test 1450"
../source/tcas.c.inst.exe 718 1 0 717 34 1153 0 229 126 1 0 0     > ../newoutputs/t1450
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1449.tr
echo ">>>>>>>>running test 1451"
../source/tcas.c.inst.exe 718 1 0 717 34 1153 0 229 126 0 0 0     > ../newoutputs/t1451
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1450.tr
echo ">>>>>>>>running test 1452"
../source/tcas.c.inst.exe 718 1 1 717 34 1153 0 229 126 0 1 0     > ../newoutputs/t1452
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1451.tr
echo ">>>>>>>>running test 1453"
../source/tcas.c.inst.exe 718 1 1 717 34 1153 1 229 126 0 1 0     > ../newoutputs/t1453
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1452.tr
echo ">>>>>>>>running test 1454"
../source/tcas.c.inst.exe 718 1 1 717 34 1153 2 229 126 0 1 0     > ../newoutputs/t1454
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1453.tr
echo ">>>>>>>>running test 1455"
../source/tcas.c.inst.exe 718 1 1 717 34 1153 3 229 126 0 1 0     > ../newoutputs/t1455
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1454.tr
echo ">>>>>>>>running test 1456"
../source/tcas.c.inst.exe 718 1 1 717 34 1153 1 229 226 0 1 0     > ../newoutputs/t1456
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1455.tr
echo ">>>>>>>>running test 1457"
../source/tcas.c.inst.exe 718 1 0 717 34 1153 1 429 326 0 0 0     > ../newoutputs/t1457
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1456.tr
echo ">>>>>>>>running test 1458"
../source/tcas.c.inst.exe 718 1 0 717 34 1153 2 429 326 0 0 0     > ../newoutputs/t1458
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1457.tr
echo ">>>>>>>>running test 1459"
../source/tcas.c.inst.exe 601 1 0 717 534 1153 2 429 326 0 0 0     > ../newoutputs/t1459
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1458.tr
echo ">>>>>>>>running test 1460"
../source/tcas.c.inst.exe 765 1 0 500 400 424 5 400 500 1 0 1     > ../newoutputs/t1460
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1459.tr
echo ">>>>>>>>running test 1461"
../source/tcas.c.inst.exe 765 1 0 500 400 424 5 400 500 0 0 1     > ../newoutputs/t1461
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1460.tr
echo ">>>>>>>>running test 1462"
../source/tcas.c.inst.exe 765 1 0 500 400 424 5 400 500 0 0 0     > ../newoutputs/t1462
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1461.tr
echo ">>>>>>>>running test 1463"
../source/tcas.c.inst.exe 765 1 0 500 400 424 2 400 500 0 0 0     > ../newoutputs/t1463
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1462.tr
echo ">>>>>>>>running test 1464"
../source/tcas.c.inst.exe 765 1 0 500 400 424 3 400 500 0 0 0     > ../newoutputs/t1464
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1463.tr
echo ">>>>>>>>running test 1465"
../source/tcas.c.inst.exe 675 1 0 300 0 424 1 600 500 0 1 0     > ../newoutputs/t1465
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1464.tr
echo ">>>>>>>>running test 1466"
../source/tcas.c.inst.exe 675 1 0 300 0 424 3 600 500 0 1 0     > ../newoutputs/t1466
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1465.tr
echo ">>>>>>>>running test 1467"
../source/tcas.c.inst.exe 675 1 0 300 599 424 2 600 500 1 1 0     > ../newoutputs/t1467
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1466.tr
echo ">>>>>>>>running test 1468"
../source/tcas.c.inst.exe 675 1 0 300 0 424 0 600 500 1 1 1     > ../newoutputs/t1468
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1467.tr
echo ">>>>>>>>running test 1469"
../source/tcas.c.inst.exe 675 0 0 300 0 424 1 600 500 1 1 1     > ../newoutputs/t1469
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1468.tr
echo ">>>>>>>>running test 1470"
../source/tcas.c.inst.exe 65 0 0 300 0 424 2 600 500 1 1 1     > ../newoutputs/t1470
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1469.tr
echo ">>>>>>>>running test 1471"
../source/tcas.c.inst.exe 65 0 1 300 0 424 3 600 500 1 1 1      > ../newoutputs/t1471
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1470.tr
echo ">>>>>>>>running test 1472"
../source/tcas.c.inst.exe 5 0 1 300 0 424 2 600 500 0 0 0     > ../newoutputs/t1472
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1471.tr
echo ">>>>>>>>running test 1473"
../source/tcas.c.inst.exe 65 0 1 300 700 424 1 600 500 0 0 0     > ../newoutputs/t1473
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1472.tr
echo ">>>>>>>>running test 1474"
../source/tcas.c.inst.exe 65 0 1 300 700 424 2 600 500 1 1 1     > ../newoutputs/t1474
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1473.tr
echo ">>>>>>>>running test 1475"
../source/tcas.c.inst.exe 765 1 0 300 300 424 0 400 500 1 0 1     > ../newoutputs/t1475
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1474.tr
echo ">>>>>>>>running test 1476"
../source/tcas.c.inst.exe 765 1 0 300 100 424 2 400 500 0 0 1     > ../newoutputs/t1476
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1475.tr
echo ">>>>>>>>running test 1477"
../source/tcas.c.inst.exe 765 1 0 300 0 424 1 400 500 0 0 0     > ../newoutputs/t1477
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1476.tr
echo ">>>>>>>>running test 1478"
../source/tcas.c.inst.exe 765 1 0 300 40 424 2 400 500 0 0 0     > ../newoutputs/t1478
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1477.tr
echo ">>>>>>>>running test 1479"
../source/tcas.c.inst.exe 765 1 0 300 400 424 3 400 500 1 0 0     > ../newoutputs/t1479
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1478.tr
echo ">>>>>>>>running test 1480"
../source/tcas.c.inst.exe 765 1 0 500 400 424 3 600 800 1 0 1     > ../newoutputs/t1480
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1479.tr
echo ">>>>>>>>running test 1481"
../source/tcas.c.inst.exe 765 1 0 500 400 424 3 600 800 1 0 0     > ../newoutputs/t1481
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1480.tr
echo ">>>>>>>>running test 1482"
../source/tcas.c.inst.exe 765 1 0 500 400 424 3 600 800 0 0 0     > ../newoutputs/t1482
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1481.tr
echo ">>>>>>>>running test 1483"
../source/tcas.c.inst.exe 765 1 0 500 400 424 3 600 800 0 0 1     > ../newoutputs/t1483
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1482.tr
echo ">>>>>>>>running test 1484"
../source/tcas.c.inst.exe 665 1 0 500 500 624 3 600 800 0 0 1     > ../newoutputs/t1484
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1483.tr
echo ">>>>>>>>running test 1485"
../source/tcas.c.inst.exe 665 1 0 600 500 524 3 600 800 0 0 1     > ../newoutputs/t1485
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1484.tr
echo ">>>>>>>>running test 1486"
../source/tcas.c.inst.exe 765 1 0 500 400 424 5 600 500 1 0 1     > ../newoutputs/t1486
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1485.tr
echo ">>>>>>>>running test 1487"
../source/tcas.c.inst.exe 765 1 0 500 400 424 5 600 500 0 0 1     > ../newoutputs/t1487
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1486.tr
echo ">>>>>>>>running test 1488"
../source/tcas.c.inst.exe 765 1 0 500 400 424 5 600 500 0 0 0     > ../newoutputs/t1488
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1487.tr
echo ">>>>>>>>running test 1489"
../source/tcas.c.inst.exe 765 1 0 500 400 424 2 600 500 0 0 0     > ../newoutputs/t1489
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1488.tr
echo ">>>>>>>>running test 1490"
../source/tcas.c.inst.exe 765 1 0 500 400 424 3 600 500 0 0 0     > ../newoutputs/t1490
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1489.tr
echo ">>>>>>>>running test 1491"
../source/tcas.c.inst.exe 700 1 1 400 200 500 1 100 200 1 0 0     > ../newoutputs/t1491
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1490.tr
echo ">>>>>>>>running test 1492"
../source/tcas.c.inst.exe 700 1 1 400 200 600 1 100 500 1 0 0     > ../newoutputs/t1492
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1491.tr
echo ">>>>>>>>running test 1493"
../source/tcas.c.inst.exe 700 1 1 400 300 600 3 100 500 1 0 0     > ../newoutputs/t1493
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1492.tr
echo ">>>>>>>>running test 1494"
../source/tcas.c.inst.exe 700 1 0 400 300 600 3 100 500 1 0 1     > ../newoutputs/t1494
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1493.tr
echo ">>>>>>>>running test 1495"
../source/tcas.c.inst.exe 700 1 0 400 300 600 3 100 500 0 0 1     > ../newoutputs/t1495
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1494.tr
echo ">>>>>>>>running test 1496"
../source/tcas.c.inst.exe 700 1 0 400 300 600 3 100 500 0 0 0      > ../newoutputs/t1496
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1495.tr
echo ">>>>>>>>running test 1497"
../source/tcas.c.inst.exe 700 1 0 400 400 600 2 100 500 0 0 0     > ../newoutputs/t1497
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1496.tr
echo ">>>>>>>>running test 1498"
../source/tcas.c.inst.exe 700 1 0 400 400 600 2 100 500 0 1 0     > ../newoutputs/t1498
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1497.tr
echo ">>>>>>>>running test 1499"
../source/tcas.c.inst.exe 700 1 0 400 400 600 2 100 500 0 1 1     > ../newoutputs/t1499
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1498.tr
echo ">>>>>>>>running test 1500"
../source/tcas.c.inst.exe 700 1 0 400 200 600 0 100 500 0 1 1     > ../newoutputs/t1500
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1499.tr
echo ">>>>>>>>running test 1501"
../source/tcas.c.inst.exe 700 1 1 400 200 600 0 100 500 0 1 1      > ../newoutputs/t1501
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1500.tr
echo ">>>>>>>>running test 1502"
../source/tcas.c.inst.exe 700 1 1 400 300 600 2 100 500 0 1 1      > ../newoutputs/t1502
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1501.tr
echo ">>>>>>>>running test 1503"
../source/tcas.c.inst.exe 700 1 1 400 300 600 2 100 300 0 1 1      > ../newoutputs/t1503
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1502.tr
echo ">>>>>>>>running test 1504"
../source/tcas.c.inst.exe 700 1 1 400 300 600 2 100 300 1 1 1     > ../newoutputs/t1504
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1503.tr
echo ">>>>>>>>running test 1505"
../source/tcas.c.inst.exe 800 1 1 400 300 600 3 100 300 1 1 1     > ../newoutputs/t1505
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1504.tr
echo ">>>>>>>>running test 1506"
../source/tcas.c.inst.exe 700 1 0 400 300 600 3 100 800 0 0 1     > ../newoutputs/t1506
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1505.tr
echo ">>>>>>>>running test 1507"
../source/tcas.c.inst.exe 700 1 0 400 200 600 0 100 300 0 1 1     > ../newoutputs/t1507
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1506.tr
echo ">>>>>>>>running test 1508"
../source/tcas.c.inst.exe 700 1 1 400 200 600 1 100 500 1 0 0     > ../newoutputs/t1508
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1507.tr
echo ">>>>>>>>running test 1509"
../source/tcas.c.inst.exe 700 1 0 400 400 600 2 100 500 0 0 0     > ../newoutputs/t1509
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1508.tr
echo ">>>>>>>>running test 1510"
../source/tcas.c.inst.exe 700 1 0 400 400 600 2 100 600 0 0 0     > ../newoutputs/t1510
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1509.tr
echo ">>>>>>>>running test 1511"
../source/tcas.c.inst.exe 700 1 1 400 300 600 2 100 500 0 1 1     > ../newoutputs/t1511
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1510.tr
echo ">>>>>>>>running test 1512"
../source/tcas.c.inst.exe 610 1 0 400 400 200 2 300 400 1 1 1      > ../newoutputs/t1512
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1511.tr
echo ">>>>>>>>running test 1513"
../source/tcas.c.inst.exe 610 1 0 400 400 200 3 300 400 1 1 1     > ../newoutputs/t1513
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1512.tr
echo ">>>>>>>>running test 1514"
../source/tcas.c.inst.exe 610 1 0 400 400 200 3 300 400 1 1 0     > ../newoutputs/t1514
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1513.tr
echo ">>>>>>>>running test 1515"
../source/tcas.c.inst.exe 610 1 0 400 400 200 3 300 400 0 1 0     > ../newoutputs/t1515
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1514.tr
echo ">>>>>>>>running test 1516"
../source/tcas.c.inst.exe 610 1 0 400 0 200 0 300 400 0 1 0     > ../newoutputs/t1516
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1515.tr
echo ">>>>>>>>running test 1517"
../source/tcas.c.inst.exe 610 1 0 400 0 200 1 300 400 0 1 0     > ../newoutputs/t1517
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1516.tr
echo ">>>>>>>>running test 1518"
../source/tcas.c.inst.exe 610 1 0 400 0 200 1 300 400 1 1 1     > ../newoutputs/t1518
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1517.tr
echo ">>>>>>>>running test 1519"
../source/tcas.c.inst.exe 610 1 0 400 0 200 1 300 800 1 1 1     > ../newoutputs/t1519
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1518.tr
echo ">>>>>>>>running test 1520"
../source/tcas.c.inst.exe 665 1 0 500 500 624 2 600 800 0 0 1     > ../newoutputs/t1520
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1519.tr
echo ">>>>>>>>running test 1521"
../source/tcas.c.inst.exe 665 1 0 500 500 624 2 600 800 1 0 1     > ../newoutputs/t1521
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1520.tr
echo ">>>>>>>>running test 1522"
../source/tcas.c.inst.exe 665 1 0 500 500 624 3 600 800 1 0 1     > ../newoutputs/t1522
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1521.tr
echo ">>>>>>>>running test 1523"
../source/tcas.c.inst.exe 665 1 0 500 500 624 3 600 600 1 0 0     > ../newoutputs/t1523
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1522.tr
echo ">>>>>>>>running test 1524"
../source/tcas.c.inst.exe 665 1 0 500 500 624 2 600 600 1 0 0     > ../newoutputs/t1524
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1523.tr
echo ">>>>>>>>running test 1525"
../source/tcas.c.inst.exe 665 1 1 500 500 624 2 600 600 0 1 0     > ../newoutputs/t1525
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1524.tr
echo ">>>>>>>>running test 1526"
../source/tcas.c.inst.exe 665 1 1 500 500 624 3 600 600 0 1 0     > ../newoutputs/t1526
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1525.tr
echo ">>>>>>>>running test 1527"
../source/tcas.c.inst.exe 665 1 1 500 200 624 3 600 600 0 1 0     > ../newoutputs/t1527
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1526.tr
echo ">>>>>>>>running test 1528"
../source/tcas.c.inst.exe 665 1 1 300 200 624 3 600 600 0 1 0     > ../newoutputs/t1528
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1527.tr
echo ">>>>>>>>running test 1529"
../source/tcas.c.inst.exe 765 1 0 500 400 424 2 600 500 0 0 0     > ../newoutputs/t1529
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1528.tr
echo ">>>>>>>>running test 1530"
../source/tcas.c.inst.exe 765 1 0 500 400 424 2 600 500 1 0 1     > ../newoutputs/t1530
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1529.tr
echo ">>>>>>>>running test 1531"
../source/tcas.c.inst.exe 765 1 0 500 400 424 3 600 500 1 0 1     > ../newoutputs/t1531
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1530.tr
echo ">>>>>>>>running test 1532"
../source/tcas.c.inst.exe 765 1 1 500 400 424 3 600 500 0 1 1     > ../newoutputs/t1532
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1531.tr
echo ">>>>>>>>running test 1533"
../source/tcas.c.inst.exe 765 1 1 500 400 424 0 600 500 0 1 1     > ../newoutputs/t1533
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1532.tr
echo ">>>>>>>>running test 1534"
../source/tcas.c.inst.exe 765 1 1 600 400 524 0 600 500 0 1 1     > ../newoutputs/t1534
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1533.tr
echo ">>>>>>>>running test 1535"
../source/tcas.c.inst.exe 765 1 1 600 400 524 2 600 500 0 1 1     > ../newoutputs/t1535
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1534.tr
echo ">>>>>>>>running test 1536"
../source/tcas.c.inst.exe 901 1 0 502 200 450 3 801 740 1 0 1     > ../newoutputs/t1536
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1535.tr
echo ">>>>>>>>running test 1537"
../source/tcas.c.inst.exe 901 1 0 502 200 450 2 801 740 1 0 1     > ../newoutputs/t1537
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1536.tr
echo ">>>>>>>>running test 1538"
../source/tcas.c.inst.exe 901 1 1 502 200 450 1 801 740 1 0 1     > ../newoutputs/t1538
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1537.tr
echo ">>>>>>>>running test 1539"
../source/tcas.c.inst.exe 901 1 1 502 200 450 1 801 740 0 1 0     > ../newoutputs/t1539
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1538.tr
echo ">>>>>>>>running test 1540"
../source/tcas.c.inst.exe 901 1 1 502 200 450 1 801 740 0 1 1     > ../newoutputs/t1540
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1539.tr
echo ">>>>>>>>running test 1541"
../source/tcas.c.inst.exe 901 1 1 502 200 450 0 801 740 0 1 1     > ../newoutputs/t1541
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1540.tr
echo ">>>>>>>>running test 1542"
../source/tcas.c.inst.exe 675 1 0 300 0 424 1 600 500 0 1 1     > ../newoutputs/t1542
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1541.tr
echo ">>>>>>>>running test 1543"
../source/tcas.c.inst.exe 675 1 0 300 0 424 2 600 500 0 1 1     > ../newoutputs/t1543
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1542.tr
echo ">>>>>>>>running test 1544"
../source/tcas.c.inst.exe 675 1 1 300 0 424 2 600 500 0 1 1     > ../newoutputs/t1544
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1543.tr
echo ">>>>>>>>running test 1545"
../source/tcas.c.inst.exe 675 1 1 300 0 424 3 600 500 0 1 1     > ../newoutputs/t1545
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1544.tr
echo ">>>>>>>>running test 1546"
../source/tcas.c.inst.exe 675 1 1 300 0 424 0 600 500 0 1 1     > ../newoutputs/t1546
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1545.tr
echo ">>>>>>>>running test 1547"
../source/tcas.c.inst.exe 675 1 1 300 0 424 0 600 300 0 1 1     > ../newoutputs/t1547
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1546.tr
echo ">>>>>>>>running test 1548"
../source/tcas.c.inst.exe 675 1 1 300 0 424 0 600 300 0 1 0     > ../newoutputs/t1548
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1547.tr
echo ">>>>>>>>running test 1549"
../source/tcas.c.inst.exe 611 1 1 1142 511 4704 1 740 500 0 1 1     > ../newoutputs/t1549
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1548.tr
echo ">>>>>>>>running test 1550"
../source/tcas.c.inst.exe 611 1 1 1142 511 4704 1 740 500 0 1 0     > ../newoutputs/t1550
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1549.tr
echo ">>>>>>>>running test 1551"
../source/tcas.c.inst.exe 611 1 0 1142 511 4704 1 740 500 1 1 0     > ../newoutputs/t1551
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1550.tr
echo ">>>>>>>>running test 1552"
../source/tcas.c.inst.exe 611 1 0 1142 511 4704 2 740 500 1 1 0     > ../newoutputs/t1552
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1551.tr
echo ">>>>>>>>running test 1553"
../source/tcas.c.inst.exe 611 1 0 1142 511 4704 3 740 500 1 1 0     > ../newoutputs/t1553
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1552.tr
echo ">>>>>>>>running test 1554"
../source/tcas.c.inst.exe 611 1 0 1142 511 4704 0 740 500 1 1 0     > ../newoutputs/t1554
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1553.tr
echo ">>>>>>>>running test 1555"
../source/tcas.c.inst.exe 611 1 0 1142 511 4704 0 740 500 0 1 0     > ../newoutputs/t1555
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1554.tr
echo ">>>>>>>>running test 1556"
../source/tcas.c.inst.exe 611 1 0 1142 511 4704 0 740 500 0 1 1     > ../newoutputs/t1556
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1555.tr
echo ">>>>>>>>running test 1557"
../source/tcas.c.inst.exe 611 1 0 1142 511 4704 2 740 500 0 1 1     > ../newoutputs/t1557
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1556.tr
echo ">>>>>>>>running test 1558"
../source/tcas.c.inst.exe 718 1 0 717 34 1153 2 429 326 0 0 1     > ../newoutputs/t1558
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1557.tr
echo ">>>>>>>>running test 1559"
../source/tcas.c.inst.exe 718 1 0 717 34 1153 3 429 326 0 0 1     > ../newoutputs/t1559
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1558.tr
echo ">>>>>>>>running test 1560"
../source/tcas.c.inst.exe 634 1 0 633 500 335 1 665 795 1 0 1     > ../newoutputs/t1560
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1559.tr
echo ">>>>>>>>running test 1561"
../source/tcas.c.inst.exe 634 1 0 633 500 335 2 665 795 1 0 1     > ../newoutputs/t1561
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1560.tr
echo ">>>>>>>>running test 1562"
../source/tcas.c.inst.exe 634 1 1 633 500 335 2 665 795 1 0 1     > ../newoutputs/t1562
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1561.tr
echo ">>>>>>>>running test 1563"
../source/tcas.c.inst.exe 634 1 1 633 500 335 2 665 795 0 1 1     > ../newoutputs/t1563
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1562.tr
echo ">>>>>>>>running test 1564"
../source/tcas.c.inst.exe 634 1 1 633 500 335 3 665 795 0 1 1     > ../newoutputs/t1564
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1563.tr
echo ">>>>>>>>running test 1565"
../source/tcas.c.inst.exe 634 1 1 633 500 335 0 665 795 0 1 1     > ../newoutputs/t1565
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1564.tr
echo ">>>>>>>>running test 1566"
../source/tcas.c.inst.exe 634 1 1 733 500 335 0 665 795 0 1 1     > ../newoutputs/t1566
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1565.tr
echo ">>>>>>>>running test 1567"
../source/tcas.c.inst.exe 500 0 1 300 0 424 2 600 500 0 0 0     > ../newoutputs/t1567
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1566.tr
echo ">>>>>>>>running test 1568"
../source/tcas.c.inst.exe 500 0 1 300 0 424 2 600 500 1 1 1     > ../newoutputs/t1568
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1567.tr
echo ">>>>>>>>running test 1569"
../source/tcas.c.inst.exe 500 0 0 300 0 424 2 600 500 1 1 1     > ../newoutputs/t1569
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1568.tr
echo ">>>>>>>>running test 1570"
../source/tcas.c.inst.exe 400 0 1 300 80 424 2 600 500 0 0 0     > ../newoutputs/t1570
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1569.tr
echo ">>>>>>>>running test 1571"
../source/tcas.c.inst.exe 700 0 1 300 80 424 2 600 500 0 0 0     > ../newoutputs/t1571
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1570.tr
echo ">>>>>>>>running test 1572"
../source/tcas.c.inst.exe 700 0 1 300 0 424 2 600 500 0 0 0     > ../newoutputs/t1572
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1571.tr
echo ">>>>>>>>running test 1573"
../source/tcas.c.inst.exe 700 0 1 300 0 424 2 600 500 1 1 1     > ../newoutputs/t1573
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1572.tr
echo ">>>>>>>>running test 1574"
../source/tcas.c.inst.exe 700 0 0 300 0 424 2 600 500 1 1 1     > ../newoutputs/t1574
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1573.tr
echo ">>>>>>>>running test 1575"
../source/tcas.c.inst.exe 1078 1 0 581 567 655 3 637 906 1 1 0     > ../newoutputs/t1575
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1574.tr
echo ">>>>>>>>running test 1576"
../source/tcas.c.inst.exe 1078 1 1 581 567 655 3 637 906 0 1 0     > ../newoutputs/t1576
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1575.tr
echo ">>>>>>>>running test 1577"
../source/tcas.c.inst.exe 1078 1 1 581 567 655 3 637 906 0 1 1     > ../newoutputs/t1577
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1576.tr
echo ">>>>>>>>running test 1578"
../source/tcas.c.inst.exe 1078 1 1 581 567 655 0 637 906 0 1 1     > ../newoutputs/t1578
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1577.tr
echo ">>>>>>>>running test 1579"
../source/tcas.c.inst.exe 1     > ../newoutputs/t1579
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1578.tr
echo ">>>>>>>>running test 1580"
../source/tcas.c.inst.exe 1 1 581 567 655 0 637 906 0 1 1     > ../newoutputs/t1580
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1579.tr
echo ">>>>>>>>running test 1581"
../source/tcas.c.inst.exe 1 581 567 655 0 637 906 0 1 1     > ../newoutputs/t1581
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1580.tr
echo ">>>>>>>>running test 1582"
../source/tcas.c.inst.exe 581 567 655 0 637 906 0 1 1     > ../newoutputs/t1582
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1581.tr
echo ">>>>>>>>running test 1583"
../source/tcas.c.inst.exe 567 655 0 637 906 0 1 1     > ../newoutputs/t1583
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1582.tr
echo ">>>>>>>>running test 1584"
../source/tcas.c.inst.exe 655 0 637 906 0 1 1     > ../newoutputs/t1584
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1583.tr
echo ">>>>>>>>running test 1585"
../source/tcas.c.inst.exe 0 637 906 0 1 1     > ../newoutputs/t1585
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1584.tr
echo ">>>>>>>>running test 1586"
../source/tcas.c.inst.exe 637 906 0 1 1     > ../newoutputs/t1586
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1585.tr
echo ">>>>>>>>running test 1587"
../source/tcas.c.inst.exe 906 0 1 1     > ../newoutputs/t1587
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1586.tr
echo ">>>>>>>>running test 1588"
../source/tcas.c.inst.exe 0 1 1     > ../newoutputs/t1588
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1587.tr
echo ">>>>>>>>running test 1589"
../source/tcas.c.inst.exe 1 1     > ../newoutputs/t1589
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1588.tr
echo ">>>>>>>>running test 1590"
../source/tcas.c.inst.exe 1078 1 1 567 655 0 637 906 0 1 1     > ../newoutputs/t1590
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1589.tr
echo ">>>>>>>>running test 1591"
../source/tcas.c.inst.exe 1078 1 1 655 0 637 906 0 1 1     > ../newoutputs/t1591
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1590.tr
echo ">>>>>>>>running test 1592"
../source/tcas.c.inst.exe 1078 1 1 0 637 906 0 1 1     > ../newoutputs/t1592
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1591.tr
echo ">>>>>>>>running test 1593"
../source/tcas.c.inst.exe 1078 1 1 637 906 0 1 1     > ../newoutputs/t1593
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1592.tr
echo ">>>>>>>>running test 1594"
../source/tcas.c.inst.exe 1078 1 1 581 655 0 637 906 0 1 1     > ../newoutputs/t1594
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1593.tr
echo ">>>>>>>>running test 1595"
../source/tcas.c.inst.exe 1078 1 1 581 0 637 906 0 1 1     > ../newoutputs/t1595
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1594.tr
echo ">>>>>>>>running test 1596"
../source/tcas.c.inst.exe 1078 1 1 581 637 906 0 1 1     > ../newoutputs/t1596
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1595.tr
echo ">>>>>>>>running test 1597"
../source/tcas.c.inst.exe 1078 1 1 581 906 0 1 1     > ../newoutputs/t1597
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1596.tr
echo ">>>>>>>>running test 1598"
../source/tcas.c.inst.exe 1078 1 1 581 906 1 1     > ../newoutputs/t1598
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1597.tr
echo ">>>>>>>>running test 1599"
../source/tcas.c.inst.exe 1078 1 1 581 567 655 0 906 0 1 1     > ../newoutputs/t1599
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1598.tr
echo ">>>>>>>>running test 1600"
../source/tcas.c.inst.exe 1078 1 1 581 567 655 0 0 1 1     > ../newoutputs/t1600
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1599.tr
echo ">>>>>>>>running test 1601"
../source/tcas.c.inst.exe 1078 1 1 581 567 655 0 1 1     > ../newoutputs/t1601
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1600.tr
echo ">>>>>>>>running test 1602"
../source/tcas.c.inst.exe 1078 1 1 581 567 655 0 1     > ../newoutputs/t1602
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1601.tr
echo ">>>>>>>>running test 1603"
../source/tcas.c.inst.exe 1078 1 1 581 567 0 637 0 1 1     > ../newoutputs/t1603
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1602.tr
echo ">>>>>>>>running test 1604"
../source/tcas.c.inst.exe 1078 1 1 567 655 0 906 0 1 1     > ../newoutputs/t1604
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1603.tr
echo ">>>>>>>>running test 1605"
../source/tcas.c.inst.exe 1078 1 581 655 0 906 0 1 1     > ../newoutputs/t1605
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1604.tr
echo ">>>>>>>>running test 1606"
../source/tcas.c.inst.exe 1078 1 1 655 0 906 0 1 1     > ../newoutputs/t1606
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1605.tr
echo ">>>>>>>>running test 1607"
../source/tcas.c.inst.exe 1078 1 655 0 906 0 1 1     > ../newoutputs/t1607
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1606.tr
echo ">>>>>>>>running test 1608"
../source/tcas.c.inst.exe 1078 1 1 637 906 1 1     > ../newoutputs/t1608
cp $ARISTOTLE_DB_DIR/tcas.c.tr ../traces/1607.tr
