#!/usr/bin/env bash
#Title			: run_falty_programs.sh
#Usage			: bash run_falty_programs.sh
#Author			: pmorvalho
#Date			: November 07, 2023
#Description		: Runs all faulty version of the TCAS program and copies all traces to the "traces/" directory.
#Notes			: 
# (C) Copyright 2023 Pedro Orvalho.
#==============================================================================

initial_dir=$(pwd)

for v_dir in $(find ../versions/v* -mindepth 0 -maxdepth 0 -type d);
do
    cd $v_dir
    version=$(basename $(pwd))
    echo "Executing faulty version $version"
    gcc tcas.c -o tcas-$version.exe
    mkdir failed_outputs correct_outputs
    for t in $(find $initial_dir/../inputs/t* -mindepth 0 -maxdepth 0 -type f);
    do
	t_id=$(basename $t ".in")    
	# echo ">>>>>>>>running test $t_id"
	./tcas-$version.exe  $(cat $t) > $t_id".out"
	if [[ $(diff $t_id".out" $initial_dir/../outputs/$t_id".out") ]];
	then
	    mv $t_id".out" failed_outputs/.
	else
	    mv $t_id".out" correct_outputs/.	   
	fi
    done
    pt=$(ls correct_outputs/*.out | wc -l)
    rm -rf correct_outputs
    ft=$(ls failed_outputs/*.out | wc -l)
    mv failed_outputs $initial_dir/../traces/$version
    echo "Faulty version $version. Passed Tests = $pt. Failed Tests  = $ft."    
    cd $initial_dir
done
	   
