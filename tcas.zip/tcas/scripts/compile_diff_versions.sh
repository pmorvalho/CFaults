#!/usr/bin/env bash
#Title			: compile_diff_versions.sh
#Usage			: bash compile_diff_versions.sh
#Author			: pmorvalho
#Date			: November 07, 2023
#Description		: 
#Notes			: 
# (C) Copyright 2023 Pedro Orvalho.
#==============================================================================


initial_dir=$(pwd)
for v_dir in $(find ../versions/v* -mindepth 0 -maxdepth 0 -type d);
do
    cd $v_dir
    version=$(basename $(pwd))
    echo "Compile faulty version $version"
    gcc tcas.c -o tcas-$version.exe
    cd $initial_dir
done
	   
